from django.db import models
from accounts.models import BaseModel, CustomUser
import uuid
# Create your models here.

class Application(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    base_url = models.URLField(blank=True, null=True, help_text="Base URL for the application")
    active = models.BooleanField(default=True, help_text="Is the application active?")


    def __str__(self):
        return self.name



class Permission(models.Model):
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Permission'
        verbose_name_plural = 'Permissions'
        unique_together = ['name', 'application']

    def __str__(self):
        return f'{self.name} ({self.application})'


class Role(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    permissions = models.ManyToManyField(Permission)

    class Meta:
        verbose_name = 'Role'
        verbose_name_plural = 'Roles'
        unique_together = ['name', 'application']

    def __str__(self):
        return f'{self.name} ({self.application})'




class UserRole(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    can_create = models.BooleanField(default=False)
    can_read = models.BooleanField(default=True)
    can_update = models.BooleanField(default=False)
    can_delete = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'role', 'application')

    def get_absolute_url(self):
        if self.application.base_url:
            return f"{self.application.base_url}/user/{self.user.username}"
        else:
            return "/profile/"

    def __str__(self):
        return f"{self.user.username} - {self.role.name} - {self.application.name}"