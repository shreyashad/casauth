from django.urls import path
from .views import *

urlpatterns = [

    path('applications/', ApplicationListCreateView.as_view(), name='application-list-create'),
    path('applications/<uuid:pk>/', ApplicationDetailView.as_view(), name='application-detail'),
    path('application-count/', ApplicationCountView.as_view(), name='application-count'),
    path('application-details/', ApplicationAPIView.as_view(),name='application'),
    # Permission URLs
    path('permissions/', PermissionListCreateView.as_view(), name='permission-list-create'),
    path('permissions/<uuid:pk>/', PermissionDetailView.as_view(), name='permission-detail'),

    # Role URLs
    path('roles/', RoleListCreateView.as_view(), name='role-list-create'),
    path('roles/<uuid:pk>/', RoleDetailView.as_view(), name='role-detail'),

    # UserRole URLs
    path('user-roles/', UserRoleListCreateView.as_view(), name='userrole-list-create'),
    path('user-roles/<uuid:pk>/', UserRoleDetailView.as_view(), name='userrole-detail'),

]
