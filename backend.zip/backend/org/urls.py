from django.urls import path
from .views import *

urlpatterns = [
    path('organization-list/', OrganizationListCreateAPIView.as_view(), name='organization'),
    path('organization-details/<uuid:pk>/', OrganizationRetrieveUpdateDestroyAPIView.as_view(), name='organization-details'),
    path('org-subtype-list/', OrganizationSubTypeListCreateAPIView.as_view(),
         name='org-subtype-list'),
    path('org-subtype-details/<uuid:pk>/', OrganizationSubTypeRetrieveUpdateDestroyAPIView.as_view(),
         name='org-subtype-details'),
    path('locations-list/', LocationsListCreateAPIView.as_view(), name='locations'),
    path('locations-details/<uuid:pk>/', LocationsRetrieveUpdateDestroyAPIView.as_view(), name='locations-details'),
    path('designation-list/', DesignationListCreateAPIView.as_view(), name='designation'),
    path('designation-details/<uuid:pk>', DesignationRetrieveUpdateDestroyAPIView.as_view(), name='designation-details'),
    path('department-list/', DepartmentListCreateAPIView.as_view(), name='department'),
    path('department-details/<uuid:pk>', DepartmentRetrieveUpdateDestroyAPIView.as_view(),
         name='department-details'),
    path('departments/', DepartmentListAPIView.as_view(), name='departments'),
    path('designations/', DesignationListAPIView.as_view(), name='designations'),
    path('org-type-list/', OrgTypeListView.as_view(), name='org-type'),
    path('org-name-list/', OrgNameList.as_view(), name='org-name-list'),
    path('org-subtype-list/', OrgSubTypeList.as_view(), name='org-subtype-list'),
    path('location-type-list/', LocationTypeList.as_view(), name='location-type-list'),
    path('location-name-list/', LocationNameList.as_view(), name='location-name-list'),
    path('location-code-list/', LocationCodeList.as_view(), name='location-code-list'),

]