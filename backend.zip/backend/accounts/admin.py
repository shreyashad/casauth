from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ["username",  "is_online", "is_verified"]



@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user_username',)  # Display the username of the associated user

    def user_username(self, obj):
        return obj.user.username

    user_username.short_description = 'username'


@admin.register(AuthenticatorFilterSettings)
class AuthenticatorFilterSettingsAdmin(admin.ModelAdmin):
    list_display = ['user', 'filter_org_type', 'filter_org_name', 'filter_org_sub_type', 'filter_location_type']
