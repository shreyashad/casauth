
from .models import *
from .serializers import *
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from django.contrib.auth.forms import SetPasswordForm
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication
class UserRegistrationView(generics.CreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'User registered successfully.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# views for administrator

class UserListView(generics.ListCreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]




class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]



class ChangePasswordView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        form = SetPasswordForm(user, data=request.data)
        if form.is_valid():
            form.save()
            return Response({'status': 'password set'}, status=status.HTTP_200_OK)
        return Response(form.errors, status=status.HTTP_400_BAD_REQUEST)



class ListAdministratorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_administrator=True)


class ListAuthenticatorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_authenticator=True)



class ListSiteAdminsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_site_admin=True)


class AssignRolesView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        serializer = self.get_serializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RevokeRolesView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        user.is_administrator = False
        user.is_authenticator = False
        user.is_site_admin = False
        user.save()
        return Response({'status': 'roles revoked'})



class FilterSettingsDetailView(generics.RetrieveUpdateAPIView):
    serializer_class = AuthenticatorFilterSettingsSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return AuthenticatorFilterSettings.objects.get(user=self.request.user)
        except AuthenticatorFilterSettings.DoesNotExist:
            # Create a new filter settings instance if it doesn't exist
            return AuthenticatorFilterSettings.objects.create(user=self.request.user)

    def perform_update(self, serializer):
        instance = self.get_object()
        serializer.save(user=instance.user)




class AuthenticatorFilteredUserListView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if not user.is_authenticator:
            raise PermissionDenied("You do not have permission to access this resource.")

        # Get filter settings for the user
        filter_settings = AuthenticatorFilterSettings.objects.get(user=user)

        # Apply filters based on the filter settings
        queryset = CustomUser.objects.filter(is_authenticator=True)

        if filter_settings.filter_org_type:
            queryset = queryset.filter(org_type=user.org_type)
        if filter_settings.filter_org_name:
            queryset = queryset.filter(org_name=user.org_name)
        if filter_settings.filter_org_sub_type:
            queryset = queryset.filter(org_sub_type=user.org_sub_type)
        if filter_settings.filter_location_type:
            queryset = queryset.filter(location_type=user.location_type)
        if filter_settings.filter_location_name:
            queryset = queryset.filter(location_name=user.location_name)
        if filter_settings.filter_department:
            queryset = queryset.filter(department=user.department)

        return queryset



class OnlineUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            online_user = CustomUser.objects.filter(is_online=True).count()
            return Response({'active_user': online_user})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class TotalUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            total_user = CustomUser.objects.count()
            return Response({'total_user': total_user})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AministratorUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            online_user = CustomUser.objects.filter(is_online=True).count()
            return Response({'active_user': online_user})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

