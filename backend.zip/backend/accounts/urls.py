from django.urls import path
from .views import *

urlpatterns = [

    path('register/',UserRegistrationView.as_view(),name='register'),
    path('admin-user-list/', UserListView.as_view(), name='user-list-administrator'),
    path('admin-user-details/<uuid:pk>/', UserDetailView.as_view(), name='user-details-administrator'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password-user'),
    path('administrator-user-list/', ListAdministratorsView.as_view(), name='administrator-user-list'),
    path('authenticator-user-list/', ListAuthenticatorsView.as_view(), name='authenticator-user-list'),
    path('site-admin-user-list/', ListSiteAdminsView.as_view(), name='site-admin-user-list'),
    path('assign-role/', AssignRolesView.as_view(), name='assign-role'),
    path('revoke-role/', RevokeRolesView.as_view(), name='revoke-role'),
    path('assign-filter-authenticator/', FilterSettingsDetailView.as_view(), name='assign-filter-authenticator'),
    path('authenticator-user-list/', AuthenticatorFilteredUserListView.as_view(), name='authenticator-user-list'),
    path('online-user-count/', OnlineUserCountView.as_view(), name='online-user-count'),
    path('total-users-count/', TotalUserCountView.as_view(), name='total_user_count'),

]