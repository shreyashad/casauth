# cas/notifications.py (Example module within CAS app)
from django.utils import timezone
from notifications.models import Notification  # Assuming Notification model is defined in cas.models
from .models import CustomUser
def create_admin_notification(user):
    admin_users = CustomUser.objects.filter(is_administrator=True)  # Adjust as per your CustomUser model
    for admin_user in admin_users:
        Notification.objects.create(
            user=admin_user,
            title=f'New User Registration: {user.username}',
            message=f'A new user with username {user.username} has registered.',
            notification_type='info',  # Adjust notification type as needed
            created_at=timezone.now(),
            read=False
        )
