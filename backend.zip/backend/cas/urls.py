from django.urls import path
from .views import *
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    path('login/',LoginAPIView.as_view(), name='login'),
    path('logout/',LogoutView.as_view(), name='logout'),
    path('validate-ticket/', ValidateServiceTicketAPIView.as_view(), name='validate-ticket'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]