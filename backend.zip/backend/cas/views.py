import uuid
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from accounts.models import *
from .models import *
from .serializers import *
from rest_framework_simplejwt.tokens import RefreshToken




class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if serializer.is_valid():
            username = serializer.validated_data.get('username')
            password = serializer.validated_data.get('password')
            application_id = serializer.validated_data.get('application_id')

            # Ensure username, password, and application_id are present
            if not username or not password or not application_id:
                return Response({"error": "All fields are required: username, password, and application_id"},
                                status=status.HTTP_400_BAD_REQUEST)

            # Authenticate the user
            user = authenticate(username=username, password=password)
            if user is not None:
                try:
                    # Validate the application is active and exists
                    application = Application.objects.get(id=application_id, active=True)
                except Application.DoesNotExist:
                    return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)


                # Update the user's last login time
                user.is_online = True
                user.last_login = timezone.now()
                user.save()

                # Generate JWT tokens
                refresh = RefreshToken.for_user(user)

                # Create a user session
                session_key = UserSession.create_ticket_str()
                expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
                user_session = UserSession.objects.create(
                    user=user,
                    application=application,
                    session_key=session_key,
                    expires_at=expires_at
                )

                # Generate Service Ticket
                service_ticket = ServiceTicket.objects.create_ticket(user=user, application=application)

                # Optionally, generate a Proxy Granting Ticket (PGT)
                pgt = ProxyGrantingTicket.objects.create_ticket(user=user, application=application)

                # Response data with JWT and service tickets
                response_data = {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'session_key': user_session.session_key,
                    'session_expires_at': user_session.expires_at,
                    'service_ticket': service_ticket.ticket,
                    'proxy_granting_ticket': pgt.ticket,
                }

                return Response(response_data, status=status.HTTP_200_OK)

            # Handle invalid credentials
            return Response({"error": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)

        # Handle serializer validation errors
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class ValidateServiceTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        # Use the serializer to validate incoming data
        serializer = ServiceTicketValidationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Extract validated data
        service_ticket = serializer.validated_data.get('service_ticket')
        application_id = serializer.validated_data.get('application_id')

        try:
            # Retrieve the application
            application = Application.objects.get(id=application_id)

            # Validate the service ticket against the application
            ticket = ServiceTicket.validate_ticket(service_ticket, application)

            # Check if the ticket is expired or consumed
            if ticket.is_expired:
                return Response({'error': 'Ticket expired'}, status=status.HTTP_400_BAD_REQUEST)
            if ticket.is_consumed:
                return Response({'error': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            # Consume the ticket (mark it as used)
            ticket.consume()
            user = ticket.user

            # Check if the user has access to this application via a role
            try:
                user_role = UserRole.objects.get(user=user, application=application)
                user_profile = UserProfile.objects.get(user=user)
                profile_pic = user_profile.profile_picture.url if user_profile.profile_picture else None
                permissions = {
                    'can_create': user_role.can_create,
                    'can_read': user_role.can_read,
                    'can_update': user_role.can_update,
                    'can_delete': user_role.can_delete
                }
                return Response({
                    'profile_pic': profile_pic,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'org_type': user.org_type,
                    'org_name': user.org_name,
                    'org_sub_type': user.org_sub_type,
                    'location_type': user.location_type,
                    'location_name': user.location_name,
                    'location_code': user.location_code,
                    'emp_code': user.emp_code,
                    'department': user.department,
                    'designation': user.designation,
                    'username': user.username,
                    'roles': user_role.role.name,
                    'permissions': permissions
                }, status=status.HTTP_200_OK)

            except UserRole.DoesNotExist:
                return Response({"error": "User does not have access to this application"},
                                status=status.HTTP_403_FORBIDDEN)

        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket = request.data.get('service_ticket')

        try:
            ticket = ServiceTicket.objects.get(ticket=service_ticket)
            if ticket.is_consumed:
                return Response({'detail': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            ticket.consume()
            return Response({'detail': 'Logged out successfully'}, status=status.HTTP_200_OK)
        except ServiceTicket.DoesNotExist:
            return Response({'detail': 'Invalid ticket'}, status=status.HTTP_400_BAD_REQUEST)




class GenerateProxyTicketView(APIView):
    def post(self, request, *args, **kwargs):
        pgt_id = request.data.get('pgt_id')
        application_id = request.data.get('application_id')

        try:
            pgt = ProxyGrantingTicket.objects.get(ticket=pgt_id)
            application = Application.objects.get(id=application_id)
            proxy_ticket = ProxyTicket.create_ticket(user=pgt.user, application=application, granted_by_pgt=pgt)
            return Response({'proxy_ticket': proxy_ticket.ticket}, status=status.HTTP_200_OK)
        except ProxyGrantingTicket.DoesNotExist:
            return Response({'detail': 'Invalid Proxy Granting Ticket'}, status=status.HTTP_400_BAD_REQUEST)
        except Application.DoesNotExist:
            return Response({'detail': 'Invalid application'}, status=status.HTTP_400_BAD_REQUEST)

