from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from cas.models import Service, ServiceTicket
from accounts.models import CustomUser
from .serializers import LoginSerializer

class LoginAPIView(APIView):
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        token = {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }

        # Issue a CAS service ticket if a service URL is provided
        service_url = request.data.get('service_url')
        if service_url:
            try:
                service = Service.objects.get(base_url=service_url)
                service_ticket = ServiceTicket.objects.create_ticket(user=user, service=service)
                token['cas_ticket'] = service_ticket.ticket
            except Service.DoesNotExist:
                return Response({'error': 'Invalid service URL'}, status=status.HTTP_400_BAD_REQUEST)

        return Response(token, status=status.HTTP_200_OK)


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import ServiceTicket


class ValidateTicketView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket = request.data.get('service_ticket')
        application_id = request.data.get('application_id')

        try:
            application = Application.objects.get(id=application_id)
            ticket = ServiceTicket.validate_ticket(service_ticket, application)
        except ValueError as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        # Consume the ticket
        ticket.consume()

        return Response({'detail': 'Ticket is valid and has been consumed'}, status=status.HTTP_200_OK)


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import ServiceTicket


class LogoutView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket = request.data.get('service_ticket')

        try:
            ticket = ServiceTicket.objects.get(ticket=service_ticket)
            if ticket.is_consumed:
                return Response({'detail': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            ticket.consume()
            return Response({'detail': 'Logged out successfully'}, status=status.HTTP_200_OK)
        except ServiceTicket.DoesNotExist:
            return Response({'detail': 'Invalid ticket'}, status=status.HTTP_400_BAD_REQUEST)


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import ProxyTicket, ProxyGrantingTicket


class GenerateProxyTicketView(APIView):
    def post(self, request, *args, **kwargs):
        pgt_id = request.data.get('pgt_id')
        application_id = request.data.get('application_id')

        try:
            pgt = ProxyGrantingTicket.objects.get(ticket=pgt_id)
            application = Application.objects.get(id=application_id)
            proxy_ticket = ProxyTicket.create_ticket(user=pgt.user, application=application, granted_by_pgt=pgt)
            return Response({'proxy_ticket': proxy_ticket.ticket}, status=status.HTTP_200_OK)
        except ProxyGrantingTicket.DoesNotExist:
            return Response({'detail': 'Invalid Proxy Granting Ticket'}, status=status.HTTP_400_BAD_REQUEST)
        except Application.DoesNotExist:
            return Response({'detail': 'Invalid application'}, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from cas.models import Ticket

class ValidateTicketAPIView(APIView):
    def get(self, request, *args, **kwargs):
        ticket = request.query_params.get('ticket')
        service_url = request.query_params.get('service')

        if not ticket or not service_url:
            return Response({'error': 'Ticket and service URL are required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Validate ticket
            service = Service.objects.get(base_url=service_url)
            ticket_instance = Ticket.objects.validate_ticket(ticket, service)
            return Response({
                'ticket': ticket_instance.ticket,
                'service': service.name,
                'user': ticket_instance.user.username
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from cas.models import Ticket

class ConsumeTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        ticket = request.data.get('ticket')

        if not ticket:
            return Response({'error': 'Ticket is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            ticket_instance = Ticket.objects.get(ticket=ticket)
            ticket_instance.consume()
            return Response({'status': 'Ticket consumed'}, status=status.HTTP_200_OK)
        except Ticket.DoesNotExist:
            return Response({'error': 'Ticket does not exist'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
----------------------------------------------------------------------------------------------------
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from accounts.models import CustomUser
from accounts.serializers import LoginSerializer

class LoginAPIView(APIView):
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']

        # Logging the login event
        log_audit_entry(user, Application.objects.get(name='Your CAS Application'), 'Login', user.id, 'User login')

        # Generating JWT tokens
        refresh = RefreshToken.for_user(user)
        token = {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }

        return Response(token, status=status.HTTP_200_OK)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import update_session_auth_hash
from accounts.models import CustomUser
from accounts.serializers import ChangePasswordSerializer

class ChangePasswordAPIView(APIView):
    serializer_class = ChangePasswordSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = request.user
        new_password = serializer.validated_data['new_password']

        user.set_password(new_password)
        user.save()
        update_session_auth_hash(request, user)  # Keep the user logged in after password change

        return Response({'message': 'Password updated successfully.'}, status=status.HTTP_200_OK)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from cas.models import Service, Ticket
from cas.serializers import TicketSerializer

class CreateTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        service_id = request.data.get('service_id')
        try:
            service = Service.objects.get(id=service_id)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=status.HTTP_404_NOT_FOUND)

        ticket = Ticket.objects.create_ticket(user=request.user, service=service)
        serializer = TicketSerializer(ticket)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from cas.models import Ticket, Service

class ValidateTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        ticket_str = request.data.get('ticket')
        service_id = request.data.get('service_id')

        try:
            service = Service.objects.get(id=service_id)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=status.HTTP_404_NOT_FOUND)

        try:
            ticket = Ticket.objects.validate_ticket(ticket_str, service)
            return Response({'valid': True, 'message': 'Ticket is valid.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'valid': False, 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from cas.models import Ticket

class ConsumeTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        ticket_str = request.data.get('ticket')
        try:
            ticket = Ticket.objects.get(ticket=ticket_str)
            if ticket.is_consumed:
                return Response({'message': 'Ticket already consumed.'}, status=status.HTTP_400_BAD_REQUEST)
            ticket.consume()
            return Response({'message': 'Ticket marked as consumed.'}, status=status.HTTP_200_OK)
        except Ticket.DoesNotExist:
            return Response({'error': 'Ticket not found'}, status=status.HTTP_404_NOT_FOUND)
from rest_framework import status, generics
from rest_framework.response import Response
from cas.models import Service
from cas.serializers import ServiceSerializer

class ServiceListCreateAPIView(generics.ListCreateAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class ServiceRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from cas.models import ServiceTicket, ProxyGrantingTicket

class IssuePGTAPIView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket_str = request.data.get('service_ticket')
        try:
            service_ticket = ServiceTicket.objects.get(ticket=service_ticket_str)
            pgt = ProxyGrantingTicket.objects.create_ticket(user=request.user, service=service_ticket.service)
            pgt.iou = f"PGTIOU-{int(timezone.time())}"
            pgt.save()
            return Response({'ticket': pgt.ticket, 'iou': pgt.iou}, status=status.HTTP_201_CREATED)
        except ServiceTicket.DoesNotExist:
            return Response({'error': 'Service Ticket not found'}, status=status.HTTP_404_NOT_FOUND)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from cas.models import ProxyTicket, ProxyGrantingTicket

class IssuePGTFromPTAPIView(APIView):
    def post(self, request, *args, **kwargs):
        proxy_ticket_str = request.data.get('proxy_ticket')
        try:
            proxy_ticket = ProxyTicket.objects.get(ticket=proxy_ticket_str)
            pgt = ProxyGrantingTicket.objects.create_ticket(user=request.user, service=proxy_ticket.service)
            pgt.iou = f"PGTIOU-{int(timezone.time())}"
            pgt.granted_by_pt = proxy_ticket
            pgt.save()
            return Response({'ticket': pgt.ticket, 'iou': pgt.iou}, status=status.HTTP_201_CREATED)
        except ProxyTicket.DoesNotExist:
            return Response({'error': 'Proxy Ticket not found'}, status=status.HTTP_404_NOT_FOUND)
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

class LogoutAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            refresh_token = request.data.get('refresh_token')
            token = RefreshToken(refresh_token)
            token.blacklist()  # Blacklist the refresh token
            return Response({'message': 'Logged out successfully.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
from rest_framework import status, generics
from accounts.models import CustomUser
from accounts.serializers import AdminUserSerializer

class AdminUserListCreateAPIView(generics.ListCreateAPIView):
    queryset = CustomUser.objects.filter(is_staff=True)
    serializer_class = AdminUserSerializer

class AdminUserRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CustomUser.objects.filter(is_staff=True)
    serializer_class = AdminUserSerializer
--------------------------------------------------------------
from rest_framework import serializers
from django.contrib.auth import authenticate
from accounts.models import CustomUser

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if user:
                if not user.is_active:
                    raise serializers.ValidationError("User account is disabled.")
                if not user.is_verified:
                    raise serializers.ValidationError("User is not verified.")
                data['user'] = user
            else:
                raise serializers.ValidationError("Unable to log in with provided credentials.")
        else:
            raise serializers.ValidationError("Must include 'username' and 'password'.")

        return data
from rest_framework import serializers
from accounts.models import CustomUser

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)
    new_password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)

    def validate(self, data):
        user = self.context['request'].user
        old_password = data.get('old_password')
        new_password = data.get('new_password')

        if not user.check_password(old_password):
            raise serializers.ValidationError("Old password is incorrect.")
        if old_password == new_password:
            raise serializers.ValidationError("New password must be different from old password.")

        return data
from rest_framework import serializers
from cas.models import Ticket

class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = ['ticket', 'user', 'service', 'expires', 'consumed']
from rest_framework import serializers
from cas.models import Service

class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'name', 'base_url', 'active']
from rest_framework import serializers
from accounts.models import UserProfile

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['address', 'city', 'state', 'country', 'postal_code', 'phone_number', 'date_of_birth', 'profile_picture', 'bio']
from rest_framework import serializers
from accounts.models import CustomUser

class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'is_staff', 'is_superuser']


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from django.utils import timezone
from .models import Ticket, Service
from accounts.models import CustomUser


class LoginView(APIView):
    def post(self, request):
        # Extract username and password from request
        username = request.data.get('username')
        password = request.data.get('password')
        service_id = request.data.get('service_id')

        if not username or not password or not service_id:
            return Response({"error": "Username, password, and service ID are required."},
                            status=status.HTTP_400_BAD_REQUEST)

        # Authenticate the user
        user = authenticate(username=username, password=password)
        if not user:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

        # Validate the service
        try:
            service = Service.objects.get(id=service_id, active=True)
        except Service.DoesNotExist:
            return Response({"error": "Invalid or inactive service."}, status=status.HTTP_400_BAD_REQUEST)

        # Generate a ticket
        ticket = Ticket.objects.create_ticket(user=user, service=service)

        return Response({
            "ticket": ticket.ticket,
            "expires": ticket.expires.isoformat(),
        }, status=status.HTTP_200_OK)
---------------------------
# cas/models.py
from django.db import models
from django.utils import timezone
from django.conf import settings
from accounts.models import CustomUser
import uuid
import random
import string

# Helper function to create a unique ticket string
def create_ticket_str(prefix=None):
    if not prefix:
        prefix = 'T'
    return f"{prefix}-{int(timezone.time())}-{''.join(random.choices(string.ascii_uppercase + string.digits, k=32))}"

class Application(models.Model):
    name = models.CharField(max_length=255, unique=True)
    base_url = models.URLField()
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class TicketManager(models.Manager):
    def create_ticket(self, user, application, **kwargs):
        ticket = create_ticket_str()
        expires = timezone.now() + timezone.timedelta(minutes=90)
        return self.create(ticket=ticket, user=user, application=application, expires=expires, **kwargs)

    def validate_ticket(self, ticket, application):
        try:
            t = self.get(ticket=ticket)
        except self.model.DoesNotExist:
            raise ValueError("Invalid ticket")
        if t.is_consumed:
            raise ValueError("Ticket already consumed")
        if t.is_expired:
            raise ValueError("Ticket expired")
        if t.application != application:
            raise ValueError("Invalid application")
        return t

class Ticket(models.Model):
    ticket = models.CharField(max_length=255, unique=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    expires = models.DateTimeField()
    consumed = models.DateTimeField(null=True, blank=True)

    objects = TicketManager()

    @property
    def is_expired(self):
        return timezone.now() > self.expires

    @property
    def is_consumed(self):
        return self.consumed is not None

    def consume(self):
        self.consumed = timezone.now()
        self.save()

    def __str__(self):
        return self.ticket

class ServiceTicket(Ticket):
    TICKET_PREFIX = 'ST'
    primary = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"

class ProxyTicket(Ticket):
    TICKET_PREFIX = 'PT'
    granted_by_pgt = models.ForeignKey('ProxyGrantingTicket', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"

class ProxyGrantingTicket(Ticket):
    TICKET_PREFIX = 'PGT'
    IOU_PREFIX = 'PGTIOU'
    iou = models.CharField(max_length=255, unique=True)
    granted_by_st = models.ForeignKey('ServiceTicket', null=True, blank=True, on_delete=models.PROTECT)
    granted_by_pt = models.ForeignKey('ProxyTicket', null=True, blank=True, on_delete=models.PROTECT)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"


------------------------------
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from .models import Ticket


@csrf_exempt  # You might want to use this if you are testing without CSRF protection.
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        application_id = request.POST.get('application_id')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Log in the user
            auth_login(request, user)

            try:
                # Validate that application_id is provided and is valid
                application = Application.objects.get(id=application_id)
            except Application.DoesNotExist:
                messages.error(request, "Invalid application.")
                return redirect('login')  # Redirect back to login if application is invalid

            # Create a ticket for the user
            Ticket.create_ticket(user=user, application=application)

            messages.success(request, "Login successful!")
            return redirect('home')  # Redirect to a success page or home

        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')  # Redirect back to login on failure

    return render(request, 'login.html')
--------------------------------------------------------------------------------------------------

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import CustomUser, Application, UserRole
from .serializers import LoginSerializer
from django.utils import timezone


class LoginAPIView(APIView):
    """
    This view handles user login within the Central Authentication System (CAS).
    Users are authenticated and provided with JWT tokens. Their roles and application
    information are validated for authorization.
    """

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data.get('username')
            password = serializer.validated_data.get('password')
            application_token = serializer.validated_data.get('application_token')

            # Authenticate user
            user = authenticate(username=username, password=password)
            if user is not None:
                # Validate Application Token (If needed)
                try:
                    application = Application.objects.get(token=application_token)
                except Application.DoesNotExist:
                    return Response({"error": "Invalid Application Token"}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the user has a role in the application
                try:
                    user_role = UserRole.objects.get(user=user, application=application)
                except UserRole.DoesNotExist:
                    return Response({"error": "User does not have access to this application"},
                                    status=status.HTTP_403_FORBIDDEN)

                # Generate JWT tokens
                refresh = RefreshToken.for_user(user)
                user.last_login = timezone.now()
                user.save()

                # Prepare response data
                response_data = {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'user': {
                        'username': user.username,
                        'first_name': user.first_name,
                        'last_name': user.last_name,
                        'roles': user_role.role.name,
                        'permissions': {
                            'can_create': user_role.can_create,
                            'can_read': user_role.can_read,
                            'can_update': user_role.can_update,
                            'can_delete': user_role.can_delete
                        },
                        'application': application.name,
                    }
                }

                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
-----------------------------
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.utils import timezone
from accounts.models import CustomUser
from roles.models import Application, UserRole
from cas.models import ServiceTicket, ProxyGrantingTicket
from .serializers import LoginSerializer
import uuid

class LoginAPIView(APIView):
    """
    This view handles user login for the CAS.
    After user authentication, JWT tokens are issued, and CAS tickets (Service Ticket, Proxy Granting Ticket)
    are generated if the user has the appropriate role in the application.
    """

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data.get('username')
            password = serializer.validated_data.get('password')
            application_name = serializer.validated_data.get('application_name')

            # Authenticate the user
            user = authenticate(username=username, password=password)
            if user is not None:
                # Fetch the application by name
                try:
                    application = Application.objects.get(name=application_name, active=True)
                except Application.DoesNotExist:
                    return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the user has a role in the application
                try:
                    user_role = UserRole.objects.get(user=user, application=application)
                except UserRole.DoesNotExist:
                    return Response({"error": "User does not have access to this application"}, status=status.HTTP_403_FORBIDDEN)

                # Generate JWT tokens
                refresh = RefreshToken.for_user(user)
                user.last_login = timezone.now()
                user.save()

                # Generate a Service Ticket
                service_ticket = ServiceTicket.objects.create(
                    user=user,
                    application=application,
                    ticket=str(uuid.uuid4())  # Generate unique service ticket
                )

                # Optionally, generate a Proxy Granting Ticket (PGT)
                pgt = ProxyGrantingTicket.objects.create(
                    user=user,
                    application=application,
                    ticket=str(uuid.uuid4())  # Generate unique PGT
                )

                # Prepare the response data
                response_data = {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'service_ticket': service_ticket.ticket,
                    'proxy_granting_ticket': pgt.ticket,
                    'user': {
                        'username': user.username,
                        'first_name': user.first_name,
                        'last_name': user.last_name,
                        'roles': user_role.role.name,
                        'permissions': {
                            'can_create': user_role.can_create,
                            'can_read': user_role.can_read,
                            'can_update': user_role.can_update,
                            'can_delete': user_role.can_delete
                        },
                        'application': application.name,
                    }
                }

                return Response(response_data, status=status.HTTP_200_OK)

            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import ServiceTicket, Application

class ValidateServiceTicketAPIView(APIView):
    def post(self, request):
        service_ticket = request.data.get('service_ticket')
        application_id = request.data.get('application_id')

        try:
            application = Application.objects.get(id=application_id)
            ticket = ServiceTicket.validate_ticket(service_ticket, application)
            if ticket.is_valid():
                ticket.consume()
                user = ticket.user
                return Response({
                    'username': user.username,
                    'roles': user.role.name,
                    'permissions': {
                        'can_create': user.can_create,
                        'can_read': user.can_read,
                        'can_update': user.can_update,
                        'can_delete': user.can_delete
                    }
                }, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Invalid ticket'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class ValidateServiceTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket = request.data.get('service_ticket')
        application_id = request.data.get('application_id')

        try:
            # Retrieve the application
            application = Application.objects.get(id=application_id)

            # Validate the ticket
            ticket = ServiceTicket.validate_ticket(service_ticket, application)

            # Check if the ticket is expired or consumed
            if ticket.is_expired:
                return Response({'error': 'Ticket expired'}, status=status.HTTP_400_BAD_REQUEST)
            if ticket.is_consumed:
                return Response({'error': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            # Consume the ticket
            ticket.consume()
            user = ticket.user

            try:
                user_role = UserRole.objects.get(user=user, application=application)
            except UserRole.DoesNotExist:
                return Response({"error": "User does not have access to this application"},
                                status=status.HTTP_403_FORBIDDEN)

            return Response({
                'username': user.username,
                'roles': user_role.role.name,
                'permissions': {
                    'can_create': user_role.can_create,
                    'can_read': user_role.can_read,
                    'can_update': user_role.can_update,
                    'can_delete': user_role.can_delete
                }
            }, status=status.HTTP_200_OK)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_400_BAD_REQUEST)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import ServiceTicketValidationSerializer
from .models import Application, ServiceTicket, UserRole

class ValidateServiceTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        # Use the serializer to validate incoming data
        serializer = ServiceTicketValidationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Extract validated data
        service_ticket = serializer.validated_data.get('service_ticket')
        application_id = serializer.validated_data.get('application_id')

        try:
            # Retrieve the application
            application = Application.objects.get(id=application_id)

            # Validate the service ticket against the application
            ticket = ServiceTicket.validate_ticket(service_ticket, application)

            # Check if the ticket is expired or consumed
            if ticket.is_expired:
                return Response({'error': 'Ticket expired'}, status=status.HTTP_400_BAD_REQUEST)
            if ticket.is_consumed:
                return Response({'error': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            # Consume the ticket (mark it as used)
            ticket.consume()
            user = ticket.user

            # Check if the user has access to this application via a role
            try:
                user_role = UserRole.objects.get(user=user, application=application)
            except UserRole.DoesNotExist:
                return Response({"error": "User does not have access to this application"},
                                status=status.HTTP_403_FORBIDDEN)

            # Return user details and permissions
            return Response({
                'username': user.username,
                'roles': user_role.role.name,
                'permissions': {
                    'can_create': user_role.can_create,
                    'can_read': user_role.can_read,
                    'can_update': user_role.can_update,
                    'can_delete': user_role.can_delete
                }
            }, status=status.HTTP_200_OK)

        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


from django.db import models
from accounts.models import CustomUser
from roles.models import Application
import random
import string
from django.utils import timezone


class TicketManager(models.Manager):
    def create_ticket(self, user, application, **kwargs):
        ticket_str = self.create_ticket_str()
        expires = timezone.now() + timezone.timedelta(minutes=self.model.TICKET_EXPIRE)
        return self.create(ticket=ticket_str, user=user, application=application, expires=expires, **kwargs)

    def create_ticket_str(self, prefix=None):
        prefix = prefix or self.model.TICKET_PREFIX
        random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=self.model.TICKET_RAND_LEN))
        timestamp = int(timezone.now().timestamp())
        return f"{prefix}-{timestamp}-{random_part}"

    def validate_ticket(self, ticket, application):
        try:
            t = self.get(ticket=ticket)
        except self.model.DoesNotExist:
            raise ValueError("Invalid ticket")

        if t.is_consumed:
            raise ValueError("Ticket already consumed")
        if t.is_expired:
            raise ValueError("Ticket expired")
        if t.application != application:
            raise ValueError("Invalid application")

        return t


class Ticket(models.Model):
    TICKET_EXPIRE = 90  # Expiry time in minutes
    TICKET_RAND_LEN = 32
    TICKET_PREFIX = 'T'

    ticket = models.CharField(max_length=255, unique=True, db_index=True)  # Indexed for faster queries
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    expires = models.DateTimeField()
    consumed = models.DateTimeField(null=True, blank=True)

    objects = TicketManager()

    @property
    def is_expired(self):
        return timezone.now() > self.expires

    @property
    def is_consumed(self):
        return self.consumed is not None

    def consume(self):
        self.consumed = timezone.now()
        self.save()

    def __str__(self):
        return f"Ticket {self.ticket} for user {self.user.username}"


class ServiceTicket(Ticket):
    TICKET_PREFIX = 'ST'
    primary = models.BooleanField(default=False)

    def __str__(self):
        return f"ServiceTicket {self.ticket}"


class ProxyTicket(Ticket):
    TICKET_PREFIX = 'PT'
    granted_by_pgt = models.ForeignKey('ProxyGrantingTicket', on_delete=models.CASCADE)

    def __str__(self):
        return f"ProxyTicket {self.ticket}"


class ProxyGrantingTicket(Ticket):
    TICKET_PREFIX = 'PGT'
    IOU_PREFIX = 'PGTIOU'

    iou = models.CharField(max_length=255, unique=True, db_index=True)  # Indexed for faster queries
    granted_by_st = models.ForeignKey('ServiceTicket', null=True, blank=True, on_delete=models.PROTECT)
    granted_by_pt = models.ForeignKey('ProxyTicket', null=True, blank=True, on_delete=models.PROTECT)

    def __str__(self):
        return f"ProxyGrantingTicket {self.ticket}"


class UserSession(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    session_key = models.CharField(max_length=255, unique=True, db_index=True)  # Indexed for faster session lookup
    created_at = models.DateTimeField(auto_now_add=True)
    last_accessed = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    def is_expired(self):
        return timezone.now() > self.expires_at

    def expire(self):
        self.is_active = False
        self.save()

    def __str__(self):
        return f"Session {self.session_key} for user {self.user.username}"
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from .models import UserSession, ServiceTicket, ProxyGrantingTicket
from roles.models import Application
from .serializers import LoginSerializer

class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if serializer.is_valid():
            username = serializer.validated_data.get('username')
            password = serializer.validated_data.get('password')
            application_id = serializer.validated_data.get('application_id')

            # Ensure username, password, and application_id are present
            if not username or not password or not application_id:
                return Response({"error": "All fields are required: username, password, and application_id"},
                                status=status.HTTP_400_BAD_REQUEST)

            # Authenticate the user
            user = authenticate(username=username, password=password)
            if user is not None:
                try:
                    # Validate the application is active and exists
                    application = Application.objects.get(id=application_id, active=True)
                except Application.DoesNotExist:
                    return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)

                # Update the user's last login time
                user.last_login = timezone.now()
                user.save()

                # Generate JWT tokens
                refresh = RefreshToken.for_user(user)

                # Create a user session
                session_key = UserSession.create_ticket_str()
                expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
                user_session = UserSession.objects.create(
                    user=user,
                    application=application,
                    session_key=session_key,
                    expires_at=expires_at
                )

                # Generate Service Ticket
                service_ticket = ServiceTicket.objects.create_ticket(user=user, application=application)

                # Optionally, generate a Proxy Granting Ticket (PGT)
                pgt = ProxyGrantingTicket.objects.create_ticket(user=user, application=application)

                # Response data with JWT, session, and service tickets
                response_data = {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'session_key': user_session.session_key,
                    'session_expires_at': user_session.expires_at,
                    'service_ticket': service_ticket.ticket,
                    'proxy_granting_ticket': pgt.ticket,
                }

                return Response(response_data, status=status.HTTP_200_OK)

            # Handle invalid credentials
            return Response({"error": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)

        # Handle serializer validation errors
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import ServiceTicket, UserRole, Application
from .serializers import ServiceTicketValidationSerializer

class ValidateServiceTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        # Use the serializer to validate incoming data
        serializer = ServiceTicketValidationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Extract validated data
        service_ticket_str = serializer.validated_data.get('service_ticket')
        application_id = serializer.validated_data.get('application_id')

        try:
            # Retrieve the application
            application = Application.objects.get(id=application_id)

            # Validate the service ticket against the application
            ticket = ServiceTicket.validate_ticket(service_ticket_str, application)

            # Check if the ticket is expired or consumed
            if ticket.is_expired:
                return Response({'error': 'Ticket expired'}, status=status.HTTP_400_BAD_REQUEST)
            if ticket.is_consumed:
                return Response({'error': 'Ticket already consumed'}, status=status.HTTP_400_BAD_REQUEST)

            # Consume the ticket (mark it as used)
            ticket.consume()
            user = ticket.user

            # Check if the user has access to this application via a role
            try:
                user_role = UserRole.objects.get(user=user, application=application)
                permissions = {
                    'can_create': user_role.can_create,
                    'can_read': user_role.can_read,
                    'can_update': user_role.can_update,
                    'can_delete': user_role.can_delete
                }
                return Response({
                    'username': user.username,
                    'roles': user_role.role.name,
                    'permissions': permissions
                }, status=status.HTTP_200_OK)

            except UserRole.DoesNotExist:
                return Response({"error": "User does not have access to this application"},
                                status=status.HTTP_403_FORBIDDEN)

        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

import secrets
from django.utils import timezone
from django.conf import settings

class UserSession(models.Model):
    TICKET_EXPIRE = 60  # Session expires in 60 minutes (you can adjust this value)

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    session_key = models.CharField(max_length=255, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_accessed = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    @staticmethod
    def create_ticket_str():
        return secrets.token_urlsafe(32)

    def is_expired(self):
        return timezone.now() > self.expires_at

    def expire(self):
        self.is_active = False
        self.save()

    def __str__(self):
        return f"Session {self.session_key} for user {self.user.username}"
