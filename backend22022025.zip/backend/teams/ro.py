from datetime import timezone

from django.shortcuts import render
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication

from .models import *
from .serializers import *
from rest_framework.permissions import IsAuthenticated
# Create your views here.


# Team Views
class AllTeamListAPIView(generics.ListAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList

class UserTeamsView(generics.ListAPIView):
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Get the current user
        user = self.request.user
        # Filter teams based on membership
        return Team.objects.filter(users=user)

class CreatedTeamsView(generics.ListAPIView):
    serializer_class = TeamSerializerList
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Get the current user
        user = self.request.user
        # Filter teams where the user is the creator
        return Team.objects.filter(created_by=user)




class TeamCreateAPIView(generics.CreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)


class TeamRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer



class TeamMembersAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            team = Team.objects.get(pk=pk)
            memberships = TeamMembership.objects.filter(team=team)
            serializer = TeamMembershipSerializer(memberships, many=True)
            return Response(serializer.data)
        except Team.DoesNotExist:
            return Response({'error': 'Team not found'}, status=status.HTTP_404_NOT_FOUND)

# Team Membership Views
class TeamMembershipListCreateAPIView(generics.ListAPIView):
    queryset = TeamMembership.objects.all()
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

class TeamMembershipRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TeamMembership.objects.all()
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            memberships = TeamMembership.objects.filter(team=pk)
            serializer = TeamMembershipSerializer(memberships, many=True)
            return Response(serializer.data)
        except TeamMembership.DoesNotExist:
            return Response({'error': 'TeamMembership not found'}, status=status.HTTP_404_NOT_FOUND)

# # Team Invite Views
# class TeamInviteListCreateAPIView(generics.ListCreateAPIView):
#     queryset = TeamInvite.objects.all()
#     serializer_class = TeamInviteSerializer
#     permission_classes = [IsAuthenticated]
#
# class TeamInviteRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = TeamInvite.objects.all()
#     serializer_class = TeamInviteSerializer
#     permission_classes = [IsAuthenticated]
#
#     def post(self, request, pk):
#         try:
#             invite = TeamInvite.objects.get(pk=pk)
#             status = request.data.get('status')
#             if status in ['Accepted', 'Declined']:
#                 invite.status = status
#                 invite.responded_at = timezone.now()
#                 invite.save()
#                 return Response({'status': 'Invitation responded'})
#             return Response({'error': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)
#         except TeamInvite.DoesNotExist:
#             return Response({'error': 'TeamInvite not found'}, status=status.HTTP_404_NOT_FOUND)
#
# # Team Notification Views
# class TeamNotificationListCreateAPIView(generics.ListCreateAPIView):
#     queryset = TeamNotification.objects.all()
#     serializer_class = TeamNotificationSerializer
#     permission_classes = [IsAuthenticated]
#
# class TeamNotificationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = TeamNotification.objects.all()
#     serializer_class = TeamNotificationSerializer
#     permission_classes = [IsAuthenticated]
#
#     def get(self, request, pk):
#         try:
#             notifications = TeamNotification.objects.filter(team=pk)
#             serializer = TeamNotificationSerializer(notifications, many=True)
#             return Response(serializer.data)
#         except TeamNotification.DoesNotExist:
#             return Response({'error': 'TeamNotification not found'}, status=status.HTTP_404_NOT_FOUND)
---------

from rest_framework import generics
from .models import Team, Application, AuditLogEntry
from rest_framework.permissions import IsAuthenticated
from .serializers import TeamSerializerList
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.contenttypes.models import ContentType
from .models import ActionType
from django.utils.timezone import now

class TeamCreateView(generics.CreateAPIView):
    """
    View to create a new team and capture the action in audit logs.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        team = serializer.save()
        # Capture the create action in the log
        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_type=content_type,
            object_id=str(team.id),
            details=f"Created team with name {team.name}"
        )
        return team
class TeamUpdateView(generics.UpdateAPIView):
    """
    View to update an existing team and capture the action in audit logs.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        team = serializer.save()
        # Capture the update action in the log
        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_type=content_type,
            object_id=str(team.id),
            details=f"Updated team with name {team.name}"
        )
        return team

class TeamDeleteView(generics.DestroyAPIView):
    """
    View to delete a team and capture the action in audit logs.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_destroy(self, instance):
        team_name = instance.name
        super().perform_destroy(instance)
        # Capture the delete action in the log
        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_type=content_type,
            object_id=str(instance.id),
            details=f"Deleted team with name {team_name}"
        )


class TeamMembersView(generics.ListAPIView):
    """
    View to get all the members of a specific team and capture the action in audit logs.
    """
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        team_id = self.kwargs['team_id']
        return Team.objects.get(id=team_id).users.all()

    def list(self, request, *args, **kwargs):
        team_id = kwargs.get('team_id')
        # Capture the read action in the log
        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            object_id=team_id,
            details=f"Fetched members of team with ID {team_id}"
        )
        return super().list(request, *args, **kwargs)


class AllTeamListView(generics.ListAPIView):
    """
    To get all the teams that are created and capture the action in audit logs.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of teams"
        )
        return super().list(request, *args, **kwargs)
---
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Team, CustomUser, TeamMembership, ActionType, Application
from django.db.models import Count
from django.contrib.contenttypes.models import ContentType
from django.utils.timezone import now
from .serializers import TeamSerializerList
from rest_framework_simplejwt.authentication import JWTAuthentication
from .models import AuditLogEntry

class AllTeamListView(generics.ListAPIView):
    """
    View to get a list of all teams along with the total number of members and leaders.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        # First, we annotate the teams with the count of members and leaders
        teams = Team.objects.annotate(
            total_members=Count('users', distinct=True),  # Count total users in the team
            total_leaders=Count('teammembership', filter=TeamMembership.objects.filter(role='Leader'), distinct=True)  # Count total leaders in the team
        )

        # Capture the READ action in the log
        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of teams with member and leader counts"
        )

        # Serialize the teams data and include the additional counts
        team_data = []
        for team in teams:
            serialized_team = TeamSerializerList(team).data
            serialized_team['total_members'] = team.total_members
            serialized_team['total_leaders'] = team.total_leaders
            team_data.append(serialized_team)

        return Response(team_data)
-----
from django.db import transaction
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.contenttypes.models import ContentType
from django.utils.timezone import now
from audit.models import AuditLogEntry, ActionType
from roles.models import Application
from .models import *
from .serializers import TeamSerializer


class TeamCreateView(generics.CreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        with transaction.atomic():
            team = serializer.save(created_by=self.request.user)
            try:
                TeamMembership.objects.get_or_create(
                    team=team,
                    user=self.request.user,
                    role='Leader',
                )
            except Exception as e:
                raise ValidationError(f"Error creating team membership: {str(e)}")

            application_name = self.request.headers.get('X-Application-Name', 'Unknown')
            try:
                application = Application.objects.get(name=application_name)
            except Application.DoesNotExist:
                application = Application.objects.first()  # Default application if not found

            content_type = ContentType.objects.get_for_model(Team)
            AuditLogEntry.objects.create(
                user=self.request.user,
                application=application,
                action_type=ActionType.CREATE,
                object_type=content_type,
                object_id=str(team.id),
                details=f"Created team with name {team.name}"
            )
        return team


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from django.contrib.contenttypes.models import ContentType
from audit.models import AuditLogEntry, ActionType
from roles.models import Application
from .models import Team
from .serializers import TeamSerializer


class TeamListView(generics.ListAPIView):
    """
    View to list teams related to the authenticated user.
    The user must be either a 'Leader' or 'Member' of the team to see the team.
    """
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = PageNumberPagination  # Optional: Add pagination

    def get_queryset(self):
        user = self.request.user  # The authenticated user making the request

        # Fetch the teams the user is part of (either as Leader or Member)
        queryset = Team.objects.filter(
            teammembership__user=user
        ).distinct()  # Avoid duplicate teams

        # Log the read action in AuditLogEntry
        self.log_audit(user, queryset)

        return queryset

    def log_audit(self, user, queryset):
        """
        Logs an audit entry whenever the user reads the list of teams.
        """
        # Get the application name from headers (or default to 'Unknown' if not provided)
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Default application if not found

        # Content type for the Team model
        content_type = ContentType.objects.get_for_model(Team)

        # Create the AuditLogEntry
        AuditLogEntry.objects.create(
            user=user,
            application=application,
            action_type=ActionType.READ,
            object_type=content_type,
            object_id='all',  # As we are reading the list, we can set the object_id to 'all'
            details=f"User viewed the list of teams"
        )
-----
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from .models import Team
from .serializers import TeamSerializer

class TeamDetailView(generics.RetrieveAPIView):
    """
    View to retrieve the details of a specific team.
    The user must be either a 'Leader' or 'Member' of the team to view the details.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        team_id = self.kwargs.get('pk')
        team = Team.objects.filter(id=team_id).first()
        if team and self.request.user in team.users.all():
            return team
        raise PermissionDenied("You do not have permission to view this team.")


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from .models import Team, TeamMembership
from .serializers import TeamMembershipSerializer

class TeamAddUserView(generics.CreateAPIView):
    """
    View to add a user to a team.
    The user must be a 'Leader' of the team to add other users.
    """
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        team = serializer.validated_data['team']
        user_to_add = serializer.validated_data['user']
        user_role = serializer.validated_data.get('role', 'Member')

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to add users.")

        # Create team membership
        membership = TeamMembership.objects.create(
            team=team,
            user=user_to_add,
            role=user_role
        )
        return membership


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from .models import Team, TeamMembership


class TeamRemoveUserView(generics.DestroyAPIView):
    """
    View to remove a user from a team.
    Only the team leader can remove members.
    """
    permission_classes = [IsAuthenticated]

    def get_object(self):
        team_id = self.kwargs.get('team_id')
        user_id = self.kwargs.get('user_id')
        team = Team.objects.filter(id=team_id).first()
        if not team:
            raise NotFound("Team not found.")
        membership = TeamMembership.objects.filter(team=team, user_id=user_id).first()
        if not membership:
            raise NotFound("User not found in this team.")

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to remove users.")

        return membership


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import Team
from .serializers import TeamSerializer

class TeamUpdateView(generics.UpdateAPIView):
    """
    View to update the details of a team.
    Only the team leader can update team details.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        team = serializer.instance
        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to update team details.")
        serializer.save()


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from .models import Team, TeamInvite
from .serializers import TeamInviteSerializer

class TeamInviteUserView(generics.CreateAPIView):
    """
    View to send an invitation to a user to join a team.
    Only the team leader can send invites.
    """
    serializer_class = TeamInviteSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        team = serializer.validated_data['team']
        invitee = serializer.validated_data['invitee']

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to invite users.")

        invite = TeamInvite.objects.create(
            team=team,
            invited_by=self.request.user,
            invitee=invitee,
            status='Pending'
        )
        return invite
------
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import Team
from .serializers import TeamSerializer

class TeamDetailsView(generics.RetrieveUpdateDestroyAPIView):
    """
    View to retrieve, update, or delete a team.
    Only the team leader can update or delete the team.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        team_id = self.kwargs.get('pk')
        team = Team.objects.filter(id=team_id).first()
        if team and self.request.user in team.users.all():
            return team
        raise PermissionDenied("You do not have permission to view or modify this team.")

    def perform_update(self, serializer):
        # Ensure that only the team leader can update the team
        team = serializer.instance
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to update the team details.")
        serializer.save()

    def perform_destroy(self, instance):
        # Ensure that only the team leader can delete the team
        if not instance.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to delete the team.")
        instance.delete()
--------
from rest_framework import generics
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated
from django.contrib.contenttypes.models import ContentType
from django.utils.timezone import now
from .models import Team
from .serializers import TeamSerializer
from audit.models import AuditLogEntry, ActionType
from roles.models import Application


class TeamDetailsView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        # Get the application; if not found, handle appropriately
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Team: {instance.name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        team = serializer.instance
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to update the team details.")

        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(team.id),
            object_type=content_type,
            content_object=team,
            details=f"Updated Team: {team.name}"
        )

        super().perform_update(serializer)  # Let the parent class perform the update

    def perform_destroy(self, instance):
        if not instance.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to delete the team.")

        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Team: {instance.name}"
        )

        super().perform_destroy(instance)  # Let the parent class perform the delete
-------


class TeamAddUserView(generics.CreateAPIView):
    """
    View to add a user to a team.
    The user must be a 'Leader' of the team to add other users.
    """
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        team = serializer.validated_data['team']
        user_to_add = serializer.validated_data['user']
        user_role = serializer.validated_data.get('role', 'Member')

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to add users.")

        # Ensure the user is not already a member of the team
        if TeamMembership.objects.filter(team=team, user=user_to_add).exists():
            raise PermissionDenied(f"User {user_to_add.username} is already a member of the team.")

        # Create team membership
        membership = TeamMembership.objects.create(
            team=team,
            user=user_to_add,
            role=user_role
        )

        # Get application name from headers
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(TeamMembership)
        # Log the action in AuditLogEntry
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(membership.id),
            object_type=content_type,
            content_object=membership,
            details=f"Added new Team member: {membership.user.username} to {membership.team.name} team"
        )

        return membership


from rest_framework.exceptions import PermissionDenied
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from django.utils.timezone import now
from django.contrib.contenttypes.models import ContentType
from .models import TeamMembership, Team
from .serializers import TeamMembershipSerializer
from audit.models import AuditLogEntry, ActionType
from roles.models import Application


class TeamRemoveUserView(generics.DestroyAPIView):
    """
    View to remove a user from a team.
    The user must be the 'Leader' of the team to remove other users.
    """
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def perform_destroy(self, instance):
        team = instance.team
        user_to_remove = instance.user

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to remove users.")

        # Check if the user to be removed exists in the team
        if not team.users.filter(id=user_to_remove.id).exists():
            raise PermissionDenied(f"User {user_to_remove.username} is not a member of the team.")

        # Delete the TeamMembership instance to remove the user from the team
        instance.delete()

        # Get application name from headers
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(TeamMembership)
        # Log the action in AuditLogEntry
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Removed Team member: {user_to_remove.username} from {team.name} team"
        )

        return instance
