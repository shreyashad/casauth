from email.policy import default

from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from .models import *


class TeamMembershipSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())
    role = serializers.ChoiceField(choices=[('Leader', 'Leader'), ('Member', 'Member')], default='Member')
    joined_at = serializers.DateTimeField(read_only=True)

    class Meta:
        model = TeamMembership
        fields = ['user', 'role', 'joined_at']

    def create(self, validated_data):
        team = validated_data['team']
        user = validated_data['user']
        role = validated_data.get('role', 'Member')

        try:
            user_instance = CustomUser.objects.get(id=user)
        except CustomUser.DoseNotExist:
            raise ValidationError(f"User with ID {user} does not exist")

        membership, created = TeamMembership.objects.create(
            team=team, user=user_instance, defaults={'role': role}
        )
        if not created:
            membership.role = role  # Update the role if membership already exists
            membership.save()

        return membership

class TeamSerializer(serializers.ModelSerializer):
    users = TeamMembershipSerializer(many=True, required=False)  # Users as members

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'users']

    def create(self, validated_data):
        users_data = validated_data.pop('users',[])
        team = Team.objects.create(**validated_data)
        for user_data in users_data:
            TeamMembership.objects.create(team=team, **user_data)
        return team