from django.contrib.contenttypes.models import ContentType
from django.db.models import Count
from rest_framework import generics
from rest_framework.exceptions import ValidationError, PermissionDenied
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.utils.timezone import now
from audit.models import AuditLogEntry, ActionType
from roles.models import Application
from .models import *
from .serializers import *
from django.db import transaction


# Create your views here.


class TeamCreateView(generics.CreateAPIView):
    """
            View to create a new team and capture the action in audit logs.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        with transaction.atomic():
            team = serializer.save(created_by=self.request.user)
            try:
                TeamMembership.objects.get_or_create(
                    team=team,
                    user=self.request.user,
                    role='Leader',
                )
            except Exception as e:
                raise ValidationError(f"Error creating team membership: {str(e)}")

            application_name = self.request.headers.get('X-Application-Name','Unknown')
            try:
                application = Application.objects.get(name=application_name)
            except Application.DoesNotExist:
                application = Application.objects.first()

            content_type = ContentType.objects.get_for_model(Team)
            AuditLogEntry.objects.create(
                user=self.request.user,
                application=application,
                action_type=ActionType.CREATE,
                timestamp=now(),
                object_type=content_type,
                object_id=str(team.id),
                details=f"Created team with name {team.name}"
            )
        return team

class TeamListViewForUser(generics.ListAPIView):
    """
        View to list teams related to the authenticated user.
        The user must be either a 'Leader' or 'Member' of the team to see the team.
    """
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        queryset = Team.objects.filter(
            teammembership__user=user
        ).distinct()

        self.log_audit(user, queryset)
        return queryset

    def log_audit(self, user, queryset):
        """
        Logs an audit entry whenever the user reads the list of teams.
        """
        # Get the application name from headers (or default to 'Unknown' if not provided)
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Default application if not found

        # Content type for the Team model
        content_type = ContentType.objects.get_for_model(Team)

        # Create the AuditLogEntry
        AuditLogEntry.objects.create(
            user=user,
            application=application,
            action_type=ActionType.READ,
            object_type=content_type,
            object_id='all',  # As we are reading the list, we can set the object_id to 'all'
            details=f"User viewed the list of teams"
        )

class TeamDetailsView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        # Get the application; if not found, handle appropriately
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Team: {instance.name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        team = serializer.instance
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to update the team details.")

        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(team.id),
            object_type=content_type,
            content_object=team,
            details=f"Updated Team: {team.name}"
        )

        super().perform_update(serializer)  # Let the parent class perform the update

    def perform_destroy(self, instance):
        if not instance.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to delete the team.")

        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(Team)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Team: {instance.name}"
        )

        super().perform_destroy(instance)  # Let the parent class perform the delete


class TeamAddUserView(generics.CreateAPIView):
    """
        View to add a user to a team.
        The user must be a 'Leader' of the team to add other users.
        """
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        team = serializer.validated_data['team']
        user_to_add = serializer.validated_data['user']
        user_role = serializer.validated_data.get('role', 'Member')

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to add users.")
        # Ensure the user is not already a member of the team
        if TeamMembership.objects.filter(team=team, user=user_to_add).exists():
            raise PermissionDenied(f"User {user_to_add.username} is already a member of the team.")

        # Create team membership
        membership = TeamMembership.objects.create(
            team=team,
            user=user_to_add,
            role=user_role
        )
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')

        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(TeamMembership)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(membership.id),
            object_type=content_type,
            content_object=membership,
            details=f"Added new Team member: {membership.user.username} to {membership.team.name} team"
        )

        return membership


class TeamRemoveUserView(generics.DestroyAPIView):
    """
    View to remove a user from a team.
    The user must be the 'Leader' of the team to remove other users.
    """
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def perform_destroy(self, instance):
        team = instance.team
        user_to_remove = instance.user

        # Check if the requesting user is the 'Leader' of the team
        if not team.users.filter(id=self.request.user.id, teammembership__role='Leader').exists():
            raise PermissionDenied("You must be the team leader to remove users.")

        # Check if the user to be removed exists in the team
        if not team.users.filter(id=user_to_remove.id).exists():
            raise PermissionDenied(f"User {user_to_remove.username} is not a member of the team.")

        # Delete the TeamMembership instance to remove the user from the team
        instance.delete()

        # Get application name from headers
        application_name = self.request.headers.get('X-Application-Name', 'Unknown')
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            application = Application.objects.first()  # Fallback to the first application

        content_type = ContentType.objects.get_for_model(TeamMembership)
        # Log the action in AuditLogEntry
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Removed Team member: {user_to_remove.username} from {team.name} team"
        )

        return instance
