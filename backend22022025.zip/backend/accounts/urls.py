from tkinter.font import names

from django.urls import path
from .views import *

urlpatterns = [

    path('register/',UserRegistrationView.as_view(),name='register'),
    path('user-profile/', UserProfileDetailView.as_view(), name='user-profile-detail'),
    path('user-account/', UserAccountDetailsView.as_view(), name='user-account-detail'),
    path('password-reset-request/', PasswordResetRequestView.as_view(), name='password-reset-request'),
    path('reset-password/', PasswordResetView.as_view(), name='rest-password'),
    path('password-expired/', ChangePasswordForUnauthenticatedUserView.as_view(), name='password-expired'),

    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('admin-user-list/', UserListView.as_view(), name='user-list-administrator'),
    path('admin-user-details/<uuid:pk>/', UserDetailView.as_view(), name='user-details-administrator'),
    path('administrator-user-list/', ListAdministratorsView.as_view(), name='administrator-user-list'),
    path('authenticator-user-list/', ListAuthenticatorsView.as_view(), name='authenticator-user-list'),
    path('site-admin-user-list/', ListSiteAdminsView.as_view(), name='site-admin-user-list'),
    path('revoke-role/', RevokeRolesView.as_view(), name='revoke-role'),
    path('assign-filter-authenticator/', FilterSettingsDetailView.as_view(), name='assign-filter-authenticator'),
    path('authenticator-user-list/', AuthenticatorFilteredUserListView.as_view(), name='authenticator-user-list'),
    path('online-user-count/', OnlineUserCountView.as_view(), name='online-user-count'),
    path('total-users-count/', TotalUserCountView.as_view(), name='total_user_count'),
    path('admin-user-count/', AdministratorUserCountView.as_view(), name='admin_user_count'),
    path('authenticator-user-count/', AuthenticatorUserCountView.as_view(), name='authenticator_user_count'),
    path('site-admin-user-count/', SiteAdminUserCountView.as_view(), name='site-admin-user-count'),
    path('user-count-role-app/', UserCountViewByRoleApp.as_view(), name='user_count_role_app/'),
    path('unverified-users-count/', VerificationPendingCountView.as_view(), name='unverified_users'),
    path('similar-department-users/', SimilarDepartmentUsersView.as_view(), name='similar-department-users'),
]