from django.urls import resolve
from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse
from django.utils import timezone
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny

from cas.models import UserSession, ServiceTicket
from roles.models import Application, UserRole
from .models import  CustomUser

class PasswordExpiryMiddleware(MiddlewareMixin):
    """
    Middleware to check if the user's password has expired.
    If expired, the user will be asked to change their password before proceeding.
    """

    def process_request(self, request):
        """Skip password expiry check for open API views"""

        # Skip for unauthenticated users
        if not request.user.is_authenticated:
            return None

        # Get the current view function
        resolver_match = resolve(request.path)
        view_func = resolver_match.func

        # Skip check if the view allows any user (open API)
        if hasattr(view_func, "cls") and hasattr(view_func.cls, "permission_classes"):
            if AllowAny in view_func.cls.permission_classes:
                return None  # Skip the middleware

        # Fetch user's password expiry date
        password_expiry_date = getattr(request.user, "password_expiry_date", None)

        # Check if password is expired
        if password_expiry_date and password_expiry_date < timezone.now():
            return JsonResponse(
                {"error": "Your password has expired. Please reset your password."},
                status=403
            )

        return None  # Allow request if password is valid

