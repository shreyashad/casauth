import uuid
import json
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import BaseUserManager,AbstractBaseUser,PermissionsMixin
from django.contrib.auth.hashers import check_password, make_password
from phonenumber_field.modelfields import PhoneNumberField
from django.conf import settings
from datetime import timedelta


# Create your models here.
def user_directory_path(instance, filename):
    return f'user_{instance.user.id}/{filename}'


class GenderChoice(models.TextChoices):
    MALE = 'Male', 'Male'
    FEMALE = 'Female', 'Female'
    OTHERS = 'Others', 'Others'

class CustomUserManager(BaseUserManager):
    def create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError('The Username must be set')
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(username, password, **extra_fields)



class CustomUser(AbstractBaseUser,PermissionsMixin):
    id = models.UUIDField(
        default=uuid.uuid4, unique=True, editable=False, db_index=True, primary_key=True
    )
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    org_type = models.CharField(max_length=150)
    org_name = models.CharField(max_length=250)
    org_sub_type = models.CharField(max_length=150)
    location_type = models.CharField(max_length=150)
    location_name = models.CharField(max_length=250)
    location_code = models.CharField(max_length=150)
    emp_code = models.CharField(max_length=150)
    department = models.CharField(max_length=250,blank=True, null=True)
    designation = models.CharField(max_length=250)
    mobile = PhoneNumberField(null=False, blank=False, unique=True)
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=128)
    assigned_details = models.CharField(max_length=1000, blank=True, null=True)
    is_online = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    last_password_change = models.DateTimeField(null=True, blank=True)
    password_change_required = models.BooleanField(default=False)
    password_history_json = models.TextField(default='[]')
    password_reset_token = models.CharField(max_length=255, blank=True, null=True)
    token_expiration = models.DateTimeField(blank=True, null=True)
    password_expiry_days = models.IntegerField(default=60)

    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['mobile']

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        indexes = [
            models.Index(fields=['username']),
            models.Index(fields=['mobile']),
            models.Index(fields=['emp_code']),
            models.Index(fields=['org_type']),
            models.Index(fields=['org_name']),
            models.Index(fields=['org_sub_type']),
            models.Index(fields=['location_type']),
            models.Index(fields=['location_name']),
            models.Index(fields=['location_code']),
            models.Index(fields=['department']),
            models.Index(fields=['designation']),
        ]

    def is_password_expired(self):
        if not self.last_password_change:
            return False
        expiry_date = self.last_password_change + timedelta(days=self.password_expiry_days)
        return timezone.now() >= expiry_date

    def is_password_in_history(self, raw_password):
        password_history = json.loads(self.password_history_json)
        for hashed_password in password_history:
            if check_password(raw_password, hashed_password):
                return True
        return False

    def set_password(self, raw_password):
        if self.is_password_in_history(raw_password):
            raise ValidationError("The new password cannot be the same as any of the last 3 passwords.")

        # Set the new password and update history
        hashed_password = make_password(raw_password)
        super().set_password(raw_password)

        # Update password history
        password_history = json.loads(self.password_history_json)
        password_history.append(hashed_password)
        if len(password_history) > 3:
            password_history.pop(0)
        self.password_history_json = json.dumps(password_history)

        # Update the last password change time
        self.last_password_change = timezone.now()
        self.password_change_required = self.is_password_expired()

        super().save()

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        if self.password_change_required and not self.is_password_expired():
            self.password_change_required = False
        super().save(*args, **kwargs)





class BaseModel(models.Model):
    id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False, db_index=True, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="created at")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="last modified at")
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name="%(class)s_created_by",
                                   verbose_name="created by", null=True)
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name="%(class)s_updated_by",
                                   verbose_name="last modified by", null=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        if not self.pk:
            self.created_by = user
        self.updated_by = user
        super().save(*args, **kwargs)

    def __str__(self):
        created_by_str = self.created_by.username if self.created_by else "None"
        updated_by_str = self.updated_by.username if self.updated_by else "None"
        return f"ID: {self.id}, Created by: {created_by_str}, Updated by: {updated_by_str}"

def user_profile_picture_path(instance, filename):
    return f'profile_pictures/user_{instance.user.id}/{filename}'

class UserProfile(BaseModel):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    address = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=100, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    postal_code = models.CharField(max_length=20, blank=True, null=True)
    phone_number = PhoneNumberField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    profile_picture = models.ImageField(default='',upload_to=user_profile_picture_path, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    def __str__(self):
        return f'{self.user.username} Profile'

    class Meta:
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'






class AuthenticatorFilterSettings(BaseModel):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='filter_settings')
    filter_org_type = models.BooleanField(default=False)
    filter_org_name = models.BooleanField(default=False)
    filter_org_sub_type = models.BooleanField(default=False)
    filter_location_type = models.BooleanField(default=False)
    filter_location_name = models.BooleanField(default=False)
    filter_department = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'Authenticator Filter Settings'
        verbose_name_plural = 'Authenticator Filter Settings'

    def __str__(self):
        return f'{self.user.username} Filter Settings'


