import logging
from shutil import disk_usage
import uuid
import psutil
from celery import shared_task
from django.utils.timezone import now
from audit.models import SystemMetrics, Trace
from roles.models import Application
import logging

logger = logging.getLogger(__name__)
@shared_task
def capture_system_metrics():
    """
    Capture system metrics such as CPU usage, memory usage, disk usage, etc.
    asynchronously using Celery.
    """
    try:

        logger.info("Starting Celery task with parameters: %s, %s, %s, %s",)
        app_name ="Auth Server"
        application = Application.objects.get(name=app_name)

        # Gather system metrics
        cpu_usage = psutil.cpu_percent(interval=1)
        memory_info = psutil.virtual_memory()
        disk_usage = psutil.disk_usage('/')
        net_io = psutil.net_io_counters()

        # Save metrics to the database
        SystemMetrics.objects.create(
            application=application,
            cpu_usage=cpu_usage,
            memory_usage=memory_info.percent,
            disk_usage=disk_usage.percent,
            network_io={
                "bytes_sent": net_io.bytes_sent,
                "bytes_recv": net_io.bytes_recv
            },
            timestamp=now()
        )
        logging.Logger(f"System metrics captured for system_metrics {app_name}.")
        print(f"System metrics captured for {app_name}.")
    except Exception as e:
        print(f"Failed to capture system metrics: {str(e)}")




@shared_task
def log_trace(application_name, path, method):
    try:
        application, _ = Application.objects.get(name=application_name)
        Trace.objects.create(
            application=application,
            trace_id=str(uuid.uuid4()),
            path=path,
            method=method,
            timestamp=now()
        )
        print(f"Trace logged successfully for {method} {path} in {application_name}")
    except Exception as e:
        print(f"Failed to log trace: {str(e)}")