from django.urls import path
from .views import *

urlpatterns = [
    path('audit-logs-list', AuditLogListView.as_view(), name='audit-list'),
    path('audit/<uuid:pk>/details', AuditLogDetailView.as_view(), name='audit-details'),
    path('audit-log-entries/receive/', AuditLogEntryReceiverView.as_view(), name='audit-log-entry-receive'),
    path('user-application-status-chart/', UserApplicationStatusChartView.as_view(),
         name='user_application_status_chart'),
    path('online-users-by-application/', OnlineUsersByApplicationView.as_view(), name='online-users'),
    path('audit/capture_request_metrics/', RequestMetricsReceiverView.as_view(), name='capture_request_metrics'),
    path('audit/capture_log_metrics/',LogEntryReceiverView.as_view() , name='capture_log_metrics'),

    # for audit report of applications
    path('audit/application/<uuid:application_id>/metrics/', ApplicationMetricsAPIView.as_view(), name='application_metrics'),
    path("audit/metrics/total-requests/<uuid:application_id>/", TotalRequestsOverTimeView.as_view()),
    path("audit/metrics/top-endpoints/<uuid:application_id>/", MostAccessedEndpointsViews.as_view()),
    path("audit/metrics/status-codes/<uuid:application_id>/", StatusCodeDistributionView.as_view()),
    path("audit/metrics/slow-endpoints/<uuid:application_id>/", SlowestEndpointsView.as_view()),
    path("audit/metrics/request-methods/<uuid:application_id>/", RequestMethodDistributionView.as_view()),
    path("audit/metrics/error-trends/<uuid:application_id>/", ErrorTrendsView.as_view()),
    path("audit/system-metrics/current/<uuid:application_id>/", CurrentResourceUsageView.as_view(), name='current-resource-usage'),
    path("audit/system-metrics/trends/<uuid:application_id>/", ResourceUsageTrendsView.as_view(),
         name='resource-usage-trends'),
    path("audit/system-metrics/anomalies/<uuid:application_id>/", AnomalyDetectionView.as_view(),
         name='resource-usage-anomalies'),
    path("metrics/top-endpoints/", TopRequestsByEndpointView.as_view(), name="top-endpoints"),
    path("metrics/top-endpoints/<int:application_id>/", TopRequestsByEndpointView.as_view(),
         name="top-endpoints-by-application"),

]
