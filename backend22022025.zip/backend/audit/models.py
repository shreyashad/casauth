# audit/models.py
from django.db import models
from accounts.models import CustomUser
from cas.models import UserSession
from roles.models import Application
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey

# Create your models here.


class ActionType(models.TextChoices):
    ASSIGN_ROLE = 'Assign Role', 'Assign Role'
    REVOKE_ROLE = 'Revoke Role', 'Revoke Role'
    CREATE = 'Create', 'Create'
    UPDATE = 'Update', 'Update'
    DELETE = 'Delete', 'Delete'
    READ = 'Read', 'Read'
    LOGIN = 'Login', 'Login'
    LOGOUT = 'Logout', 'Logout'
    ERROR = 'Error', 'Error'
    CHANGED_PASSWORD = 'Changed password', 'Changed password'
    PROFILE_UPDATE = 'Update Profile', 'Update Profile'
    GENRATE_REPORT = 'Generate Report','Generate Report'
    DOWNLOAD_REPORT = 'Download Report', 'Download Report'

class AuditLogEntry(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    application = models.ForeignKey(Application,  on_delete=models.SET_NULL, null=True, related_name='audit_logs')
    action_type =models.CharField(max_length=50, choices=ActionType)
    timestamp = models.DateTimeField(auto_now_add=True)
    object_id = models.CharField(max_length=255)
    object_type = models.ForeignKey(ContentType, on_delete=models.SET_NULL, null=True, blank=True)
    content_object = GenericForeignKey('object_type', 'object_id')
    details = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.action_type} on {self.object_type} - {self.timestamp}"

    class Meta:
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['application']),
            models.Index(fields=['action_type']),
            models.Index(fields=['timestamp']),
        ]


class UserApplicationStatus(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    is_online = models.BooleanField(default=False)
    last_active = models.DateTimeField(auto_now=True)
    session = models.ForeignKey(UserSession, on_delete=models.CASCADE, null=True, blank=True)
    class Meta:
        unique_together = ('user', 'application')

    def __str__(self):
        return f"{self.user.username} - {self.application.name} - {'Online' if self.is_online else 'Offline'}"

    def update_status_on_session_expiry(self):
        """
        Update the user's application status when their session expires.
        If the session expires, mark them offline for the application.
        """
        if self.session.is_expired:
            self.is_online = False
            self.save()

            # Check if the user has any active sessions for other applications
            if not UserSession.objects.filter(user=self.user, is_active=True).exists():
                # If no active sessions exist, mark the user as offline globally
                self.user.is_online = False
                self.user.save()

class RequestMetrics(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    endpoint = models.CharField(max_length=2048)
    method = models.CharField(max_length=10)
    status_code = models.PositiveSmallIntegerField()
    duration = models.FloatField()
    metadata = models.JSONField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['application']),
            models.Index(fields=['status_code']),
            models.Index(fields=['timestamp']),
        ]

class LogEntry(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    level = models.CharField(max_length=50)
    message = models.TextField()
    metadata = models.JSONField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['application']),
            models.Index(fields=['level']),
            models.Index(fields=['timestamp']),
        ]


class SystemMetrics(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    cpu_usage = models.FloatField()
    memory_usage = models.FloatField()
    disk_usage = models.FloatField()
    network_io = models.JSONField()
    uptime = models.DurationField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['application']),  # Speeds up queries filtering by application
            models.Index(fields=['timestamp']),  # Optimizes sorting by latest metrics
            models.Index(fields=['cpu_usage']),  # Helps in CPU usage trend analysis
            models.Index(fields=['memory_usage']),  # Optimizes memory monitoring queries
            models.Index(fields=['disk_usage']),  # Helps in disk space trend analysis
        ]

class Trace(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    trace_id = models.CharField(max_length=100, db_index=True)
    path = models.CharField(max_length=200)
    method = models.CharField(max_length=10, db_index=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['application']),  # Optimize queries filtering by application
            models.Index(fields=['timestamp']),  # Optimize sorting by latest traces
            models.Index(fields=['trace_id']),  # Speeds up trace lookups
            models.Index(fields=['method']),  # Helps when filtering requests by HTTP method
        ]