from dateutil.utils import today
from django.db.models import Count
from django.shortcuts import render, get_object_or_404
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.db.models import Avg, Count, Sum
from django.db.models.functions import TruncDay, TruncHour
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.utils.timezone import now

# Create your views here.


class AuditLogListView(generics.ListAPIView):
    queryset = AuditLogEntry.objects.all().order_by('-timestamp')
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]

    # def get_queryset(self):
    #     """
    #     Optionally filter by user or application.
    #     """
    #     queryset = self.queryset
    #     user = self.request.query_params.get('user', None)
    #     application = self.request.query_params.get('application', None)
    #
    #     if user:
    #         queryset = queryset.filter(user__username=user)
    #     if application:
    #         queryset = queryset.filter(application__name=application)
    #
    #     return queryset


class AuditLogDetailView(generics.RetrieveAPIView):
    queryset = AuditLogEntry.objects.all()
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]



class AuditLogEntryReceiverView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        serializer = AuditLogReceiverSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # Extract validated data
        validated_data = serializer.validated_data

        # Get the application from application_name field
        application_name = validated_data.get('application_name')
        try:
            application = get_object_or_404(Application, name=application_name)
        except Application.DoesNotExist:
            return Response({"error": "Invalid application name."}, status=status.HTTP_404_NOT_FOUND)

        # Get the ContentType object if `object_type` is provided
        content_type = None
        if 'object_type' in validated_data:
            content_type = get_object_or_404(ContentType, model=validated_data['object_type'].lower())

        try:
            AuditLogEntry.objects.create(
                user=validated_data.get('user'),
                application=application,
                action_type=validated_data['action_type'],
                timestamp=now(),
                object_id=validated_data.get('object_id', None),
                object_type=content_type,
                details=validated_data.get('details', None),
            )
        except Exception as e:
            return Response(
                {"error": f"Failed to save audit log entry: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response({"message": "Audit log entry recorded successfully."}, status=status.HTTP_201_CREATED)



class UserApplicationStatusChartView(APIView):
    def get(self, request, *args, **kwargs):
        online_status = UserApplicationStatus.objects.filter(is_online=True) \
            .values('application__name') \
            .annotate(online_count=Count('id'))
        return Response(online_status, status=status.HTTP_200_OK)



class OnlineUsersByApplicationView(APIView):
    permission_classes = [AllowAny]
    def get(self, request, *args, **kwargs):
        application_name = request.query_params.get('application_name')

        if not application_name:
            return Response({"error": "Application name is required."}, status=status.HTTP_400_BAD_REQUEST)

        online_users = UserApplicationStatus.objects.filter(
            is_online=True,
            application__name=application_name
        ).values('user__username')  # Adjust this field based on how you want to represent users

        online_user_count = online_users.count()
        online_user_list = list(online_users)  # Convert to list if you want to return user details

        return Response({
            "application_name": application_name,
            "online_count": online_user_count,
            "online_users": online_user_list  # You can return usernames or other user details here
        }, status=status.HTTP_200_OK)



class RequestMetricsReceiverView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):

        # Validate the incoming data using the serializer
        serializer = RequestMetricsSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Extract validated data
        validated_data = serializer.validated_data
        application = Application.objects.get(name=validated_data['application_name'])

        # Create the RequestMetrics entry
        try:
            RequestMetrics.objects.create(
                application=application,
                endpoint=validated_data['endpoint'],
                method=validated_data['method'],
                status_code=validated_data['status_code'],
                duration=validated_data['duration'],
                metadata=validated_data.get('metadata', {}),

            )
        except Exception as e:
            return Response(
                {"error": f"Failed to save request metrics: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response({"message": "Request metrics recorded successfully."}, status=status.HTTP_201_CREATED)



class LogEntryReceiverView(APIView):

    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LogEntrySerializer(data=request.data)
        if not serializer.is_valid():
           return  Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # Extract validated data
        validated_data = serializer.validated_data
        application = Application.objects.get(name=validated_data['application_name'])

        # Create the LogEntry
        try:
           LogEntry.objects.create(
               application=application,
               level=validated_data['level'],
               message=validated_data['message'],
               metadata=validated_data.get('metadata', {}),
               timestamp=now(),
           )
        except Exception as e:
           return Response(
               {"error": f"Failed to save log entry: {str(e)}"},
               status=status.HTTP_500_INTERNAL_SERVER_ERROR,
           )

        return Response({"message": "Log entry created successfully."}, status=status.HTTP_201_CREATED)



class ApplicationMetricsAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


    def get(self, request, application_id):
        today = now().date()
        try:
            # total request for today
            total_requests = RequestMetrics.objects.filter(
                application=application_id,
                timestamp__date=today
            ).count()

            # Average Response Time for Today
            avg_response_time = RequestMetrics.objects.filter(
                application=application_id,
                timestamp__date=today
            ).aggregate(avg_duration=Avg('duration'))['avg_duration']

            # Total Logs for Today
            total_logs = LogEntry.objects.filter(
                application=application_id,
                timestamp__date=today
            ).count()

            # System Metrics (CPU, Memory, Disk) Latest
            latest_system_metrics = SystemMetrics.objects.filter(
                application=application_id
            ).order_by('-timestamp').first()

            # Response Data
            data = {
                'total_requests': total_requests,
                'avg_response_time': avg_response_time or 0,
                'total_logs': total_logs,
                'system_metrics': {
                    'cpu_usage': latest_system_metrics.cpu_usage if latest_system_metrics else 0,
                    'memory_usage': latest_system_metrics.memory_usage if latest_system_metrics else 0,
                    'disk_usage': latest_system_metrics.disk_usage if latest_system_metrics else 0,
                }
            }
            return Response(data)
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class TotalRequestsOverTimeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        granularity = request.query_params.get("granularity", "day")  # 'day' or 'hour'
        if granularity == "hour":
            time_trunc = TruncHour("timestamp")
        else:
            time_trunc = TruncDay("timestamp")

        data = (
            RequestMetrics.objects.filter(application_id=application_id)
            .annotate(time_bucket=time_trunc)
            .values("time_bucket")
            .annotate(total_requests=Count("id"))
            .order_by("time_bucket")
        )

        return Response(data)


class MostAccessedEndpointsViews(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        top_n = int(request.query_params.get("top", 10))

        data = (
            RequestMetrics.objects.filter(application_id=application_id)
            .values("endpoint")
            .annotate(request_count=Count("id"))
            .order_by("-request_count")[:top_n]
        )

        return Response(data)


class StatusCodeDistributionView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        data = (
            RequestMetrics.objects.filter(application_id=application_id)
            .values("status_code")
            .annotate(count=Count("id"))
            .order_by("status_code")
        )

        return Response(data)

class SlowestEndpointsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        top_n = int(request.query_params.get("top", 10))  # Default to top 10

        data = (
            RequestMetrics.objects.filter(application_id=application_id)
            .values("endpoint")
            .annotate(avg_duration=Avg("duration"))
            .order_by("-avg_duration")[:top_n]
        )

        return Response(data)

class RequestMethodDistributionView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        data = (
            RequestMetrics.objects.filter(application_id=application_id)
            .values("method")
            .annotate(request_count=Count("id"))
            .order_by("-request_count")
        )

        return Response(data)


class ErrorTrendsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        data = (
            RequestMetrics.objects.filter(application_id=application_id, status_code__gte=400)
            .annotate(day=TruncDay("timestamp"))
            .values("day")
            .annotate(error_count=Count("id"))
            .order_by("day")
        )

        return Response(data)


class CurrentResourceUsageView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        # Get the latest metrics for the application
        latest_metrics = SystemMetrics.objects.filter(application=application_id).order_by('-timestamp').first()

        if not latest_metrics:
            return Response({"error": "No metrics found for this application."}, status=404)

        data = {
            "cpu_usage": latest_metrics.cpu_usage,
            "memory_usage": latest_metrics.memory_usage,
            "disk_usage": latest_metrics.disk_usage,
            "network_io": latest_metrics.network_io,
            "timestamp": latest_metrics.timestamp,
        }
        return Response(data)


class ResourceUsageTrendsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        # Group metrics by hourly timestamp and calculate average usage
        trends = (
            SystemMetrics.objects.filter(application=application_id)
            .annotate(hour=TruncHour("timestamp"))
            .values("hour")
            .annotate(
                avg_cpu_usage=Avg("cpu_usage"),
                avg_memory_usage=Avg("memory_usage"),
                avg_disk_usage=Avg("disk_usage"),
            )
            .order_by("hour")
        )

        return Response(trends)


class AnomalyDetectionView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id):
        # Define thresholds for anomalies
        cpu_threshold = 90.0
        memory_threshold = 90.0
        disk_threshold = 90.0

        anomalies = SystemMetrics.objects.filter(
            application_id=application_id
        ).filter(
            cpu_usage__gte=cpu_threshold
        ).union(
            SystemMetrics.objects.filter(memory_usage__gte=memory_threshold)
        ).union(
            SystemMetrics.objects.filter(disk_usage__gte=disk_threshold)
        ).values(
            "timestamp", "cpu_usage", "memory_usage", "disk_usage"
        ).order_by("timestamp")

        return Response(list(anomalies))


class TopRequestsByEndpointView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, application_id=None):
        """
        Get the top 10 most accessed endpoints.
        If `application_id` is provided, filter by application.
        """
        queryset = RequestMetrics.objects.all()

        # Filter by application if application_id is provided
        if application_id:
            queryset = queryset.filter(application=application_id)

        # Aggregate the count of requests per endpoint
        top_endpoints = (
            queryset.values("endpoint")
            .annotate(count=Count("endpoint"))
            .order_by("-count")[:10]
        )

        # Serialize and return the data
        serializer = TopEndpointsSerializer(top_endpoints, many=True)
        return Response(serializer.data)
