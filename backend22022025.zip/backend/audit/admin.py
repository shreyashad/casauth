from django.contrib import admin
from .models import *

# Register your models here.


@admin.register(AuditLogEntry)
class AuditLogEntryAdmin(admin.ModelAdmin):
    list_display = ["user","application", "action_type","timestamp"]



@admin.register(UserApplicationStatus)
class UserApplicationStatusAdmin(admin.ModelAdmin):
    list_display = ["user","application", "is_online","last_active"]