from tkinter.font import names

from rest_framework import serializers
from .models import *
from roles.models import Application  # Adjust import based on your project structure


class AuditLogReceiverSerializer(serializers.Serializer):
    user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all(), required=False, allow_null=True)
    application_name = serializers.CharField()
    action_type = serializers.ChoiceField(choices=ActionType.choices)
    object_id = serializers.CharField(required=False, allow_blank=True)
    object_type = serializers.CharField(required=False, allow_blank=True)  # Optional, for GenericForeignKey
    details = serializers.CharField(required=False, allow_blank=True)


class AuditLogEntrySerializer(serializers.ModelSerializer):
    application = serializers.PrimaryKeyRelatedField(queryset=Application.objects.all())

    class Meta:
        model = AuditLogEntry
        fields = ['application', 'action_type', 'object_id', 'details']

    def validate(self, data):
        # Additional validation if needed
        return data

    def create(self, validated_data):
        # Assuming user is available in context
        user = self.context['request'].user  # Adjust based on your authentication setup

        audit_log = AuditLogEntry.objects.create(
            user=user,
            action_type=validated_data['action_type'],
            object_id=validated_data['object_id'],
            application=validated_data['application'],
            details=validated_data.get('details'),
        )
        return audit_log


class AuditLogSerializer(serializers.ModelSerializer):
    # Serializing related fields
    application_name = serializers.CharField(source='application.name', read_only=True)
    username = serializers.CharField(source='user.username', read_only=True)
    action_type_display = serializers.CharField(source='get_action_type_display', read_only=True)

    class Meta:
        model = AuditLogEntry
        fields = ['id', 'application_name', 'username', 'action_type', 'action_type_display', 'timestamp', 'details']

    def to_representation(self, instance):
        """ Customize representation if needed, for example formatting datetime """
        representation = super().to_representation(instance)
        # You can customize the timestamp format if needed
        representation['timestamp'] = instance.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        return representation




class RequestMetricsSerializer(serializers.ModelSerializer):
    application_name = serializers.CharField(max_length=255)
    endpoint = serializers.CharField(max_length=2048)
    method = serializers.ChoiceField(choices=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
    status_code = serializers.IntegerField()
    duration = models.FloatField()
    metadata = serializers.JSONField(required=False)  # Optional field

    def validate_application_name(self, value):
        """Ensure the application name exists in the Application model."""
        if not Application.objects.filter(name=value).exists():
            raise serializers.ValidationError(f"Application '{value}' does not exist.")
        return value





class LogEntrySerializer(serializers.Serializer):
    application_name = serializers.CharField(max_length=255)
    level = serializers.ChoiceField(choices=["INFO", "WARNING", "ERROR"])
    message = serializers.CharField()
    metadata = serializers.JSONField(required=False)

    def validate_application_name(self, value):
        if not Application.objects.filter(name=value).exists():
            raise  serializers.ValidationError(f"Application '{value}' does not exist.")
        return value



class TopEndpointsSerializer(serializers.Serializer):
    endpoint = serializers.CharField()
    count = serializers.IntegerField()
