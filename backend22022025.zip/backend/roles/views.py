from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.db import transaction
from psutil import users
from rest_framework.exceptions import NotFound
from rest_framework.generics import get_object_or_404
import openpyxl


from audit.models import AuditLogEntry, ActionType

""" Added this new part for logout """
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated, AllowAny
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.parsers import MultiPartParser, FormParser

# application management related views
# for all applications excluding auth server application
class ApplicationListView(generics.ListAPIView):
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]


class AdminApplicationListView(generics.ListAPIView):
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]


# for creating new application
class ApplicationCreateView(generics.CreateAPIView):
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



# for retrieving update and deleting application
class ApplicationDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


# for getting number of counts for applications
class ApplicationCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            apps = Application.objects.filter(active=True).count()
            return Response({'apps_count': apps})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ApplicationAPIView(APIView):
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        try:
            application = Application.objects.get(name=request.data.get('name'))
            serializer = ApplicationSerializer(application)
            return Response({'app': serializer.data}, status=status.HTTP_200_OK)
        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)





# for Permission management related views

class PermissionListView(generics.ListAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializerForOther
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]



class PermissionCreateView(generics.CreateAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class PermissionDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class PermissionListByApplicationView(generics.ListAPIView):
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        application_id = self.request.query_params.get('application', None)
        if application_id is None:
            return Permission.objects.none()  # Return an empty queryset if no application name is provided

        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            raise NotFound(detail="Application not found.")

        return Permission.objects.filter(application=application)


class CreatePermissionsFromExcelView(APIView):
    parser_classes = [MultiPartParser]

    def post (self, request, *args, **kwargs):
        centralized_app = Application.objects.get(name=settings.REGISTERED_APP_NAME)
        file = request.FILES.get('file')
        if not file:
            return Response({'error': 'No file uploaded.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        permissions = []
        existing_permissions = set()  # To track existing permissions

        for row in sheet.iter_rows(min_row=2, values_only=True):
            permission_name = row[0]
            application_name = row[1]
            permission_description = row[2]

            if not permission_name or not application_name or not permission_description:
                return Response({'error': 'Invalid data in the Excel file.'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                # Get the Application instance
                application = Application.objects.get(name=application_name)
            except Application.DoesNotExist:
                return Response({'error': f"Application '{application_name}' does not exist."}, status=status.HTTP_400_BAD_REQUEST)


            # Check if permission with the same name already exists for the same application
            if Permission.objects.filter(name=permission_name, application=application.id).exists():
                return Response(
                    {'error': f"Permission '{permission_name}' already exists for application '{application_name}'."},
                    status=status.HTTP_400_BAD_REQUEST)

            # Create the permission
            permission_data = {'name': permission_name, 'application': application.id, 'description': permission_description}
            serializer = PermissionSerializer(data=permission_data)
            if serializer.is_valid():
                permission = serializer.save(created_by=request.user, updated_by=request.user)
                permissions.append(permission)
                existing_permissions.add((permission_name, application.id))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        try:
            with transaction.atomic():
                Permission.objects.bulk_create(permissions)
            # log the action for each permission

            content_type = ContentType.objects.get_for_model(Permission)
            for permission in permissions:
                AuditLogEntry.objects.create(
                user=request.user,
                application=centralized_app,  # Assuming the user has an application field
                action_type=ActionType.CREATE,
                object_type=content_type,
                object_id=str(permission.id),
                details=f"Permission '{permission.name}' created for application '{permission.application.name}' from Excel file."
            )



            return Response({'message': f'{len(permissions)}Permissions created successfully.'}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)






# for role management related views

class RoleListView(generics.ListAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


class RoleCreateView(generics.CreateAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class RoleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class RoleListByApplicationView(generics.ListAPIView):
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        application_id = self.request.query_params.get('application', None)
        if application_id is None:
            return Role.objects.none()  # Return an empty queryset if no application name is provided

        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            raise NotFound(detail="Application not found.")

        return Role.objects.filter(application=application)




# for user roles assigning management related views
class UserRolesListView(generics.ListAPIView):
    serializer_class = UserRoleSerializerForDisplayList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        auth_server = Application.objects.filter(name="Auth server").first()
        if auth_server:
            # Exclude UserRole instances associated with the auth_server application
            return UserRole.objects.exclude(application=auth_server)
        return UserRole.objects.all()




class UserRoleCreateView(generics.CreateAPIView):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



class UserRoleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializer
    # authentication_classes = [JWTAuthentication]
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)



class UsersByApplicationAndRoleView(generics.GenericAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request, application_name, role_name):
        # Get the application instance
        application = get_object_or_404(Application, name=application_name)

        # Get the role instance
        role = get_object_or_404(Role, name=role_name, application=application)

        # Get the users associated with the specified role for the application
        user_roles = UserRole.objects.filter(application=application, role=role).select_related('user')

        # Serialize the user data
        users = [user_role.user for user_role in user_roles]
        serializer = self.get_serializer(users, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)



# for Auth Server User Role
class AuthServerUserRolesListView(generics.ListAPIView):
    serializer_class = UserRoleSerializerForDisplayList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        auth_server = Application.objects.filter(name="Auth server").first()
        if auth_server:
            # Exclude UserRole instances associated with the auth_server application
            return UserRole.objects.filter(application=auth_server)
        return UserRole.objects.all()


class AssignAuthServerUserRoleView(generics.CreateAPIView):
    serializer_class = AssignRolesAuthServerSerializers
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return UserRole.objects.filter(application__name='auth_server')

    def post(self, request, *args, **kwargs):
        # Validate if role is among the allowed roles for 'auth_server'
        allowed_roles = ['Administrator', 'Authenticator', 'Site Admin']
        role = request.data.get('role')

        if role not in allowed_roles:
            return Response({'error': 'Invalid role assigned.'}, status=status.HTTP_400_BAD_REQUEST)

        return super().post(request, *args, **kwargs)