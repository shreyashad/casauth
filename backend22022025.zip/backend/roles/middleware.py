from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils.deprecation import MiddlewareMixin
from django.db.models import Q
from .models import *
from rest_framework import status

class ApplicationValidationMiddleware:
    """
    Middleware to validate application based on the request.
    It checks whether the application exists or not and is active or not.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Get application identifier from the request headers or query parameters
        application_name = request.headers.get("X-Application-Name") or request.GET.get("application_name")

        if not application_name:
            return JsonResponse({"error": "Application name not provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            application = Application.objects.filter(name=application_name, active=True).first()
        except Application.DoesNotExist:
            return JsonResponse({"error": "Application not found or inactive"}, status=status.HTTP_404_NOT_FOUND)

        # Set the application in the request object
        request.application = application

        response = self.get_response(request)

        return response






class DefaultRoleMiddleware(MiddlewareMixin):
    def process_request(self, request):
        application = getattr(request, 'application', None)

        if not application:
            return JsonResponse({"error": "Application not provided"}, status=status.HTTP_400_BAD_REQUEST)

        default_role = Role.objects.filter(application=application, default_for_application=True).first()

        if default_role and default_role.auto_assign_verified_users:
            # Get the criteria stored in the Json format
            criteria = default_role.criteria

            if criteria:
                # Ensure criteria is a dictionary
                if not isinstance(criteria, dict):
                    return JsonResponse({"error": "Invalid criteria format"}, status=status.HTTP_400_BAD_REQUEST)

                user_filter = Q(is_verified=True) # Base filter for verified users

                #Dynamically apply filters from the criteria
                for field, value in criteria.items():
                    if hasattr(CustomUser, field):
                        user_filter &= Q(**{field: value})
                    else:
                        return JsonResponse({"error": f"Invalid field: {field}"}, status=status.HTTP_400_BAD_REQUEST)

                # Filter users based on the criteria
                eligible_users = CustomUser.objects.filter(user_filter)
                for user in eligible_users:
                    if not user.roles.filter(application=application).exists():
                        # Assign the default role to the user
                        UserRole.assign_role(user, application, default_role)
                        # Optionally, you can send a notification to the user or perform other actions
                        print(f"Assigned default role {default_role.name} to user {user.username}")
        return None

class RoleMiddleware(MiddlewareMixin):
    """
    Middleware to check if the user has the correct role the application.
    The user's role is validated based on the application they are trying to access.
    """

    def process_request(self, request):
        user = request.user
        application = getattr(request, 'application', None)

        if not user.is_authenticated:
            return JsonResponse({"error": "User is not authenticated"}, status=status.HTTP_401_UNAUTHORIZED)

        if not application:
            return JsonResponse({"error": "Application not provided"}, status=status.HTTP_400_BAD_REQUEST)

        # Check if the user has any valid role for the given application
        role = UserRole.objects.filter(application=application, user=user).first()

        if not role:
            return JsonResponse({"error": "User does not have a valid role for this application"}, status=status.HTTP_403_FORBIDDEN)

        request.user_role = role
        return None

# class PermissionMiddleware(MiddlewareMixin):
#     """
#     Middleware to check if the user has the required permission for the resource.
#     The permissions are dynamically checked based on the view's `permission_name` attribute.
#     """
#
#     def process_request(self, request):
#         user = request.user
#         required_permission = getattr(request.view, 'permission_name', None)
#         application = getattr(request, 'application', None)
#
#         if not user.is_authenticated:
#             return JsonResponse({"error": "User is not authenticated"}, status=status.HTTP_401_UNAUTHORIZED)
#
#         if not application: