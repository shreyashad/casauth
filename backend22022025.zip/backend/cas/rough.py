import os
import json
from multiprocessing.managers import view_type

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from cryptography.hazmat.primitives import serialization
import uuid  # For UUID generation

PRIVATE_KEY_PATH = os.path.join(BASE_DIR, 'secrets', 'auth_server_private.pem')  # Your private key path
PUBLIC_KEY_PATH = os.path.join(BASE_DIR, 'auth_server_public.pem') # Your public key path

class JWKSView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            with open(PUBLIC_KEY_PATH, "rb") as f:
                public_key = serialization.load_pem_public_key(f.read())

            # Generate or retrieve the key ID (kid)
            try:
                # Try to read kid from a file (if you have previously stored it)
                with open("key_id.txt", "r") as kid_file:
                    key_id = kid_file.read().strip()
            except FileNotFoundError:
                # If kid file doesn't exist, generate a new UUID and save it
                key_id = str(uuid.uuid4())
                with open("key_id.txt", "w") as kid_file:
                    kid_file.write(key_id)

            # Convert public key components to strings (Base64url encoding is handled by json)
            jwk = {
                "kty": "RSA",
                "kid": key_id,
                "n": public_key.modulus.to_int().to_bytes(
                    (public_key.modulus.bit_length() + 7) // 8, 'big'
                ).hex(),  # Hex encoding for 'n'
                "e": public_key.public_exponent.to_int().to_bytes(
                    (public_key.public_exponent.bit_length() + 7) // 8, 'big'
                ).hex()   # Hex encoding for 'e'
            }

            return Response({"keys": [jwk]}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# In your auth_server/urls.py
from django.urls import path
urlpatterns = [
    # ... other URLs
    path('jwks/', JWKSView.as_view(), name='jwks'),
]
-------
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from rest_framework.permissions import AllowAny # Make this endpoint accessible without authentication

class RefreshTokenView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        refresh_token = request.data.get('refresh')

        if not refresh_token:
            return Response({'error': 'Refresh token is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            refresh = RefreshToken(refresh_token)
            # Verify the refresh token (this will raise exceptions if invalid)
            refresh.verify()

            # Get user and other claims from the refresh token (if needed)
            user_id = refresh.payload.get('user_id')
            application_id = refresh.payload.get('application_id')
            # ... other claims

            # Generate a *new* access token
            access = AccessToken()
            access.payload['user_id'] = user_id
            access.payload['application_id'] = application_id
            # ... other claims

            # Optionally, generate a *new* refresh token (one-time use is recommended)
            new_refresh = RefreshToken()

            return Response({
                'access': str(access),
                'refresh': str(new_refresh) if generate_new_refresh else None, # Only include a new refresh token if you generate one
            }, status=status.HTTP_200_OK)

        except Exception as e: # Catch all exceptions during token verification or generation
            return Response({'error': 'Invalid refresh token'}, status=status.HTTP_400_BAD_REQUEST)

# In your auth_server/urls.py
from django.urls import path
urlpatterns = [
    # ... other URLs
    path('api/token/refresh/', RefreshTokenView.as_view(), name='token_refresh'), # Add this URL
]

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from rest_framework.permissions import AllowAny

class RefreshTokenView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        refresh_token = request.data.get('refresh')

        if not refresh_token:
            return Response({'error': 'Refresh token is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            refresh = RefreshToken(refresh_token)
            refresh.verify()  # Verify refresh token

            user_id = refresh.payload.get('user_id')
            application_id = refresh.payload.get('application_id')
            # ... other claims

            access = AccessToken()  # Generate a *new* access token
            access.payload['user_id'] = user_id
            access.payload['application_id'] = application_id
            access.payload['app_name'] = refresh.payload.get('app_name')  # Get app_name from refresh token payload
            access.payload['session_key'] = refresh.payload.get('session_key')  # Get session key from refresh token payload
            # ... other claims

            # Refresh token rotation (optional but recommended)
            new_refresh = RefreshToken.for_user(User.objects.get(id=user_id)) # generate a new refresh token
            #Blacklist the old refresh token
            refresh.blacklist()

            return Response({
                'access': str(access),
                'refresh': str(new_refresh) if new_refresh else None, # Only include a new refresh token if you generate one
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'error': 'Invalid refresh token'}, status=status.HTTP_400_BAD_REQUEST)
-----
#old jwks view
class JWKSView(APIView):
    permission_classes = [AllowAny]
    def get(self, request):
        try:
            with open(PUBLIC_KEY_PATH, "rb") as f:
                public_key = serialization.load_pem_public_key(f.read())
            # Generate or retrieve the key ID (kid)
            try:
                with open("key_id.txt", "r") as kid_file:
                    key_id = kid_file.read().strip()
            except FileNotFoundError:
                key_id = str(uuid.uuid4())
                with open("key_id.txt", "w") as kid_file:
                    kid_file.write(key_id)

            # Convert public key components to strings (Base64url encoding is handled by json)
            jwk = {
                "kty": "RSA",
                "kid": key_id,
                "n": public_key.modulus.to_int().to_bytes(
                    (public_key.modulus.bit_length() + 7) // 8, 'big'
                ).hex(),
                "e": public_key.public_exponent.to_int().to_bytes(
                    (public_key.public_exponent.bit_length() + 7) // 8, 'big'
                ).hex()
            }

            return Response({"keys": [jwk]}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ... (urls.py as before)


import uuid
from cryptography.hazmat.primitives import serialization
from rest_framework.views import APIView, status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from .utils import PUBLIC_KEY_PATH  # Assuming PUBLIC_KEY_PATH is defined correctly

class JWKSView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            with open(PUBLIC_KEY_PATH, "rb") as f:
                public_key = serialization.load_pem_public_key(f.read())

            # Correct way to access modulus and public_exponent
            numbers = public_key.public_numbers()  # Get the public numbers object
            modulus = numbers.n
            exponent = numbers.e

            # Generate or retrieve the key ID (kid)
            try:
                with open("key_id.txt", "r") as kid_file:
                    key_id = kid_file.read().strip()
            except FileNotFoundError:
                key_id = str(uuid.uuid4())
                with open("key_id.txt", "w") as kid_file:
                    kid_file.write(key_id)

            # Convert to hex strings
            jwk = {
                "kty": "RSA",
                "kid": key_id,
                "n": hex(modulus)[2:],  # [2:] removes the "0x" prefix
                "e": hex(exponent)[2:],  # [2:] removes the "0x" prefix
            }

            return Response({"keys": [jwk]}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

-------
#old login view

class LoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        # Step 1: Validate the serializer
        if not serializer.is_valid():
            return Response({"error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

        username = serializer.validated_data.get('username')
        password = serializer.validated_data.get('password')
        application_id = serializer.validated_data.get('application_id')

        # Ensure username, password and application id are provided
        if not username or not password or not application_id:
            return Response(
                {"error": "All fields are required: username, password, and application_id"},
                status=status.HTTP_400_BAD_REQUEST
            )
        # Step 2: CAuthenticate the user
        try:
            user = authenticate(username=username, password=password)
            if user is None:
                logger.warning(f"Authentication failed for user: {username} (Invalid credentials)")  # Log username
                return Response({"error": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)


            ## Step 3: : Validate the application
            try:
                application = Application.objects.get(id=application_id, active=True)
            except Application.DoesNotExist:
                return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)

            # Step 4: : Checking for password expiry requirement
            if user.is_password_expired(): # Check for password expiry
                user.password_change_required = True
                user.save() # Save the updated user object
                logger.info(f"Password expired for user: {username}. Password change required.")  # Log the event
                return Response({"error": "Password expired. Please update your password."},
                                status=status.HTTP_403_FORBIDDEN)

            if user.password_change_required:
                logger.info(f"Password change is required for user: {username}.")  # Log the event
                return Response({"error": "Password change required. Please update your password."},
                                status=status.HTTP_403_FORBIDDEN)

            # Step 5: Create user session
            try:
                # Create a user session
                session_key = UserSession.create_ticket_str(application)
                expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
                user_session = UserSession.objects.create(
                    user=user,
                    application=application,
                    session_key=session_key,
                    expires_at=expires_at
                )

            except Exception as e:
                logger.error(f"User session creation failed for user: {username}: {e}")
                return Response({"error": "Failed to create session."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR) # User-friendly message

            # Step 6: Generate ticket
            try:
                service_ticket = ServiceTicket.objects.create_ticket(user=user, application=application)
                pgt = ProxyGrantingTicket.objects.create_ticket(user=user, application=application)
            except Exception as e:
                logger.error(f"Ticket generation failed for user: {username}: {e}")
                return Response({"error": "Failed to generate tickets."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Step 6: Update application status
            handle_user_application_status(user, application, user_session)
            # Step 7: Create audit log
            AuditLogEntry.objects.create(
                user=user,
                application=application,
                action_type=ActionType.LOGIN,
                object_id=str(user.id),
                object_type=ContentType.objects.get_for_model(CustomUser),
                details=f"Login user- ID: {user.username}"
            )

            # Step 8: Prepare response data and return
            try:
                refresh = RefreshToken.for_user(user)
                access = AccessToken()  # Generate a *new* access token
                # Add application_id to the access token payload
                access.payload['application_id'] = str(application.id)
                access.payload['app_name'] = str(application.name)
                access.payload['session_key'] = user_session.session_key
                print(access.payload)

            except Exception as e:
                logger.error(f"JWT token creation failed for user: {username}: {e}")
                return Response({"error": "Failed to generate tokens."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            response_data = {
                'refresh': str(refresh),
                'access': str(access),
                'session_key': user_session.session_key,
                'session_expires_at': user_session.expires_at,
                'service_ticket': service_ticket.ticket,
                'proxy_granting_ticket': pgt.ticket,
            }
            print(f"Access token generated: {access}")
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:  # Catch any unexpected errors
            logger.exception(
                f"An unexpected error occurred during login for user: {username}: {e}")  # Log the full traceback
            return Response({"error": "An unexpected error occurred."},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)  # User-friendly message



---------------
#reveised login view
import logging
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken

from .serializers import LoginSerializer
from .models import Application, UserSession, ServiceTicket, ProxyGrantingTicket, AuditLogEntry, ActionType, CustomUser
from .utils import handle_user_application_status  # Import your utility function

logger = logging.getLogger(__name__)  # Initialize logger

class LoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if not serializer.is_valid():
            return Response({"error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

        username = serializer.validated_data.get('username')
        password = serializer.validated_data.get('password')
        application_id = serializer.validated_data.get('application_id')  # Get application ID

        if not username or not password or not application_id:
            return Response(
                {"error": "All fields are required: username, password, and application_id"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            user = authenticate(username=username, password=password)  # Authenticate user
            if user is None:
                logger.warning(f"Authentication failed for user: {username} (Invalid credentials)")
                return Response({"error": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)

            try:
                application = Application.objects.get(id=application_id, active=True)  # Get the Application object
            except Application.DoesNotExist:
                return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)

            if user.is_password_expired() or user.password_change_required:
                return Response({"error": "Password change required."}, status=status.HTTP_403_FORBIDDEN)

            # User Session
            session_key = UserSession.create_ticket_str(application)
            expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
            user_session = UserSession.objects.create(
                user=user, application=application, session_key=session_key, expires_at=expires_at
            )

            # Tickets
            service_ticket = ServiceTicket.objects.create_ticket(user=user, application=application)
            pgt = ProxyGrantingTicket.objects.create_ticket(user=user, application=application)

            handle_user_application_status(user, application, user_session)  # Update application status

            # Audit Log
            AuditLogEntry.objects.create(
                user=user, application=application, action_type=ActionType.LOGIN,
                object_id=str(user.id), object_type=ContentType.objects.get_for_model(CustomUser),
                details=f"Login user- ID: {user.username}"
            )

            # JWT Token Generation
            refresh = RefreshToken.for_user(user)
            access = AccessToken()

            # Set Payload
            access.payload['user_id'] = user.id  # Include user ID in payload
            access.payload['application_id'] = str(application.id)
            access.payload['app_name'] = str(application.name)
            access.payload['session_key'] = user_session.session_key

            # Set Header
            access.set_exp(lifetime=settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'])  # Set expiry
            access.set_jti() # set jti
            access.set_iat()
            access.header['alg'] = settings.SIMPLE_JWT['ALGORITHM'] # Set algorithm
            access.header['kid'] = open("key_id.txt", "r").read().strip() # set kid

            response_data = {
                'refresh': str(refresh),
                'access': str(access),
                'session_key': user_session.session_key,
                'session_expires_at': user_session.expires_at,
                'service_ticket': service_ticket.ticket,
                'proxy_granting_ticket': pgt.ticket,
            }

            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            logger.exception(f"An unexpected error occurred during login for user: {username}: {e}")
            return Response({"error": "An unexpected error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
# ... other imports

class LoginAPIView(APIView):
    # ... (other code)

    def post(self, request):
        # ... (authentication and other logic)

        try:
            refresh = RefreshToken.for_user(user)
            access = AccessToken()

            # Set Payload
            access.payload['user_id'] = user.id
            access.payload['application_id'] = str(application.id)
            access.payload['app_name'] = str(application.name)
            access.payload['session_key'] = user_session.session_key

            # Set Header (Corrected)
            access.set_exp(lifetime=settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'])
            access.set_jti()
            access.set_iat()
            access.token.header['alg'] = settings.SIMPLE_JWT['ALGORITHM']  # Use access.token.header
            access.token.header['kid'] = open("key_id.txt", "r").read().strip()  # Use access.token.header

            response_data = {
                'refresh': str(refresh),
                'access': str(access),  # Access token as string
                'session_key': user_session.session_key,
                'session_expires_at': user_session.expires_at,
                'service_ticket': service_ticket.ticket,
                'proxy_granting_ticket': pgt.ticket,
            }

            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            logger.exception(f"An unexpected error occurred during login for user: {username}: {e}")
            return Response({"error": "An unexpected error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


print(settings.SIMPLE_JWT) # Print settings
    access = AccessToken()
    print("AccessToken object:", access) # Print the AccessToken object

    access.payload['user_id'] = 1  # Hardcoded user ID
    access.set_exp(lifetime=settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'])
    access.set_jti()
    access.set_iat()

    access.token.header['alg'] = settings.SIMPLE_JWT['ALGORITHM']
    access.token.header['kid'] = open("key_id.txt", "r").read().strip()

    access_token_str = str(access)
    print("Generated token:", access_token_str)
# 'VERIFYING_KEY': open(PUBLIC_KEY_PATH, 'r').read(),