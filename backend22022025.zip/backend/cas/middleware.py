from django.utils.deprecation import MiddlewareMixin
from rest_framework.exceptions import AuthenticationFailed
from django.utils import timezone
from cas.models import UserSession


class UserSessionMiddleware(MiddlewareMixin):

    def process_request(self, request):
        session_key = request.headers.get('X-Session-Key')  # or however you want to retrieve it

        if not session_key:
            return None

        try:
            user_session = UserSession.objects.get(session_key=session_key)

            # Check if the session has expired
            if user_session.is_expired:
                raise AuthenticationFailed("Session has expired.")

            # Refresh the expiration time
            user_session.expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
            user_session.save()

            # Attach user and application to request for later access
            request.user = user_session.user
            request.application = user_session.application

        except UserSession.DoesNotExist:
            raise AuthenticationFailed("Invalid session key.")