import uuid
from django.contrib.contenttypes.models import ContentType
from requests import session
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.urls import app_name
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from accounts.models import *
from audit.models import *
from backend.settings import PUBLIC_KEY_PATH, PRIVATE_KEY_PATH
from .models import *
from .serializers import *
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from .services import handle_user_application_status
import logging
from cryptography.hazmat.primitives import serialization



logger = logging.getLogger(__name__)

class LoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        # Step 1: Validate the serializer
        if not serializer.is_valid():
            return Response({"error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

        username = serializer.validated_data.get('username')
        password = serializer.validated_data.get('password')
        application_id = serializer.validated_data.get('application_id')

        # Ensure username, password and application id are provided
        if not username or not password or not application_id:
            return Response(
                {"error": "All fields are required: username, password, and application_id"},
                status=status.HTTP_400_BAD_REQUEST
            )
        # Step 2: CAuthenticate the user
        try:
            user = authenticate(username=username, password=password)
            if user is None:
                logger.warning(f"Authentication failed for user: {username} (Invalid credentials)")  # Log username
                return Response({"error": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)


            ## Step 3: : Validate the application
            try:
                application = Application.objects.get(id=application_id, active=True)
            except Application.DoesNotExist:
                return Response({"error": "Application not found or inactive"}, status=status.HTTP_400_BAD_REQUEST)

            # Step 4: : Checking for password expiry requirement
            if user.is_password_expired(): # Check for password expiry
                user.password_change_required = True
                user.save() # Save the updated user object
                logger.info(f"Password expired for user: {username}. Password change required.")  # Log the event
                return Response({"error": "Password expired. Please update your password."},
                                status=status.HTTP_403_FORBIDDEN)

            if user.password_change_required:
                logger.info(f"Password change is required for user: {username}.")  # Log the event
                return Response({"error": "Password change required. Please update your password."},
                                status=status.HTTP_403_FORBIDDEN)

            # Step 5: Create user session
            try:
                # Create a user session
                session_key = UserSession.create_ticket_str(application)
                expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
                user_session = UserSession.objects.create(
                    user=user,
                    application=application,
                    session_key=session_key,
                    expires_at=expires_at
                )

            except Exception as e:
                logger.error(f"User session creation failed for user: {username}: {e}")
                return Response({"error": "Failed to create session."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR) # User-friendly message

            # Step 6: Generate ticket
            try:
                service_ticket = ServiceTicket.objects.create_ticket(user=user, application=application)
                pgt = ProxyGrantingTicket.objects.create_ticket(user=user, application=application)
            except Exception as e:
                logger.error(f"Ticket generation failed for user: {username}: {e}")
                return Response({"error": "Failed to generate tickets."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Step 6: Update application status
            handle_user_application_status(user, application, user_session)
            # Step 7: Create audit log
            AuditLogEntry.objects.create(
                user=user,
                application=application,
                action_type=ActionType.LOGIN,
                object_id=str(user.id),
                object_type=ContentType.objects.get_for_model(CustomUser),
                details=f"Login user- ID: {user.username}"
            )
            try:
                with open(PRIVATE_KEY_PATH, 'r') as f:
                    print("Private key file opened successfully.")
            except FileNotFoundError:
                print(f"Error: Private key file not found at {PRIVATE_KEY_PATH}")
            except Exception as e:
                print(f"Error opening private key file: {e}")


            # Step 8: Prepare response data and return
            try: # JWT Token Generation
                print(f"settings.SIMPLE_JWT{settings.SIMPLE_JWT}")
                refresh = RefreshToken.for_user(user)
                access = AccessToken()  # Generate a *new* access token
                print(f"checking for Created the AccessToken object: {access} ")

                # Set Payload
                access.payload['user_id'] = str(user.id)
                access.payload['application_id'] = str(application.id)
                access.payload['app_name'] = str(application.name)
                access.payload['session_key'] = user_session.session_key


                # Set Expiry, JTI, and IAT
                access.set_exp(lifetime=settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'])  # Set expiry
                access.set_jti()  # set jti
                access.set_iat()
                print("AccessToken object (after payload):", access)

                # ***ATTEMPT JWT GENERATION*** (This is the crucial step)
                # access_token_str = str(access)  # This is where the magic happens and access.token is initialized.
                # print("Generated token (before header set):", access_token_str)  # Check if the token is generated

                # access.token.header['alg'] = settings.SIMPLE_JWT['ALGORITHM']  # Set algorithm
                # access.token.header['kid'] = open("key_id.txt", "r").read().strip()  # set kid
                # print(f"checking for access token: {access.token}")
                # print(f"checking for token header: {access.token.header}")

                access_token_str = str(access)
                print("Generated token:", access_token_str)

                response_data = {
                    'refresh': str(refresh),
                    'access': access_token_str,
                    'session_key': user_session.session_key,
                    'session_expires_at': user_session.expires_at,
                    'service_ticket': service_ticket.ticket,
                    'proxy_granting_ticket': pgt.ticket,
                }

                print(f"Access token generated: {access}")
                return Response(response_data, status=status.HTTP_200_OK)
            except Exception as e:
                logger.error(f"JWT token creation failed for user: {username}: {e}")
                return Response({"error": "Failed to generate tokens."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:  # Catch any unexpected errors
            logger.exception(
                f"An unexpected error occurred during login for user: {username}: {e}")  # Log the full traceback
            return Response({"error": "An unexpected error occurred."},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)  # User-friendly message



class ValidateSessionView(APIView):
    permission_classes = [AllowAny]
    def get(self, request):
        session_key = request.headers.get('Authorization')

        # Check if session key is provided
        if not session_key:
            return Response(
                {'error': 'Session key missing. Please provide the session key in the Authorization header.'},
                status=status.HTTP_400_BAD_REQUEST)

        try:
            # Retrieve the user session
            user_session = UserSession.objects.get(session_key=session_key)

            # Check if session has expired
            if user_session.is_expired():
                return Response({'error': 'Session expired. Please log in again.'}, status=status.HTTP_401_UNAUTHORIZED)

            # Refresh session expiration time
            user_session.expires_at = timezone.now() + timezone.timedelta(minutes=UserSession.TICKET_EXPIRE)
            user_session.save()

            # Return session details
            return Response({
                'status': 'Session is valid',
                'expires_at': user_session.expires_at
            }, status=status.HTTP_200_OK)

        except UserSession.DoesNotExist:
            return Response({'error': 'Invalid session key. The session key provided does not exist in our records.'},
                            status=status.HTTP_401_UNAUTHORIZED)



class ValidateServiceTicketAPIView(APIView):
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        # Use the serializer to validate incoming data
        serializer = ServiceTicketValidationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Extract validated data
        service_ticket = serializer.validated_data.get('service_ticket')
        application_id = serializer.validated_data.get('application_id')

        try:
            # Retrieve the application
            application = Application.objects.get(id=application_id)

            # Validate the service ticket against the application
            ticket = ServiceTicket.validate_ticket(service_ticket, application)

            # Check if the ticket is expired or consumed
            if ticket.is_expired:
                ticket.user.is_online = False
                return Response({'error': 'Ticket expired. The service ticket has expired and cannot be used.'},
                                status=status.HTTP_400_BAD_REQUEST)

            if ticket.is_consumed:
                return Response({'error': 'Ticket already consumed. The service ticket has already been used.'},
                                status=status.HTTP_400_BAD_REQUEST)

            # Consume the ticket (mark it as used)
            ticket.consume()
            user = ticket.user

            # Check if the user has access to this application via a role
            try:
                user_role = UserRole.objects.get(user=user, application=application)
                permissions = user_role.role.permissions.all()

                serialized_permissions = [
                    {
                        'name': permission.name,
                    }
                    for permission in permissions
                ]

                # Retrieve user profile information
                user_profile = UserProfile.objects.get(user=user)
                profile_pic = user_profile.profile_picture.url if user_profile.profile_picture else None

                # Return the user details and permissions
                return Response({
                    'profile_picture': profile_pic,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'org_type': user.org_type,
                    'org_name': user.org_name,
                    'org_sub_type': user.org_sub_type,
                    'location_type': user.location_type,
                    'location_name': user.location_name,
                    'location_code': user.location_code,
                    'emp_code': user.emp_code,
                    'department': user.department,
                    'designation': user.designation,
                    'username': user.username,
                    'roles': user_role.role.name,
                    'permissions': serialized_permissions
                }, status=status.HTTP_200_OK)

            except UserRole.DoesNotExist:
                return Response(
                    {"error": "User does not have access to this application. Please contact your administrator."},
                    status=status.HTTP_403_FORBIDDEN)

        except Application.DoesNotExist:
            return Response(
                {'error': 'Application not found. The application ID provided is invalid or does not exist.'},
                status=status.HTTP_400_BAD_REQUEST)
        except ValueError as e:
            return Response({'error': f'Error occurred while processing the service ticket: {str(e)}'},
                            status=status.HTTP_400_BAD_REQUEST)

class LogOutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        session_key = request.headers.get('X-Session-Key')

        if not session_key:
            return Response(
                {'error': 'Session key missing. Please provide the session key in the Authorization header.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # Retrieve the user session based on the session key
            user_session = UserSession.objects.get(session_key=session_key)

            # Mark the session as expired (or inactive)
            user_session.expire()
            try:
                user_application_status = UserApplicationStatus.objects.get(
                    user=user_session.user,
                    application=user_session.application,
                    session=user_session
                )
                user_application_status.is_online = False
                user_application_status.save()
            except UserApplicationStatus.DoesNotExist:
                # If no status exists for this session, log a warning (optional)
                print(
                    f"No UserApplicationStatus found for user: {user_session.user}, application: {user_session.application}")

            # Retrieve and invalidate any associated service ticket
            service_ticket = ServiceTicket.objects.filter(user=user_session.user,
                                                          application=user_session.application).first()
            if service_ticket and not service_ticket.is_consumed:
                service_ticket.consume()

            # Update the user's online status
            user_session.user.is_online = False
            user_session.user.save()
            return Response({'status': 'Logged out successfully'}, status=status.HTTP_200_OK)

        except UserSession.DoesNotExist:
            return Response({'error': 'Invalid session key. The session key provided does not exist in our records.'},
                            status=status.HTTP_401_UNAUTHORIZED)


class GenerateProxyTicketView(APIView):
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        pgt_id = request.data.get('pgt_id')
        application_id = request.data.get('application_id')

        try:
            pgt = ProxyGrantingTicket.objects.get(ticket=pgt_id)
            application = Application.objects.get(id=application_id)
            proxy_ticket = ProxyTicket.create_ticket(user=pgt.user, application=application, granted_by_pgt=pgt)
            return Response({'proxy_ticket': proxy_ticket.ticket}, status=status.HTTP_200_OK)
        except ProxyGrantingTicket.DoesNotExist:
            return Response({'detail': 'Invalid Proxy Granting Ticket'}, status=status.HTTP_400_BAD_REQUEST)
        except Application.DoesNotExist:
            return Response({'detail': 'Invalid application'}, status=status.HTTP_400_BAD_REQUEST)



class TokenIntrospectionAPIView(APIView):
    permission_classes = [AllowAny]
    def get(self, request):
        app_name = request.GET.get('app_name')
        token = request.GET.get('token')
        if not token:
            return Response({"error": "Token is required"}, status=status.HTTP_400_BAD_REQUEST)

        print(f"Received token: {token}")

        if token.startswith('Bearer '):
            token = token[7:]

        jwt_auth = JWTAuthentication()
        try:
            validated_token = jwt_auth.get_validated_token(token)
            user = jwt_auth.get_user(validated_token)
            application = Application.objects.get(name=app_name)
            user_roles = UserRole.objects.get(user=user, application=application)

            permissions = set()
            for user_role in user_roles:
                role_permissions = user_role.role.permissions.values_list('name', flat=True)
                permissions.update(role_permissions)


            print(f"user details for token: {user}")
            return Response({
                "user_id": user.id,
                "username": user.username,
                "is_active": user.is_active,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "org_type": user.org_type,
                "org_name": user.org_name,
                "org_sub_type": user.org_sub_type,
                "assigned_details": user.assigned_details,
                "location_type": user.location_type,
                "location_name": user.location_name,
                "location_code": user.location_code,
                "department": user.department,
                "exp": validated_token['exp'],
                "permissions": list(permissions),
                "roles": user_roles.roles.name,
            }, status=status.HTTP_200_OK)
        except (InvalidToken, TokenError) as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class JWKSView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            with open(PUBLIC_KEY_PATH, "rb") as f:
                public_key = serialization.load_pem_public_key(f.read())

            # access modulus and public_exponent
            numbers = public_key.public_numbers()
            modulus = numbers.n
            exponent = numbers.e

            # Generate or retrieve the key ID (kid)
            try:
                with open("key_id.txt", "r") as kid_file:
                    key_id = kid_file.read().strip()
            except FileNotFoundError:
                key_id = str(uuid.uuid4())
                with open("key_id.txt", "w") as kid_file:
                    kid_file.write(key_id)

            # Convert to hex strings
            jwk = {
                "kty" : "RSA",
                "kid" : key_id,
                "n" : hex(modulus)[2:],
                "e" : hex(exponent)[2:],
            }

            return Response({"keys": [jwk]}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({ "error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class RefreshTokenView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        refresh_token = request.data.get('refresh')
        if not refresh_token:
            return Response({'error': 'Refresh token is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            refresh = RefreshToken(refresh_token)
            refresh.verify()
            user_id = refresh.payload.get('user_id')
            application_id = refresh.payload.get('application_id')

            # Generate a new access token
            access = AccessToken()
            access.payload['user_id'] = user_id
            access.payload['application_id'] = application_id
            access.payload['app_name'] = refresh.payload.get('app_name')  # Get app_name from refresh token payload
            access.payload['session_key'] = refresh.payload.get('session_key')  # Get session key from refresh token payload

            # Refresh token rotation (optional but recommended)
            new_refresh = RefreshToken.for_user(CustomUser.objects.get(id=user_id)) # generate a new refresh token
            #Blacklist the old refresh token
            refresh.blacklist()

            return Response({
                'access': str(access),
                'refresh': str(new_refresh) if new_refresh else None, # Only include a new refresh token if you generate one
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': 'Invalid refresh token'}, status=status.HTTP_400_BAD_REQUEST)
