# services.py
from django.db import transaction
from django.utils import timezone

from audit.models import UserApplicationStatus


def handle_user_application_status(user, application, session):
    """
    Update the user's application status without logging them out of other applications.
    """
    try:
        # Update or create the application-specific status
        with transaction.atomic():
            user_app_status, created = UserApplicationStatus.objects.update_or_create(
                user=user,
                application=application,
                defaults={
                    'is_online': True,
                    'last_active': timezone.now(),
                    'session': session
                }
            )

            # Ensure user.is_online remains True if online for any application
            if not user.is_online:
                user.is_online = True
                user.save()

    except Exception as e:
        raise Exception(f"Failed to update user application status: {str(e)}")
