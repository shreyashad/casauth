from django.urls import path
from .views import *

urlpatterns = [
    path('cas-login/',LoginAPIView.as_view(), name='cas_login'),
    path('user-logout/',LogOutView.as_view(), name='logout'),
    path('validate-ticket/', ValidateServiceTicketAPIView.as_view(), name='validate-ticket'),
    path('token/refresh/', RefreshTokenView.as_view(), name='token_refresh'),
    path('token/introspect/', TokenIntrospectionAPIView.as_view(), name='token_introspect'),
    path('validate-session/', ValidateSessionView.as_view(), name='validate_session'),
    path('jwks/', JWKSView.as_view(), name='jwks'),
]