from rest_framework import serializers
from org.models import *

class OrgTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrgType
        fields = "__all__"

class OrgSectorSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrgSector
        fields = "__all__"




class OrganizationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Organization
        fields = ['id', 'name', 'org_type', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class OrgSubTypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = OrganizationSubType
        fields = ['id', 'subtype', 'org_type', 'created_at', 'updated_at', 'created_by', 'updated_by']


class LocationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Locations
        fields = ['id', 'org_type', 'org_name','location_type', 'location_name','location_code' ,'created_at', 'updated_at', 'created_by', 'updated_by']


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'name', 'created_at', 'updated_at', 'created_by', 'updated_by']


class DesignationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Designation
        fields = ['id', 'name', 'created_at', 'updated_at', 'created_by', 'updated_by']
