from django.urls import path
from .views import *

urlpatterns = [
    # for organization type related
    path('orgtype-list/', OrgTypeListView.as_view(), name='orgtype'),
    path('create-orgtype/', OrgTypeCreateView.as_view(), name='create-orgtype'),
    path('orgtype/<uuid:pk>/details/', OrgTypeRetrieveView.as_view(), name='orgtype-details'),
    # for organization sector
    path('org-sector-list/', OrganizationSectorListView.as_view(), name='org_sectors'),
    path('create-org-sectors/', OrganizationSectorCreateView.as_view(), name='create-org-sector'),
    path('org-sector/<uuid:pk>/details/', OrganizationSectorRetrieveView.as_view(), name='org-sector-details'),
    path('upload-sector/', CreateOrganizationSectorFromExcelView.as_view(), name='import-sector-data'),
    # for organization related
    path('organization-list/', OrganizationListView.as_view(), name='organization'),
    path('create-organization/', OrganizationCreateView.as_view(), name='organization-create'),
    path('organization/<uuid:pk>/details/', OrganizationRetrieveView.as_view(), name='organization-details'),
    path('upload-organization/', CreateOrganizationFromExcelView.as_view(), name='import-organization-data'),
    # for org-subtype related
    path('org-subtype-list/', OrganizationSubTypeListView.as_view(),
         name='org-subtype-list'),
    path('create-org-subtype/', OrganizationSubTypeCreateView.as_view(), name='org-subtype-create'),
    path('org-subtype/<uuid:pk>/details/', OrganizationSubTypeRetrieveUpdateDestroyAPIView.as_view(),
         name='org-subtype-details'),
    # for location related
    path('locations-list/', LocationListView.as_view(), name='locations'),
    path('create-location/', LocationCreateView.as_view(), name='create-location'),
    path('locations/<uuid:pk>/details/', LocationRetrieveView.as_view(), name='locations-details'),
    path('upload-locations/', CreateLocationFromExcelView.as_view(), name='import-location-data'),
    # for department related
    path('department-list/', DepartmentListView.as_view(), name='department'),
    path('create-department/', DepartmentCreateView.as_view(), name='create-department'),
    path('department/<uuid:pk>/details/', DepartmentRetrieveView.as_view(),
         name='department-details'),
    path('upload-departments/', CreateDepartmentFormExcelView.as_view(), name='import-department-data'),
     # for designation related
    path('designation-list/', DesignationListView.as_view(), name='designation'),
    path('create-designation', DesignationCreateView.as_view(), name='create-designation'),
    path('designation/<uuid:pk>/details/', DesignationRetrieveView.as_view(), name='designation-details'),
    path('upload-designations/', CreateDesignationFormExcelView.as_view(), name='import-designation-data'),
    # for registration form related
    path('departments/', DepartmentOpenAPIView.as_view(), name='departments'),
    path('designations/', DesignationOpenAPIView.as_view(), name='designations'),
    path('org-type-list/', OrgTypeOpenAPIView.as_view(), name='org-type'),
    path('org-name-list/', OrganizationNameOpenAPIView.as_view(), name='org-name-list'),
    path('org-subtypes/', OrgSubTypeOpenAPIView.as_view(), name='org-subtype-list'),
    path('location-type-list/', LocationTypeOpenAPIView.as_view(), name='location-type-list'),
    path('location-name-list/', LocationNameOpenAPIView.as_view(), name='location-name-list'),
    path('location-code-list/', LocationCodeOpenAPIView.as_view(), name='location-code-list'),

]