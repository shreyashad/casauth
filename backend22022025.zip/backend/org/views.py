import openpyxl
from django.db import transaction
from django.contrib.auth.decorators import permission_required
from django.core.files.storage import default_storage
from openpyxl.reader.excel import load_workbook
from rest_framework.parsers import MultiPartParser
from rest_framework_simplejwt.authentication import JWTAuthentication
from roles.permissions import HasApplicationUserPermission
from .serializers import *
from rest_framework import generics,status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.contrib.contenttypes.models import ContentType
from audit.models import *
from django.utils.timezone import now
from rest_framework.views import APIView



class OrgTypeListView(generics.ListAPIView):
    """
    to fetch organization type list api
    """
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch org_type list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrgTypes"
        )
        return super().list(request, *args, **kwargs)


class OrgTypeCreateView(generics.CreateAPIView):
    """
    to create new organization type view

    """
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name ="create new org_type"

    def perform_create(self, serializer):
        # Perform the normal creation
        org_type = serializer.save()
        registered_app_name = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Created OrgType: {org_type.org_type}"
        )

class OrgTypeRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
    To perform retrieval , update and delete for organization type
    """
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]
    permission_name = None  # Default permission name is None

    # Define permission names for each action
    permission_name_retrieve = "retrieve org_type"
    permission_name_update = "update org_type"
    permission_name_delete = "delete org_type"

    def get_permissions(self):
        # Set the correct permission name based on the action (retrieve, update, delete)
        if self.request.method == 'GET':
            self.permission_name = self.permission_name_retrieve
        elif self.request.method == 'PUT':
            self.permission_name = self.permission_name_update
        elif self.request.method == 'DELETE':
            self.permission_name = self.permission_name_delete

        return super().get_permissions()

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)

        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrgType: {instance.org_type}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # permission check
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        org_type = serializer.save()


        # Log the update action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Updated OrgType: {org_type.org_type}"
        )

    def perform_destroy(self, instance):
        # permission check
        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")


        # Log the delete action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrgType: {instance.org_type}"
        )
        super().perform_destroy(instance)


class OrganizationSectorListView(generics.ListAPIView):
    """
    to fetch organization sector list api
    """
    queryset = OrgSector.objects.all()
    serializer_class = OrgSectorSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch org sector list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrgSector"
        )
        return super().list(request, *args, **kwargs)


class OrganizationSectorCreateView(generics.CreateAPIView):
    """
    to create new organization sector view

    """
    queryset = OrgType.objects.all()
    serializer_class = OrgSectorSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name ="create new org sector"

    def perform_create(self, serializer):
        # Perform the normal creation
        sector = serializer.save()
        registered_app_name = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(sector.id),
            object_type=content_type,
            content_object=sector,
            details=f"Created Organization Sector: {sector.name}"
        )

class OrganizationSectorRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
    to perform retrieval , update and delete for organization type
    """
    queryset = OrgType.objects.all()
    serializer_class = OrgSectorSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]
    permission_name = None

    # Define permission names for each action
    permission_name_retrieve = "retrieve org sector"
    permission_name_update = "update org sector"
    permission_name_delete = "delete org sector"

    def get_permissions(self):
        # Set the correct permission name based on the action (retrieve, update, delete)
        if self.request.method == 'GET':
            self.permission_name = self.permission_name_retrieve
        elif self.request.method == 'PUT':
            self.permission_name = self.permission_name_update
        elif self.request.method == 'DELETE':
            self.permission_name = self.permission_name_delete

        return super().get_permissions()

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgSector)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Organization Sector: {instance.name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # permission check
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        sector = serializer.save()


        # Log the update action
        content_type = ContentType.objects.get_for_model(OrgSector)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(sector.id),
            object_type=content_type,
            content_object=sector,
            details=f"Updated Organization Sector: {sector.name}"
        )

    def perform_destroy(self, instance):
        # permission check
        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")


        # Log the delete action
        content_type = ContentType.objects.get_for_model(OrgSector)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Organization Sector: {instance.name}"
        )
        super().perform_destroy(instance)


class CreateOrganizationSectorFromExcelView(APIView):
    """
    to upload data through excel for Organization Sector
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        new_sector = []
        existing_sectors = set()

        for row in sheet.iter_rows(min_row=2, values_only=True):
            sector_name = row[0]

            if not sector_name:
                return Response({'error': 'Invalid data in the Excel file.'}, status=status.HTTP_400_BAD_REQUEST)

            if OrgSector.objects.filter(name=sector_name).exists():
                return Response({"error": f"Sector '{sector_name}' already exists."},status=status.HTTP_400_BAD_REQUEST )

            sector_data = {'name': sector_name}
            serializer = OrgSectorSerializer(data=sector_data)
            if serializer.is_valid():
                sector = serializer.save(created_by=request.user, updated_by=request.user)
                new_sector.append(sector)
                existing_sectors.add((sector_name))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                OrgSector.objects.bulk_create(new_sector)

            content_type = ContentType.objects.get_for_model(OrgSector)

            for sec in new_sector:
                AuditLogEntry.objects.create(
                    user=request.user,
                    application=registered_app_name,
                    action_type=ActionType.CREATE,
                    object_type=content_type,
                    object_id=str(len(new_sector)),
                    content_object=None,
                    details=f"Created {len(sec.name)} sector from Excel file."
                )

            return Response({'message': f"{len(new_sector)} Sector created successfully."},
                            status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OrganizationListView(generics.ListAPIView):
    """
    to get Organization list view
    """
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch organization list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List Organizations and log this action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Organizations"
        )
        return super().list(request, *args, **kwargs)


class OrganizationCreateView(generics.CreateAPIView):
    """
    to create new Organization
    """
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "create new organization"

    def perform_create(self, serializer):
        # Perform the normal creation
        organization = serializer.save()

        registered_app_name = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Created Organization: {organization.org_name}"
        )


class OrganizationRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
    to perform retrieval , update and delete for organization
    """
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]
    permission_name = None
    # Define permission names for each action
    permission_name_retrieve = "retrieve organization"
    permission_name_update = "update organization"
    permission_name_delete = "delete organization"

    def get_permissions(self):
        # Set the correct permission name based on the action (retrieve, update, delete)
        if self.request.method == 'GET':
            self.permission_name = self.permission_name_retrieve
        elif self.request.method == 'PUT':
            self.permission_name = self.permission_name_update
        elif self.request.method == 'DELETE':
            self.permission_name = self.permission_name_delete

        return super().get_permissions()

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the 'READ' action for this specific Organization retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Organization: {instance.org_name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # permission check
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        organization = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Updated Organization: {organization.org_name}"
        )

    def perform_destroy(self, instance):
        # permission check
        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the delete action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Organization: {instance.org_name}"
        )
        super().perform_destroy(instance)


class CreateOrganizationFromExcelView(APIView):
    """
    to upload data through excel for organization
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        
        new_organizations = []
        existing_organizations = set() # to track existing Organization
        
        for row in sheet.iter_rows(min_row=2, values_only=True):
            organization_name = row[0]
            org_type = row[1]
            
            if not organization_name or not org_type:
                return Response({'error': 'Invalid data in the Excel file.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if Organization.objects.filter(name=organization_name, org_type=org_type).exists():
                return Response({'error': f"Organization '{organization_name}' already exists for Organization Type '{org_type}'."},
                                status=status.HTTP_400_BAD_REQUEST)
            
            organization_data = {'name': organization_name, 'org_type': org_type}
            serializer = OrganizationSerializer(data=organization_data)
            if serializer.is_valid():
                organization = serializer.save(created_by=request.user, updated_by=request.user)
                new_organizations.append(organization)
                existing_organizations.add((organization_name, org_type))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
        
        try:
            with transaction.atomic():
                Organization.objects.bulk_create(new_organizations)
                
            content_type = ContentType.objects.get_for_model(Organization)

            for org in new_organizations:
                AuditLogEntry.objects.create(
                    user= request.user,
                    application=registered_app_name,
                    action_type=ActionType.CREATE,
                    object_type=content_type,
                    object_id=str(len(new_organizations)),
                    content_object=None,
                    details= f"Created {len(org.name)} organization from Excel file."
            )


            return Response({'message': f"{len(new_organizations)} Organization created successfully."}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OrganizationSubTypeListView(generics.ListAPIView):
    """
     to fetch organization Subtype list api
    """
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch organization sub_type list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List OrganizationSubTypes and log this action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrganizationSubTypes"
        )
        return super().list(request, *args, **kwargs)


class OrganizationSubTypeCreateView(generics.CreateAPIView):
    """
        to create new organization Subtype view

    """
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "create new organization sub_type"

    def perform_create(self, serializer):
        # Perform the normal creation
        organization_subtype = serializer.save()
        registered_app_name = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Created OrganizationSubType: {organization_subtype.org_sub_type}"
        )


class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
        to perform retrieval , update and delete for organization Subtype
    """
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]
    permission_name = None

    permission_name_retrieve = "retrieve organization sub_type"
    permission_name_update = "update organization sub_type"
    permission_name_delete = "delete organization sub_type"

    def get_permissions(self):
        # Set the correct permission name based on the action (retrieve, update, delete)
        if self.request.method == 'GET':
            self.permission_name = self.permission_name_retrieve
        elif self.request.method == 'PUT':
            self.permission_name = self.permission_name_update
        elif self.request.method == 'DELETE':
            self.permission_name = self.permission_name_delete

        return super().get_permissions()

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the 'READ' action for this specific OrganizationSubType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrganizationSubType: {instance.org_sub_type}"
        )
        return super().retrieve(request, *args, **kwargs)


    def perform_update(self, serializer):
        # permission check
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        organization_subtype = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Updated OrganizationSubType: {organization_subtype.org_sub_type}"
        )

    def perform_destroy(self, instance):
        # permission check
        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the delete action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrganizationSubType: {instance.org_sub_type}"
        )
        super().perform_destroy(instance)



class LocationListView(generics.ListAPIView):
    """
    to fetch location list api
    """
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name ="fetch locations list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(Locations)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Locations"
        )
        return super().list(request, *args, **kwargs)


class LocationCreateView(generics.CreateAPIView):
    """
    to create new location api
    """
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    permission_classes = [IsAuthenticated,HasApplicationUserPermission]

    permission_name ="create new locations"

    def perform_create(self, serializer):
        location = serializer.save()
        registered_app_name = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(location.id),
            object_type=content_type,
            content_object=location,
            details=f"Created OrgType: {location.location_name}"
        )


class LocationRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
        to perform retrieval , update and delete for location
    """
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    # Define permission names for each action
    permission_name_retrieve = "retrieve locations"
    permission_name_update = "update locations"
    permission_name_delete = "delete locations"

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(Locations)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Locations: {instance.locations.location_name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # permission check
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        location = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(Locations)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(location.id),
            object_type=content_type,
            content_object=location,
            details=f"Updated Location: {location.location_name}"
        )

    def perform_destroy(self, instance):
        # permission check
        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Log the delete action
        content_type = ContentType.objects.get_for_model(Locations)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Location: {instance.locations.location_name}"
        )
        super().perform_destroy(instance)



class CreateLocationFromExcelView(APIView):
    """
    to upload data through excel for location
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        new_locations = []
        existing_locations = set()

        for row in sheet.iter_rows(min_row=2, values_only=True):
            organization_type = row[0]
            organization_name = row[1]
            location_type = row[2]
            location_name = row[3]
            location_code = row[4]

            if not organization_type or not organization_name or not location_type or not location_name or not location_code:
                return Response({"error": "Invalid data in the Excel file."}, status=status.HTTP_400_BAD_REQUEST)

            if Locations.objects.filter(org_type=organization_type, org_name=organization_name, location_type=location_type,
                                        location_name=location_name,location_code=location_code).exists():
                return Response({"error": f"Location '{location_name}' already exists for Organization Type'{organization_type}' and Organization name '{organization_name}'."},
                                status=status.HTTP_400_BAD_REQUEST)

            location_data = {'org_type': organization_type,'org_name': organization_name, 'location_type': location_type,
                             'location_name': location_name, 'location_code': location_code }

            serializer = LocationsSerializer(data=location_data)
            if serializer.is_valid():
                location = serializer.save(created_by=request.user, updated_by=request.user)
                new_locations.append(location)
                existing_locations.add((organization_type, organization_name, location_type, location_name, location_code))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                Locations.objects.bulk_create(new_locations)

            content_type = ContentType.objects.get_for_model(Locations)

            for location in new_locations:
                AuditLogEntry.objects.create(
                    user=request.user,
                    application=registered_app_name,
                    action_type=ActionType.CREATE,
                    object_type=content_type,
                    object_id=str(len(new_locations)),
                    content_object=None,
                    details=f"Created {len(location.location_name)} location from Excel file."
                )

            return  Response({"message": f"{len(new_locations)}Location created successfully."}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DepartmentListView(generics.ListAPIView):
    """
    to get Department list view
    """
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name =" fetch department list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # list Department and log this action
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Department"
        )
        return super().list(request, *args, **kwargs)

class DepartmentCreateView(generics.CreateAPIView):
    """
    to create new Department
    """

    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "create new department"

    def perform_create(self, serializer):
        department = serializer.save()

        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(department.id),
            object_type=content_type,
            content_object=department,
            details=f"Created Department: {department.name}"
        )


class DepartmentRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
    to perform retrieval , update and delete for department
    """

    queryset = Department.objects.all()
    serializer_class =  DepartmentSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    # Define permission names for each action
    permission_name_retrieve = "retrieve department"
    permission_name_update = "update department"
    permission_name_delete = "delete department"

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Department: {instance.name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        department = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(department.id),
            object_type=content_type,
            content_object=department,
            details=f"Updated Department: {department.name}"
        )

    def perform_destroy(self, instance):

        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Department: {instance.name}"
        )
        super().perform_destroy(instance)

class CreateDepartmentFormExcelView(APIView):
    """
    to upload data through excel for department
    """

    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        new_department = []
        existing_departments = set()  # to track existing Departments

        for row in sheet.iter_rows(min_row=2, values_only=True):
            department_name = row[0]


            if not department_name :
                return Response({'error': 'Invalid data in the Excel file.'}, status=status.HTTP_400_BAD_REQUEST)

            if Department.objects.filter(name=department_name).exists():
                return Response(
                    {'error': f"Department '{department_name}' already exists."},
                    status=status.HTTP_400_BAD_REQUEST)

            department_data = {'name': department_name}
            serializer = DepartmentSerializer(data=department_data)
            if serializer.is_valid():
                department = serializer.save(created_by=request.user, updated_by=request.user)
                new_department.append(department)
                existing_departments.add((department_name))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                Department.objects.bulk_create(new_department)

            content_type = ContentType.objects.get_for_model(Department)

            for dept in new_department:
                AuditLogEntry.objects.create(
                    user=request.user,
                    application=registered_app_name,
                    action_type=ActionType.CREATE,
                    object_type=content_type,
                    object_id=str(len(new_department)),
                    content_object=None,
                    details=f"Created {len(dept.name)} department from Excel file."
                )

            return Response({'message': f"{len(new_department)} Department created successfully."},
                            status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DesignationListView(generics.ListAPIView):
    """
        to get Designation list view
        """
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch designation list"

    def list(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        # list Department and log this action
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Designation"
        )
        return super().list(request, *args, **kwargs)


class DesignationCreateView(generics.CreateAPIView):
    """
    to create new Designation
    """

    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "create new designation"

    def perform_create(self, serializer):
        designation = serializer.save()

        registered_app_name = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Department)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(designation.id),
            object_type=content_type,
            content_object=designation,
            details=f"Created Designation: {designation.name}"
        )


class DesignationRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    """
    to perform retrieval , update and delete for designation
    """

    queryset = Designation.objects.all()
    serializer_class =  DepartmentSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    # Define permission names for each action
    permission_name_retrieve = "retrieve designation"
    permission_name_update = "update designation"
    permission_name_delete = "delete designation"

    def perform_retrieve(self, request, *args, **kwargs):
        # permission check
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)
        registered_app_name = Application.objects.get(name="Auth Server")

        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(Designation)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Designation: {instance.name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        # Perform the normal update
        designation = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(Designation)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(designation.id),
            object_type=content_type,
            content_object=designation,
            details=f"Updated Designation: {designation.name}"
        )

    def perform_destroy(self, instance):

        self.permission_name = self.permission_name_delete
        self.check_permissions(self.request)
        registered_app_name = Application.objects.get(name="Auth Server")

        content_type = ContentType.objects.get_for_model(Designation)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=registered_app_name,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Designation: {instance.name}"
        )
        super().perform_destroy(instance)

class CreateDesignationFormExcelView(APIView):
    """
    to upload data through excel for designation
    """

    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request, *args, **kwargs):
        registered_app_name = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file)
            sheet = wb.active
        except Exception as e:
            return Response({"error": f"Error reading file: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        new_designation = []
        existing_designation = set()  # to track existing Departments

        for row in sheet.iter_rows(min_row=2, values_only=True):
            designation_name = row[0]


            if not designation_name :
                return Response({'error': 'Invalid data in the Excel file.'}, status=status.HTTP_400_BAD_REQUEST)

            if Designation.objects.filter(name=designation_name).exists():
                return Response(
                    {'error': f"Designation '{designation_name}' already exists."},
                    status=status.HTTP_400_BAD_REQUEST)

            designation_data = {'name': designation_name}
            serializer = DepartmentSerializer(data=designation_data)
            if serializer.is_valid():
                department = serializer.save(created_by=request.user, updated_by=request.user)
                new_designation.append(department)
                existing_designation.add((designation_name))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                Designation.objects.bulk_create(new_designation)

            content_type = ContentType.objects.get_for_model(Department)

            for desg in new_designation:
                AuditLogEntry.objects.create(
                    user=request.user,
                    application=registered_app_name,
                    action_type=ActionType.CREATE,
                    object_type=content_type,
                    object_id=str(len(new_designation)),
                    content_object=None,
                    details=f"Created {len(desg.name)} Designation from Excel file."
                )

            return Response({'message': f"{len(new_designation)} Designation created successfully."},
                            status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



"""
all open api related to user registration form for populating
dropdown menus in the form 
"""

class DesignationOpenAPIView(generics.ListAPIView):
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    permission_classes = [AllowAny]

class DepartmentOpenAPIView(generics.ListAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [AllowAny]

class OrgTypeOpenAPIView(APIView):
    permission_classes = [AllowAny]
    def get(self, request, *args, **kwargs):
        org_types = Organization.objects.values_list('org_type', flat=True).distinct()
        return Response(org_types, status=status.HTTP_200_OK)

class OrganizationNameOpenAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            organizations = Organization.objects.filter(org_type=org_type)
        else:
            organizations = Organization.objects.filter(org_type=org_type)
        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)


class OrgSubTypeOpenAPIView(APIView):
    permission_classes = [AllowAny]
    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        print("ptr orgtype",org_type)
        if org_type:
            subtypes = OrganizationSubType.objects.filter(org_type=org_type)
        else:
            subtypes = OrganizationSubType.objects.filter(org_type=org_type)
        serializer = OrgSubTypeSerializer(subtypes, many=True)
        return Response(serializer.data)


class LocationTypeOpenAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        if org_name:
            location_type = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
        else:
            location_type = Locations.objects.values_list('location_type', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)

class LocationNameOpenAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')

        if org_name and location_type:
            location_queryset = Locations.objects.filter(org_name=org_name, location_type=location_type).values('location_name')
        else:
            location_queryset = Locations.objects.filter(org_name=org_name).values('location_name')

        location_names = list(location_queryset)  # Convert queryset to a list of dictionaries

        return Response(location_names, status=status.HTTP_200_OK)



class LocationCodeOpenAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')
        location_name = request.query_params.get('location_name')

        if org_name and location_type and location_name:
            location_type = Locations.objects.filter(org_name=org_name, location_type=location_type, location_name=location_name).values_list('location_code', flat=True).distinct()
        else:
            location_type = Locations.objects.filter(org_name=org_name,location_name=location_name).values_list('location_code', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)
