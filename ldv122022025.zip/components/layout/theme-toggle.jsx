"use client";
import { Moon, Sun } from "lucide-react";
import { Switch } from "../ui/switch";
import { useTheme } from "next-themes";

export function ThemeToggle() {
    const { setTheme, theme } = useTheme();

    // Determine if the current theme is dark
    const isDarkMode = theme === "dark";

    const toggleTheme = (checked) => {
        setTheme(checked ? "dark" : "light");
    };

    return (
        <div className="flex items-center">
            <Switch 
                checked={isDarkMode} 
                onCheckedChange={toggleTheme} 
                className="mr-2" 
            />
            <span className="sr-only">Toggle theme</span>
            {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </div>
    );
}
