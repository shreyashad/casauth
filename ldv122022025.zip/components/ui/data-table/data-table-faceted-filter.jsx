"use client";
import { Check, PlusCircle } from "lucide-react";
import { Badge } from "../badge";
import { Button } from "../button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "../command";
import { Popover, PopoverContent, PopoverTrigger } from "../popover";
import { Separator } from "../separator";
import { cn } from "@/lib/utils";


function getNestedValue(obj, path) {
    return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export function DataTableFacetedFilter({ column, title }) {
    
    const facets = column?.getFacetedUniqueValues();
    console.log("facets data:",facets);
    const selectedValues = new Set(column?.getFilterValue() || []);
    

    const generateFilterOptions = () => {
        const options = [];
        const values = facets?.get(column.id);

        if (values) {
            values.forEach((value) => {
                let displayValue = value;
                if (typeof value === 'string' && value.includes('.')) {
                    displayValue = getNestedValue(value, value);
                }
                options.push({
                    label: displayValue,
                    value: value
                });
            });
        }

        return options;
    };

    return(
        <Popover>
            <PopoverTrigger asChild>
                <Button 
                    variant="outline"
                >
                    <PlusCircle />
                    {title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge variant="secondary" className="rounded-sm px-1 font-normal lg:hidden">
                                {selectedValues.size}
                            </Badge>
                            <div className="hidden space-x-1 lg:flex">
                                {selectedValues.size > 2 ? (
                                    <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                        {selectedValues.size} selected
                                    </Badge>
                                ): (
                                    generateFilterOptions().map((option) => (
                                        <Badge variant="secondary" key={option.value} className="rounded-sm px-1 font-normal">
                                            {option.label}
                                        </Badge>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder={title} />
                    <CommandList>
                        <CommandEmpty>No Result found</CommandEmpty>
                        <CommandGroup>
                            {generateFilterOptions().map((option) => {
                                const isSelected = selectedValues.has(option.value);
                                return(
                                    <CommandItem
                                        key={option.value}
                                        onSelect={() => {
                                            if (isSelected) {
                                                selectedValues.delete(option.value);
                                            } else {
                                                selectedValues.add(option.value);
                                            }
                                            const filterValues = Array.from(selectedValues);
                                            column?.setFilterValue(
                                                filterValues.length ? filterValues : undefined
                                            );
                                        }}
                                    
                                    >
                                        <div className={cn(
                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                            isSelected ? "bg-primary text-primary-foreground" : "opacity-50 [&_svg]:invisible"
                                        )}>
                                            <Check />
                                        </div>
                                        {/* {option.icon && (
                                            <option.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                        )} */}
                                        <span>{option.label}</span>
                                        {/* {facets?.get(option.value) && (
                                            <span className="ml-auto flex h-4 w-4 items-center justify-center font-mono text-xs">
                                                {facets.get(option.value)}
                                            </span>
                                        )} */}
                                    </CommandItem>
                                );
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem onSelect={() => column?.setFilterValue(undefined)} className="justify-center text-center">
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    );
}