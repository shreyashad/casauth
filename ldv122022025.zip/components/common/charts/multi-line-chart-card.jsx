"use client";

import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const MultiLineChartCard = ({ title, description, data, lines }) => {
    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="mb-5">
                    <p>{description}</p>
                </div>
                <div className="w-full h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="time" />
                            <YAxis />
                            <Tooltip />
                            {/* Render lines dynamically based on the `lines` prop */}
                            {lines.map((line, index) => (
                                <Line
                                    key={index}
                                    type="monotone"
                                    dataKey={line.dataKey}
                                    stroke={line.color}
                                    strokeWidth={2}
                                    name={line.name}
                                />
                            ))}
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
};
