"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const BarChartCard = ({ title, description, data, color }) => {
    return (
        <Card className="border-2 shadow-lg">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="status_code" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill={color} />
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
};
