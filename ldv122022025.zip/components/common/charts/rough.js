// components/PieChartCard.tsx
import React from 'react';
import { PieChart, Pie, Tooltip, Cell, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";  // Assuming you have these UI components already defined in your project.

interface PieChartCardProps {
  title: string;
  description: string;
  data: { name: string; value: number }[]; // Data structure for Pie Chart
  colors?: string[]; // Optional: Custom colors for each segment of the pie chart
}

const PieChartCard: React.FC<PieChartCardProps> = ({ title, description, data, colors = [] }) => {
  
  // Default colors for the chart if no custom colors are provided
  const defaultColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF6347', '#4682B4'];

  return (
    <Card className="border-2 shadow-lg">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="p-4">
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              outerRadius="80%" // You can adjust this to your preference
              label
            >
              {/* Render segments with custom colors */}
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index] || defaultColors[index % defaultColors.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default PieChartCard;
<!-- src/components/PieChartCard.js -->
import React from 'react';
import { PieChart, Pie, Tooltip, Cell, ResponsiveContainer, Legend, AnimationDuration } from 'recharts';

// Default colors in case custom colors are not provided
const defaultColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF6347', '#4682B4'];

const PieChartCard = ({ title, description, data, colors = [], onSliceClick }) => {
  
  // Default slice colors
  const chartColors = colors.length ? colors : defaultColors;

  return (
    <div className="pie-chart-card border-2 shadow-lg rounded-md p-4">
      <div className="card-header">
        <h3 className="text-xl font-bold">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
      
      <div className="card-content mt-4">
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              outerRadius="80%"
              label
              onClick={onSliceClick} // Handler for slice click
              animationDuration={1000} // Animation duration (1 second)
            >
              {/* Rendering slices with custom colors */}
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend verticalAlign="bottom" height={36} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PieChartCard;
---------
"use client";

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Pie, PieChart, Cell } from "recharts";


// Component to render the Pie chart
export function PieChartCard({ data, title, description, chartConfig }) {
  // Handle empty or invalid data
  if (!data || !data.result || data.result.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "20px" }}>
        <h2>No Data Available</h2>
      </div>
    );
  }

  // Dynamically extract values for the Pie chart using keys from chartConfig
  const chartData = chartConfig.map((item) => {
    const { key, name, fill } = item;
    const value = data.result[0][key] || 0; // If the key doesn't exist, default to 0
    return { name, value, fill };
  });

  return (
    <Card className="flex flex-col" style={{ width: '30%' }}>
      <CardHeader className="items-center pb-1">
        <CardTitle className="text-m font-bold">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        <ChartContainer
          className="mx-auto aspect-square max-h-[250px] pb-0 [&_.recharts-pie-label-text]:fill-foreground"
          style={{ width: "100%" }}
        >
          <PieChart>
            <ChartTooltip content={<ChartTooltipContent hideLabel />} />
            <Pie
              data={chartData}
              dataKey="value"
              label={({ name, value, percent }) =>
                `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
              }
              nameKey="name"
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
          </PieChart>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col gap-2 text-sm">
        {/* Add legends */}
        <div className="mt-4 flex gap-4">
          {chartData.map((entry, index) => (
            <div key={index} className="flex items-center">
              <div
                style={{
                  width: "12px",
                  height: "12px",
                  backgroundColor: entry.fill,
                  marginRight: "8px",
                }}
              ></div>
              <span>{entry.name}</span>
            </div>
          ))}
        </div>
      </CardFooter>
    </Card>
  );
}
-------------
// components/LineChartCard.js

import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

interface LineChartCardProps {
  title: string;
  data: { name: string; value: number }[];
  color: string;
}

const LineChartCard: React.FC<LineChartCardProps> = ({
  title,
  data,
  color,
}) => {
  return (
    <Card className="h-[200px]">
      <CardHeader title={title} />
      <CardContent className="flex-1 overflow-hidden">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart width={500} height={300} data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="value" stroke={color} />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default LineChartCard;

totalRequestsOverTime data: [
  { time_bucket: '2025-01-10T00:00:00+05:30', total_requests: 2536 },
  { time_bucket: '2025-01-11T00:00:00+05:30', total_requests: 4412 },
  { time_bucket: '2025-01-13T00:00:00+05:30', total_requests: 1997 },
  { time_bucket: '2025-01-15T00:00:00+05:30', total_requests: 8312 },
  { time_bucket: '2025-01-16T00:00:00+05:30', total_requests: 12142 },
  { time_bucket: '2025-01-17T00:00:00+05:30', total_requests: 13679 },
  { time_bucket: '2025-01-18T00:00:00+05:30', total_requests: 7530 },
  { time_bucket: '2025-01-20T00:00:00+05:30', total_requests: 607 },
  { time_bucket: '2025-01-21T00:00:00+05:30', total_requests: 2356 },
  { time_bucket: '2025-01-22T00:00:00+05:30', total_requests: 358 },
  { time_bucket: '2025-01-23T00:00:00+05:30', total_requests: 2732 }
]

"use client";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
} from "recharts";

export const ResourceUsageChart = ({ title, description, chartData }) => {
  const { cpu_usage, memory_usage, disk_usage, usage_trends } = chartData;

  // CPU & Memory usage data for the PieChart
  const pieData = [
    { name: "CPU Usage", value: cpu_usage },
    { name: "Memory Usage", value: memory_usage },
  ];

  const COLORS = ["#FF6384", "#36A2EB"];

  // Disk usage data for the BarChart
  const barData = [
    { name: "Disk Usage", value: disk_usage },
  ];

  // Resource usage trends data for the LineChart
  const lineData = usage_trends.map((item) => ({
    time: item.time,
    usage: item.usage,
  }));

  return (
    <div className="p-6 bg-card shadow-sm rounded-md space-y-6">
      <h3 className="text-lg font-semibold text-card-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* PieChart for CPU & Memory Usage */}
        <div className="flex flex-col items-center">
          <h4 className="text-base font-medium mb-4 text-muted-foreground">
            CPU & Memory Usage
          </h4>
          <PieChart width={200} height={200}>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
              label
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </div>

        {/* BarChart for Disk Usage */}
        <div className="flex flex-col items-center">
          <h4 className="text-base font-medium mb-4 text-muted-foreground">
            Disk Usage
          </h4>
          <BarChart width={250} height={200} data={barData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#4BC0C0" />
          </BarChart>
        </div>

        {/* LineChart for Usage Trends Over Time */}
        <div className="flex flex-col items-center">
          <h4 className="text-base font-medium mb-4 text-muted-foreground">
            Usage Trends Over Time
          </h4>
          <LineChart width={300} height={200} data={lineData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="usage" stroke="#8884d8" strokeWidth={2} />
          </LineChart>
        </div>
      </div>
    </div>
  );
};
