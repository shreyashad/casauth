"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { toast } from "sonner";

const defaultColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF6347', '#4682B4'];

export const PieChartCard = ({ title, description, data, colors = [], onSliceClick }) => {
    const [clickedSlice, setClickedSlice] = useState(null);
    const chartColors = colors.length ? colors : defaultColors;

    const handleSliceClick = (data) => {
        setClickedSlice(data); // Update state with clicked slice data
        toast(`You clicked on the ${data.name} slice!`); // Show an alert or handle as needed
    };


    return (
        <Card className="border-2 shadow-lg">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-5">
                    {/* Left side: Pie chart */}
                    <div className="flex justify-center items-center">
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={data}
                                    dataKey="value"
                                    nameKey="name"
                                    outerRadius="80%"
                                    label
                                    onClick={handleSliceClick} // Handler for slice click
                                    animationDuration={1000}
                                >
                                    {data.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
                                    ))}
                                </Pie>
                            </PieChart>
                            <Tooltip />
                            <Legend verticalAlign="bottom" height={36} />
                        </ResponsiveContainer>
                    </div>
                    {/* Right side: Table */}
                    <div className="overflow-x-auto">
                        <table className="min-w-full table-auto border-collapse">
                            <thead>
                                <tr>
                                    <th className="border-b py-2 px-4 text-left">Name</th>
                                    <th className="border-b py-2 px-4 text-left">Value</th>
                                    <th className="border-b py-2 px-4 text-left">Color</th> {/* New column for color */}
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((entry, index) => (
                                    <tr key={index}>
                                        <td className="border-b py-2 px-4">{entry.name}</td>
                                        <td className="border-b py-2 px-4">{entry.value}</td>
                                        {/* Add a cell for the color representation */}
                                        <td className="border-b py-2 px-4">
                                            <div
                                                style={{
                                                    width: '20px',
                                                    height: '20px',
                                                    backgroundColor: chartColors[index % chartColors.length],
                                                    margin: '0 auto',
                                                }}
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                {clickedSlice && (
                    <div className="mt-4">
                        <h3 className="text-lg font-bold">Clicked Slice:</h3>
                        <p>Name: {clickedSlice.name}</p>
                        <p>Value: {clickedSlice.value}</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

