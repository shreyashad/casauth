"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const ResourceUsageChart = ({ title, description, chartData }) => {
    

    const COLORS = ["#FF6384", "#36A2EB"];
    const pieData = [
        { name: "CPU Usage", value: chartData.cpu_usage },
        { name: "Memory Usage", value: chartData.memory_usage },
    ];

    const barData = [
        { name: "Disk Usage", value: chartData.disk_usage },
    ];
    
    const lineData = [
        {
            time: new Date(chartData.timestamp).toLocaleTimeString(), // Format timestamp as readable time
            bytes_sent: chartData.network_io.bytes_sent,
            bytes_recv: chartData.network_io.bytes_recv,
        },
    ];

    console.log("piechartdata :", pieData);
    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 grid-rows-2 gap-5">
                    {/* Pie Chart */}
                    <div className="flex justify-center items-center">
                        <div className="w-full h-[300px]">
                        <h4 className="text-base font-medium mb-4 text-muted-foreground">
                             CPU & Memory Usage
                        </h4>
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={pieData}
                                        dataKey="value"
                                        nameKey="name"
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={50}
                                        outerRadius={80}
                                        paddingAngle={5}
                                        label
                                    >
                                        {pieData.map((entry, index) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={COLORS[index % COLORS.length]}
                                            />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                    <div className="flex flex-col items-center">
                        <h4 className="text-base font-medium mb-4 text-muted-foreground">
                            Disk Usage
                        </h4>
                        <BarChart width={250} height={200} data={barData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="value" fill="#4BC0C0" />
                        </BarChart>
                    </div>
                    <div className="col-span-2">
                      <div className="flex flex-col items-center">
                        <h4 className="text-base font-medium mb-4 text-muted-foreground">
                             Usage Trends Over Time
                        </h4>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={lineData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="time" />
                                    <YAxis />
                                    <Tooltip />
                                    {/* Bytes Sent */}
                                    <Line type="monotone" dataKey="bytes_sent" stroke="#FF6384" strokeWidth={2} name="Bytes Sent" />
                                    {/* Bytes Received */}
                                    <Line type="monotone" dataKey="bytes_recv" stroke="#36A2EB" strokeWidth={2} name="Bytes Received" />
                                </LineChart>
                            </ResponsiveContainer>
                       </div>                

                    </div>
                </div>
            </CardContent>
        </Card>
    );
};
