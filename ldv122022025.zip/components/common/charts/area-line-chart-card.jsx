"use client";

import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Area, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const AreaLineCardCard = ({ title, description, data, lines, areas }) => {
    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="mb-5">
                    <p>{description}</p>
                </div>
                <div className="w-full h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="time" />
                            <YAxis />
                            <Tooltip />
                            {/* Render areas dynamically */}
                            {areas &&
                                areas.map((area, index) => (
                                    <Area
                                        key={index}
                                        type="monotone"
                                        dataKey={area.dataKey}
                                        stroke={area.color}
                                        fill={area.fillColor}
                                        strokeWidth={2}
                                        name={area.name}
                                    />
                                ))}
                            {/* Render lines dynamically */}
                            {lines &&
                                lines.map((line, index) => (
                                    <Line
                                        key={index}
                                        type="monotone"
                                        dataKey={line.dataKey}
                                        stroke={line.color}
                                        strokeWidth={2}
                                        name={line.name}
                                    />
                                ))}
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
};
