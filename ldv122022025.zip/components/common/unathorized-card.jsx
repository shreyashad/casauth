"use client";
import React from "react";


import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";

const UnauthorizedErrorCard = ({ message, redirectUrl }) => {
  const router = useRouter();

  const handleRedirect = () => {
    // Redirect the user to the specified URL (could vary based on user type)
    router.push(redirectUrl);
  };

  return (
    <div className="flex flex-1 flex-col gap-4 p-4  justify-center items-center bg-gray-100">
      <Card className="max-w-sm w-full bg-white shadow-lg rounded-lg">
        <CardHeader>
          <CardTitle className="text-red-500 text-lg font-semibold">Error</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700">{message}</p>
        </CardContent>
        <div className="p-4 flex justify-end">
          <Button variant="outline" color="blue" onClick={handleRedirect}>
            Go to Dashboard
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default UnauthorizedErrorCard;
