"use client";
import { useState } from "react";
import { Calendar } from "../ui/calendar";

export function CalendarComponent() {
    const [date, setDate] = useState(new Date);
    return(
        <div className="w-full max-w-md mx-auto p-4">
            <div className="rounded-lg border shadow-lg overflow-hidden">
                <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="w-full" // Ensures it is responsive
                />
            </div>
        </div>
    );
};