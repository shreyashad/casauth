"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { AlertModal } from "@/components/common/alert-modal";
import { deleteDifficultyLevelDetails } from "@/services/trainers-admin/course-managment/course_management_api";
import { toast } from "@/hooks/use-toast";



export function CourseLevelsCellAction({ data }) {
    const router = useRouter();
    const { data: session } = useSession();
    const [alertModalOpen, setAlterModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/${data.id}`);
    }

    const deleteCousesLevel = async () => {
        try {
            await deleteDifficultyLevelDetails(session.accessToken, data.id);
            toast.success("Course Level deleted successfully");
            router.refresh(); 
        } catch (error) {
            toast.error("Error while deleting Course Level");
        }
    };

    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Course Levels</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={() => {
                                setAlterModalOpen(true);
                             }}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Course Levels</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <AlertModal 
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlterModalOpen(false)}
                onConfirm={() => deleteCousesLevel(data.id)}
                loading={false}
            />

        </div>
    );
}