"use client";
import { AlertModal } from "@/components/common/alert-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DifficultyLevelFormSchema } from "@/schema";
import { createNewDifficultyLevelData, deleteDifficultyLevelDetails, updateDifficultyLevelDetails } from "@/services/trainers-admin/course-managment/course_management_api";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

const statusOptions = [
    { value: "Draft", label: "Draft" },
    { value: "Published", label: "Published" },
    { value: "Archived", label: "Archived" },
];

export const DifficultyLevelForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const title = initialData && initialData.id ? "Edit Difficulty Level" : "Create Difficulty Level";
    const description = initialData && initialData.id ? "Edit an Difficulty Level" : "Create a new Difficulty Level";
    const toastMessage = initialData && initialData.id ? "Difficulty Level updated successfully" : "Difficulty Level created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";



    const form = useForm({
        resolver: zodResolver(DifficultyLevelFormSchema),
        defaultValues: initialData || {
            name: "",
            status: "Draft",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async(values) => {
       try {
            setLoading(true);
            if (initialData && initialData.id) {
                const updateForm = await updateDifficultyLevelDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateForm);
            } else {
                const newData = await createNewDifficultyLevelData(session.accessToken, values);
                console.log("Create Response:", newData);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/`)
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.response ? error.response.data : error.message);
        } finally {
            setLoading(false);
        }
    };

    const onDelete = async () => {
        try {
            setLoading(true);
            await deleteDifficultyLevelDetails(session.accessToken, initialData.id);
            toast.success("Course Level deleted successfully")
            router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/`);
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };



    return(
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField 
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel> Difficulty Level</FormLabel>
                                        <FormControl>
                                            <Input 
                                                {...field}
                                                placeholder="Name"

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="status"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Status</FormLabel>
                                        <FormControl>
                                            <Select
                                                onValueChange={field.onChange}
                                                defaultValue={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Select status" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {statusOptions.map((status) => (
                                                        <SelectItem key={status.value} value={status.value}>
                                                            {status.label}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
                {initialData && initialData.id && (
                    <AlertModal 
                        title="Are you Sure!"
                        description="This actions can not be undone."
                        name={initialData?.name}
                        isOpen={open}
                        onClose={() => setOpen(false)}
                        onConfirm={onDelete}
                        loading={loading}
                    />
                )}
            </CardContent>
        </Card>
    );
};