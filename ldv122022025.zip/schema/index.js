// defining schema for course management system 

import { z } from "zod";


export const StatusSchema = z.enum([
    "Draft",
    "Published",
    "Inactive",
    "Archived",
    "Retired",
    "Pending Approval",
    "Rejected",
  ]);

// for difficulty level 

export const DifficultyLevelFormSchema = z.object({
    name: z.string()
    .min(4, { message: "Name must be at least 4 characters" })
    .nonempty({ message: "Name is required" }),
    status: StatusSchema.default("Draft"),
});