"use cleint";
import { SonnerToaster } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";


const Providers = ({ children }) => {
    return(
        <ThemeProvider attribute="class" enableSystem={false} defaultTheme="light">
            <div>
                { children }
                <Toaster />
            </div>
            <SonnerToaster />
        </ThemeProvider>
    );
};

export default Providers;