import axios from "axios";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export async function fetchDifficultyLevelListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/difficulty-level-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching difficulty level list data:", error);
        // if (error.response && error.response.status === 403) {
        //     throw new Error("You do not have access to this part of the application.");
        // }
        // throw new Error('Failed to fetch difficulty level list data:',error);
    }
};

export async function createNewDifficultyLevelData(accessToken, newData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-new-difficulty-level/`, newData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        console.log("sending data:", response);
        return response.data;
    } catch (error) {
        console.error("Error creating new difficulty level data:", error.response ? error.response.data : error.message);
        if (error.response && error.response.status === 403) {
            throw new Error("You do not have access to this part of the application.");
        }
        throw new Error('Failed create new difficulty level data:',error.response ? error.response.data : error.message);
    }
};

export async function fetchDifficultyLevelDetails(accessToken, difficultyId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/difficulty-level/${difficultyId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching difficulty level details data:", error.response ? error.response.data : error.message);
        if (error.response && error.response.status === 403) {
            throw new Error("You do not have access to this part of the application.");
        }
        throw new Error('Failed to fetching difficulty level details:', error.response ? error.response.data : error.message);
    }
};


export async function updateDifficultyLevelDetails(accessToken,  difficultyId, updateData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/difficulty-level/${difficultyId}/details/`, orgData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating org type details:", error.response ? error.response.data : error.message);
        if (error.response && error.response.status === 403) {
            throw new Error("You do not have access to this part of the application.");
        }
        throw new Error('Failed to update org type details:',error.response ? error.response.data : error.message);
        
    }
};


export async function deleteDifficultyLevelDetails(accessToken, difficultyId) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/difficulty-level/${difficultyId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting org type details:", error.response ? error.response.data : error.message);
        if (error.response && error.response.status === 403) {
            throw new Error("You do not have access to this part of the application.");
        }    
        throw new Error('Failed to delete org type details:',error.response ? error.response.data : error.message);
       
    }
};
