import axios from "axios";
import { signOut } from "next-auth/react";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";



export async function handleSignOut(accessToken, sessionKey) {
    try {
        // Step 1: Notify backend to log out
        if (accessToken && sessionKey) {
            console.log("Logging out with accessToken and sessionKey...");
            await axios.post(
                `${API_BASE_URL}api/user-logout/`,
                {}, // No body needed
                {
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                        "X-Session-Key": sessionKey, // Include session key in the headers
                    },
                }
            );
        } else {
            console.warn("Access token or session key missing. Backend logout skipped.");
        }
    } catch (error) {
        console.error("Error logging out from backend:", error.response?.data || error.message);
    }

    // Step 2: Clear session on frontend
    await signOut({ redirect: true });

    // Step 3: Remove stored tokens and session keys
    localStorage.removeItem("access_token");
    localStorage.removeItem("session_key");
    console.log("Successfully logged out on frontend.");
}


export async function PasswordExpiredChangePassword(formData) { 
    try{
        const response = await axios.post(`${API_BASE_URL}api/password-expired-change-password/`,formData);
        return response.data;

    } catch (error) {
        
        console.log("error while changing the password:", error);
        throw new Error(error.response.data);
    }
};