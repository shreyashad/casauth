"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import axios from "axios";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { FcHighPriority } from "react-icons/fc";
import { useToast } from "@/hooks/use-toast";
import { PasswordExpiredChangePassword } from "@/services/auth/auth_api";

// ✅ Zod Validation Schema
const formSchema = z
  .object({
    username: z.string().min(1, "Username is required"),
    emp_code: z.string().min(1, "Employee code is required"),
    old_password: z.string().min(6, "Old password must be at least 6 characters"),
    new_password: z.string().min(6, "New password must be at least 6 characters"),
    confirm_password: z.string().min(6, "Confirm password must be at least 6 characters"),
  })
  .refine((data) => data.new_password === data.confirm_password, {
    message: "New password and confirm password do not match",
    path: ["confirm_password"],
  });

export default function ChangePasswordForm() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(formSchema),
  });

  // ✅ Submit Handler
  const onSubmit = async (data) => {
    setLoading(true);
    try {
      const response = await PasswordExpiredChangePassword(data);
      
      toast({ title: "Success", description: response.data.message, variant: "success" });
    } catch (error) {
      const errorMessage = error.response?.data?.error || "Something went wrong!";
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <Card className="max-w-md mx-auto p-6 shadow-lg">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Change Your Password</CardTitle>
        <CardDescription className="flex items-center text-black space-x-2">
          <FcHighPriority className="h-5 w-5" />
          <span>
            <span className="text-red-500 font-semibold">Your account was locked</span> because your password has expired!
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Username */}
          <div>
            <Label htmlFor="username">Username</Label>
            <Input id="username" {...register("username")} placeholder="Enter your username" />
            {errors.username && <p className="text-red-500 text-sm">{errors.username.message}</p>}
          </div>

          {/* Employee Code */}
          <div>
            <Label htmlFor="emp_code">Employee Code</Label>
            <Input id="emp_code" {...register("emp_code")} placeholder="Enter your employee code" />
            {errors.emp_code && <p className="text-red-500 text-sm">{errors.emp_code.message}</p>}
          </div>

          {/* Old Password */}
          <div>
            <Label htmlFor="old_password">Old Password</Label>
            <Input id="old_password" type="password" {...register("old_password")} placeholder="Enter your old password" />
            {errors.old_password && <p className="text-red-500 text-sm">{errors.old_password.message}</p>}
          </div>

          {/* New Password */}
          <div>
            <Label htmlFor="new_password">New Password</Label>
            <Input id="new_password" type="password" {...register("new_password")} placeholder="Enter new password" />
            {errors.new_password && <p className="text-red-500 text-sm">{errors.new_password.message}</p>}
          </div>

          {/* Confirm Password */}
          <div>
            <Label htmlFor="confirm_password">Confirm Password</Label>
            <Input id="confirm_password" type="password" {...register("confirm_password")} placeholder="Confirm new password" />
            {errors.confirm_password && <p className="text-red-500 text-sm">{errors.confirm_password.message}</p>}
          </div>

          {/* Submit Button */}
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Updating..." : "Change Password"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
