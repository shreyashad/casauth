// auth/errors.js

class CustomAuthError extends Error {
    constructor(code, message, status) {
      super(message);
      this.name = 'CustomAuthError';
      this.code = code;
      this.status = status;
    }
  }
  
  const AUTH_ERRORS = {
    INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
    SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
    VALIDATION_FAILED: 'VALIDATION_FAILED',
    INTERNAL_ERROR: 'INTERNAL_ERROR',
    APPLICATION_ERROR: 'APPLICATION_ERROR'
  };
  
  module.exports = { CustomAuthError, AUTH_ERRORS };
  