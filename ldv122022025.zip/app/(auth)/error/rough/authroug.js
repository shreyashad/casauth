old file code 
async authorize(credentials) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/login/`, {
            username: credentials.username,
            password: credentials.password,
        });
        console.log("response data of authorize:", response.data);
        if (response.status === 200) {
            return {
                accessToken: response.data.access_token,
                refreshToken: response.data.refresh_token,
                user: response.data.user,
                sessionKey: response.data.sessionKey,
                sessionExp: response.data.sessionExp,
            };
        } else {
            return null
        }
    } catch (error) {
        console.error("Authentication failed:", error.response?.data?.error || error.message);
        throw new Error(error.response.data)
    }
}


async authorize(credentials) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/login/`, {
            username: credentials.username,
            password: credentials.password,
        });

        console.log("Response data of authorize:", response.data);

        if (response.status === 200) {
            return {
                accessToken: response.data.access_token,
                refreshToken: response.data.refresh_token,
                user: response.data.user,
                sessionKey: response.data.sessionKey,
                sessionExp: response.data.sessionExp,
            };
        } else {
            // Handle non-200 status codes (DRF Errors)
            const error = new Error(response.data.error || "Login failed"); // Use DRF error or generic message
            error.status = response.status; // Add status to the error object
            throw error; // Re-throw to be caught by the catch block
        }
    } catch (error) {
        console.error("Authentication failed:", error.response?.data?.error || error.message);

        // Construct a more informative error object for NextAuth
        let errorMessage = "Authentication failed: ";

        if (error.response?.data?.error) {
          if(typeof error.response.data.error === 'object'){
            errorMessage += Object.values(error.response.data.error).join('\n')
          }else{
            errorMessage += error.response.data.error;
          }
        } else if (error.status === 401) {  // Example: Handle 401 Unauthorized
          errorMessage += "Invalid credentials."; // Customize as needed
        } else if (error.message.includes('Password expired')) { // Example: check for a specific message
          errorMessage += "Password expired. Please update your password.";
        } else {
          errorMessage += error.message || "An unexpected error occurred.";
        }

        const authError = new Error(errorMessage); // Create a new error object
        authError.cause = error; // Set the original error as the cause
        throw authError; // Re-throw the new error
    }
}