"use client";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AuthError } from "next-auth";
import { signIn, useSession } from "next-auth/react";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: "",
        password: "",
    });
    const [errorMessage, setErrorMessage] = useState(null);
    const [successMessage, setSuccessMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const router = useRouter();
    const { data: session, status } = useSession();

    useEffect(() => {
        if (status === 'loading') return;
        if (!session?.user?.user.roles) {
            setErrorMessage("User role not found. Please contact support.");
            return;
        }
        console.log(session);
        const userRole = session.user.user.roles;
        switch (userRole) {
            case "Trainers Admin":
                router.push("/dashboard/trainers-admin");
                break;
            case "Trainer":
                router.push("/dashboard/trainer");
                break;
            case "HOD's":
                router.push("/dashboard/hod");
                break;
            case "Employee":
                router.push("/dashboard/employee");
                break;
            default:
                setErrorMessage("Invalid user role. Please contact support.");
        }
    },[session,status, router]);

    // const handleRoleRedirection = () => {
    //     if (!session?.user?.user.roles) {
    //         setErrorMessage("User role not found. Please contact support.");
    //         return;
    //     }
    //     console.log(session);
    //     const userRole = session.user.user.roles;
    //     switch (userRole) {
    //         case "Trainers Admin":
    //             router.push("/dashboard/trainers-admin");
    //             break;
    //         case "Trainer":
    //             router.push("/dashboard/trainer");
    //             break;
    //         case "HOD's":
    //             router.push("/dashboard/hod");
    //             break;
    //         case "Employee":
    //             router.push("/dashboard/employee");
    //             break;
    //         default:
    //             setErrorMessage("Invalid user role. Please contact support.");
    //     }
    // };

    const handleSubmit = async (event) => {
        event.preventDefault();
        
        try{
            const {username, password} = formData;
            const result = await signIn("credentials", {
                redirect: false,
                username,
                password,
            });
            console.log("result response:", result);
            if (result?.error) {

                setErrorMessage(result.error);
            } else {
                setSuccessMessage("Login successful. Validating user roles...");
               
            }
        } catch (error){
            console.error(error.response)
        }
    };




    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div>
            <Card className="mx-auto max-w-sm shadow-2xl">
                <CardHeader>
                    <CardTitle className="text-2xl text-center font-semibold tracking-tight py-5">🔐 Login</CardTitle>
                    <CardDescription>Please enter your credentials to log in to your account</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid gap-4">
                        {(errorMessage || successMessage) && (
                            <Alert variant={errorMessage ? "destructive" : "success"}>
                                <AlertTitle>{errorMessage ? "Error:" : "Success:"}</AlertTitle>
                                <AlertDescription>{errorMessage || successMessage}</AlertDescription>
                            </Alert>
                        )}
                        <form onSubmit={handleSubmit}>
                            <div className="grid gap-2">
                                <Label>Username</Label>
                                <Input
                                    type="text"
                                    id="username"
                                    name="username"
                                    value={formData.username}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                            </div>
                            <div className="grid gap-2">
                                <div className="flex items-center">
                                    <Label>Password</Label>
                                    <Link href="/auth/forget-password" className="ml-auto inline-block text-sm underline">
                                        Forgot password?
                                    </Link>
                                </div>
                                <Input
                                    type="password"
                                    id="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                            </div>
                            <div className="mt-4">
                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full bg-blue-500 text-white py-2 rounded"
                                >
                                    {isLoading ? "Logging in..." : "Login"}
                                </Button>
                            </div>
                        </form>
                    </div>
                    <div className="mt-4 text-center text-sm">
                        Don&apos;t have an account?{" "}
                        <Link href="/register" className="underline">
                            Sign Up
                        </Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
