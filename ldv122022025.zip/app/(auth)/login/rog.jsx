"use client";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: "",
        password: "",
    });
    const [errorMessage, setErrorMessage] = useState(null);
    const [successMessage, setSuccessMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const router = useRouter();
    const searchParams = useSearchParams();
    const errorParam = searchParams.get("error");
    const { data: session, status } = useSession();

    useEffect(() => {
        if (errorParam) {
            setErrorMessage(decodeURIComponent(errorParam));
        }
    }, [errorParam]);

    const handleRoleRedirection = () => {
        if (!session?.user?.user.roles) {
            setErrorMessage("User role not found. Please contact support.");
            return;
        }
        console.log(session);
        const userRole = session.user.user.roles;
        switch (userRole) {
            case "Trainers Admin":
                router.push("/dashboard/trainers-admin");
                break;
            case "Trainer":
                router.push("/dashboard/trainer");
                break;
            case "HOD's":
                router.push("/dashboard/hod");
                break;
            case "Employee":
                router.push("/dashboard/employee");
                break;
            default:
                setErrorMessage("Invalid user role. Please contact support.");
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage("");
        setSuccessMessage("");

        const { username, password } = formData;
        try {
            const result = await signIn("credentials", {
                redirect: false,
                username,
                password,
               
            });
            if (!result.error) {
                // Successful login, redirect or handle as needed
                console.log('Login successful');
                setSuccessMessage("Login successful. Validating user roles...");
              } else {
                // Handle error from NextAuth
                setErrorMessage(result.error);
              }
            // if(!response || response.error) {
            //     setErrorMessage(response.error);
            // } else {
            //     setSuccessMessage("Login successful. Validating user roles...");
            //     handleRoleRedirection();
            // }
            // console.log("response details:", response);
        } catch (error) {
            console.error("Login error:", error || "An unexpected error occurred.");
            setErrorMessage(error.message || "An unexpected error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };
   
    return (
        <div>
            <Card className="mx-auto max-w-sm shadow-2xl">
                <CardHeader>
                    <CardTitle className="text-2xl text-center font-semibold tracking-tight py-5">🔐 Login</CardTitle>
                    <CardDescription>Please enter your credentials to log in to your account</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid gap-4">
                        {(errorMessage || successMessage) && (
                            <Alert variant={errorMessage ? "destructive" : "success"}>
                                <AlertTitle>{errorMessage ? "Error:" : "Success:"}</AlertTitle>
                                <AlertDescription>{errorMessage || successMessage}</AlertDescription>
                            </Alert>
                        )}
                        <form onSubmit={handleSubmit}>
                            <div className="grid gap-2">
                                <Label>Username</Label>
                                <Input
                                    type="text"
                                    id="username"
                                    name="username"
                                    value={formData.username}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                            </div>
                            <div className="grid gap-2">
                                <div className="flex items-center">
                                    <Label>Password</Label>
                                    <Link href="/auth/forget-password" className="ml-auto inline-block text-sm underline">
                                        Forgot password?
                                    </Link>
                                </div>
                                <Input
                                    type="password"
                                    id="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                            </div>
                            <div className="mt-4">
                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full bg-blue-500 text-white py-2 rounded"
                                >
                                    {isLoading ? "Logging in..." : "Login"}
                                </Button>
                            </div>
                        </form>
                    </div>
                    <div className="mt-4 text-center text-sm">
                        Don&apos;t have an account?{" "}
                        <Link href="/register" className="underline">
                            Sign Up
                        </Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
if (result.error) {
    console.error("NextAuth Sign-in Error:", result.error);
    console.error("Original Cause:", result.error.cause); // Access the original error
    setError(result.error.message); // Display the user-friendly message
}

if (result.error.cause) { // Check if cause exists
    if (typeof result.error.cause === 'string') {
        errorMessage = result.error.cause; // Use cause directly if it's a string
    } else if (result.error.cause instanceof Error && result.error.cause.message) {
        errorMessage = result.error.cause.message; // Extract message from Error object
    } else if (typeof result.error.cause === 'object'){ // handle the object of errors from DRF
      errorMessage = Object.values(result.error.cause).join('\n')
    }else{
      errorMessage = "Authentication failed."
    }
}

setError(errorMessage);


-----------
import axios from "axios";
import NextAuth, { AuthError, CredentialsSignin } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";

export const { 
    handlers,
    signIn, 
    signOut, 
    auth 
} = NextAuth({
    secret: process.env.AUTH_SECRET,
    pages: {
        signIn: "/login",
    },
    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            if (user) {
                return true;
            }
            return false; // This will trigger the error page with CredentialsSignin error
        },
        async jwt({ token, user }) {
            if (user) {
                
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            if (Date.now() > token.sessionExp) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                        refresh: token.refreshToken,
                    });

                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.session_expires_at = Date.now() + 60 * 60 *1000;
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error.response?.data || error.message);
                    token.error = "SessionExpired";
                    throw new Error("Session expired. Please log in again.:", error.response?.data || error.message)
                }
            }
            return token;
        },
        async session({ session, token }) {
            console.log("Session callback:", token);
            if (!token || !token.accessToken) {
                session.error = "Session expired, please log in again.";
                return session;
            }
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            
            
            if (token.error === "SessionExpired") {
                session.error = "Session expired. Please log in again.";
            }
            
            return session;
        } 
    },
    session: {
        strategy: "jwt"
    },
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/login/`, {
                        username: credentials.username,
                        password: credentials.password,
                    });
            
                    console.log("Response data of authorize:", response.data);
            
                    if (response.status === 200) {
                        return {
                            accessToken: response.data.access_token,
                            refreshToken: response.data.refresh_token,
                            user: response.data.user,
                            sessionKey: response.data.sessionKey,
                            sessionExp: response.data.sessionExp,
                        };
                    } else {
                        console.error("Login failed respons:", response.data.error || response.data.error.message);
                        // Handle non-200 status codes (DRF Errors)
                        const error = new Error(response.data.error || "Login failed"); // Use DRF error or generic message
                        error.status = response.status; // Add status to the error object
                        // throw error; // Re-throw to be caught by the catch block
                        return null;
                    }
                } catch (error) {
                    console.error("Authentication failed:", error.response?.data?.error || error.message);
            
                    // // Construct a more informative error object for NextAuth
                    // let errorMessage = "Authentication failed: ";
            
                    // if (error.response?.data?.error) {
                    //   if(typeof error.response.data.error === 'object'){
                    //     errorMessage += Object.values(error.response.data.error).join('\n')
                    //   }else{
                    //     errorMessage += error.response.data.error;
                    //   }
                    // } else if (error.status === 401) {  // Example: Handle 401 Unauthorized
                    //   errorMessage += "Invalid credentials."; // Customize as needed
                    // } else if (error.message.includes('Password expired')) { // Example: check for a specific message
                    //   errorMessage += "Password expired. Please update your password.";
                    // } else {
                    //   errorMessage += error.message || "An unexpected error occurred.";
                    // }
            
                    // const authError = new Error(errorMessage); // Create a new error object
                    // // authError.cause = error; // Set the original error as the cause
                    // throw errorMessage; // Re-throw the new error
                    throw new Error (error);
                }
            }
        }),
    ],
    
    
});

const handleSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { username, password } = formData;
    try {
        const result  = await signIn("credentials", {
            username,
            password,
            redirect: false,
            
        });
        
        console.log("result response:", result);
        
        if (result?.error) {
            // console.error("NextAuth Sign-in Error:", response.error);
            // console.error("Original Cause:", response.error.cause); 
            // let errorMessage = response.error.message || "Authentication failed.";
            // if (response.error) {
            //     if (typeof response.error.cause === "string") {
            //         errorMessage = response.error.cause;
            //     } else if (response.error.cause instanceof Error && response.error.cause.message) {
            //         errorMessage = response.error.cause.message;
            //     }else if (typeof response.error.cause === 'object'){ // handle the object of errors from DRF
            //         errorMessage = Object.values(response.error.cause).join('\n')
            //     }else{
            //         errorMessage = "Authentication failed."
            //     }
            // }
            
            setErrorMessage(result.code);
        } else {
            setSuccessMessage("Login successful. Validating user roles...");
            handleRoleRedirection();
        }
    } catch (error) {
        console.error("Login error:", error || "An unexpected error occurred.");
        // setErrorMessage(error.message || "An unexpected error occurred.");
        if (error instanceof AuthError) {
            if (error.cause?.err instanceof Error) {
              try {
                const parsedError = JSON.parse(error.cause.err.message);
                // Now you can handle different error types dynamically
                switch(parsedError.code) {
                  case 'credentials':
                    return parsedError.message;
                  default:
                    return 'Something went wrong';
                }
              } catch {
                // If error message isn't JSON
                return error.cause.err.message;
              }
            }
          }
          throw error;
    } finally {
        setIsLoading(false);
    }
};
-----
// if (error.response && error.response.data && error.response.data.error) {
                    //     // Extract the error message from the backend response
                    //     const errorMessage = error.response.data.error;
                    //     throw new Error(errorMessage); // Re-throw with the backend message
                    // } else if(error.response){
                    //     throw new Error(error.response.data)
                    // }
                    // else {
                    //     throw new Error('Invalid credentials'); // Generic message if no backend message
                    // }
