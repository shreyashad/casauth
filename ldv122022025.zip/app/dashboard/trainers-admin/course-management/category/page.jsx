import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";



export default async function CourseCategoryManagementPage() {
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                    homelink="/dashboard/trainers-admin/"
                    hometitle="Home"
                    mdipagelink="/dashboard/trainers-admin/course-management/category"
                    mdipagetitle="Course Management"
                    pagetitle="Course Category"
            />
                    
        </div>
    );
};