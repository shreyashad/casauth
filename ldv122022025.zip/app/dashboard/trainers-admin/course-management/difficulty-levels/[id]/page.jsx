import { auth } from "@/auth";
import { DifficultyLevelForm } from "@/components/trainers-admin/course-management/difficultylevel/difficulty-level-form";
import { fetchDifficultyLevelDetails } from "@/services/trainers-admin/course-managment/course_management_api";

function getCatId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}


export default async function EditDifficultyLevel({ params }) {
    const { id } = await params;
    const session = await auth();

    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let catData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        catData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const CateId = getCatId(id);
        catData = await fetchDifficultyLevelDetails(session.accessToken,CateId);
    }
    return (
        <div className="flex flex-col">
            <DifficultyLevelForm initialData={catData || {}}/>
        </div>
   );
}