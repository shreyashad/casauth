import { auth } from "@/auth";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { CourseDifficultyLevelColumns } from "@/components/trainers-admin/course-management/difficultylevel/difficulty-level-column";
import { DataTable } from "@/components/ui/data-table/data-table";
import { fetchDifficultyLevelListData } from "@/services/trainers-admin/course-managment/course_management_api";



export default async function DifficultyLevelManagementPage() {
    const session = await auth();
    const diffLevelListData = fetchDifficultyLevelListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                    homelink="/dashboard/trainers-admin/"
                    hometitle="Home"
                    mdipagelink="/dashboard/trainers-admin/course-management/difficulty-levels"
                    mdipagetitle="Course Management"
                    pagetitle="Difficulty Level"
            />
            <DataTable 
                data={diffLevelListData}
                columns={CourseDifficultyLevelColumns}
                globalFilterColumnId="name"
               
                
            />        
        </div>
    );
};