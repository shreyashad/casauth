import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { CalendarComponent } from "@/components/common/my-calendar";
import { StatsCard } from "@/components/common/stats-card";
import { MdModelTraining ,MdPlayLesson} from "react-icons/md";
import { RiUserLocationLine, RiTeamFill } from "react-icons/ri";

export default async function TrainersAdminDashboardPage() {
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                 homelink="/dashboard/trainers-admin/"
                 hometitle="Home"
                 mdipagelink="/dashboard/trainers-admin//"
                 mdipagetitle="Trainers Administrator"
                 pagetitle="Dashboard"
            />
            <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                    <StatsCard title="Active User" description="Total number of active online users" value={25} icon={<RiUserLocationLine />}/>
                    <StatsCard title="Total Trainers" description="Total number of Trainers" value={10} icon={<RiTeamFill />}/>
                    <StatsCard title="Total Training Session" description="Total number of training sessions completed" value={1} icon={<MdModelTraining /> }/>
                    <StatsCard title="Ongoin Training Session" description="Total number of on-going training sessions" value={1} icon={<MdModelTraining /> }/>
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                    
                   <CalendarComponent />
                </div>
            </div>
        </div>





        
    );
};