import HeaderComponent from "@/components/layout/header";
import SidebarComponent from "@/components/layout/sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";



export default function HodLayout({ children }) {
    return(
        <SidebarProvider>
            <SidebarComponent dashboardType="HOD" />
            <SidebarInset>
                <HeaderComponent />
                <main>
                    {children}
                </main>
            </SidebarInset>
        </SidebarProvider>
    );
}; 