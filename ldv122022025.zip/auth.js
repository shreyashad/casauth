import axios from "axios";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:9001/";


export const { handlers, signIn, signOut, auth } = NextAuth({
    secret: process.env.AUTH_SECRET,
    providers: [
        Credentials({
            name:"Credentials",
            credentials: {
                username: { label: "Username", type: "text"},
                password: { label: "Password", type: "password"},
            },

            async authorize(credentials) {
                const { username, password } = credentials;

                try {
                    const response = await axios.post(`${API_BASE_URL}api/login/`, {
                        username,
                        password,
                    });

                    const user = response.data; // Assuming your API returns user data
                    if (!user) {
                        throw new Error("custom error")
                    }
                    
                    // if (user ) {
                    return {
                        accessToken: user.access_token,
                        refreshToken: user.refresh_token,
                        user: user.user,
                        sessionKey: user.sessionKey,
                        sessionExp: user.sessionExp,
                    };
                    // } else {
                    //    return null;// Throw an error to be caught by NextAuth
                    // }
                } catch (error) {
                    console.error("Login error:", error.response.data.error);
                    
                    const errorMessage = error.response.data.error;
                    throw new Error(JSON.stringify({
                        code: error.response.data.code || 'credentials',
                        message: error.response.data.error,
                        details: error.details || {}
                      }))
                    // throw new Error(errorMessage);
                    // return null;
                }
            },
        })
    ],
    callbacks: {
        async jwt({ token, user }) {
            // Persist the OAuth access_token to the JWT
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            return token;
        },
        async session({ session, token }) {
            // Send properties to the client, like an image and user role
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            console.log("user session details:", session);
            return session;
        },
    },
    pages: {
        signIn: '/login',
    }
});