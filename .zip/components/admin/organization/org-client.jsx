"use client";

import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

const { useRouter } = require("next/navigation")



const OrganizationClient = () => {
    const router = useRouter();
    return(
        <>
         <div className="flex items-center justify-between">
                <DashHeading 
                    title="Organization List"
                />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/org-management/organizations/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
        
        </>
    );
}
export default OrganizationClient;