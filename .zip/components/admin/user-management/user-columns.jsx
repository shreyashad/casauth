"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { UserCellAction } from "./cell-actions";



export const UserColumns = [
    {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
            className="translate-y-[2px]"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "username",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Users"} />,
        cell: ({ row }) => {
          const { username, first_name, last_name } = row.original;
          return (
            <div className="flex flex-col items-start">
              <span className="font-bold">{username}</span>
              <span>{first_name} {last_name}</span>
            </div>
          );
        },
      },
      {
        accessorKey: "org_name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Organization"} />,
        cell: ({ row }) => {
          const { org_name, org_type } = row.original;
          return (
            <div className="flex flex-col items-start">
              <span className="font-bold">{org_name}</span>
              <span>{org_type}</span>
            </div>
          );
        },
      },
      {
          accessorKey: "org_sub_type",
          header: ({ column }) => <DataTableColumnHeader column={column} title={" Org Subtype"} />,

          cell: ({ row }) => {
            return <div className="flex items-center">{row.original.org_sub_type }</div>;
        }
          
         
      
      },
      {
        accessorKey: "location_type",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"location type"} />
      },
      
      {
        accessorKey: "department",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Department"} />
      },
      
      {
        accessorKey: "is_online",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Status"} />,
        cell: ({ row }) => {
          return (
            <span>
              {row.original.is_online ? (
                <span className="text-green-500">🟢 Online</span>
              ) : (
                <span className="text-red-500">🔴 Offline</span> 
              )}
            </span>
          );
        },
      },
      {
        accessorKey: "is_verified",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Verified"} />,
        cell: ({ row }) => {
          return (
            <span>
              {row.original.is_online ? (
                <span className="text-green-500">✔️Verified</span>
              ) : (
                <span className="text-red-500">❌Not Verified</span>
              )}
            </span>
          );
        },
      },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <UserCellAction data={row.original} />,
    },
];