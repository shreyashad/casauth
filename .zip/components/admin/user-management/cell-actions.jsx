"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { fetchUserDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";


export function UserCellAction({ data }) {
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const fetchUser = async () => {
        try {
            const result = await fetchUserDetails(data)
            return result;
        } catch (error) {
            toast.error("Error fetching users");
            throw error;
        }
    };

    const handleEdit = () => {
        router.push(`/dashboard/administrator/user-management/${data.id}`);
    }

    const deleteUser = async (id) => {
        try {
            await api.administrator.userManagement.delete(id);
            toast.success("user deleted successfully");
            await fetchUser();
        } catch (error) {
            toast.error("Error deleting User");
        }
    };

    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />

                        </Button>

                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update User</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                        variant="ghost"
                        size="icon"
                        className="hover:bg-secondary"
                        onClick={() => {
                            setAlertModalOpen(true);
                        }}
                        >
                        <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete User</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={() => deleteUser(data.id)}
                loading={false} // You can handle loading state as needed
            />
        </div>
    );
}

