import { BookCheckIcon, BookOpenCheck, BookOpenText, BookUser, Briefcase, BriefcaseBusiness, Building2, FileClock, LayoutDashboard, MapPin, NotebookPen, Server, Settings, Shield, ShieldPlus, Trophy, UserCheck, UserRoundCog, UsersRound, Warehouse } from "lucide-react";


export const DashboardMenuConfig = {
    Administrator: [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/dashboard/administrator/",
            color: "text-sky-500",
        },
        {
            title: "User-Management",
            icon: UserRoundCog,
            href: "/dashboard/administrator/user-management",
            color: "text-sky-500",
            
        },
        {
            title: "Role and Permission",
            icon: ShieldPlus,
            href: "/dashboard/administrator/roles-permission",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Roles",
                    icon: UserCheck,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/roles",
                  },
                  {
                    
                    title: "Permissions",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/permissions",
                  },
                  {
                    
                    title: "Assign Roles",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/assign-roles",
                  },
                  
            ]
        },
        {
            title: "Organization",
            icon: Building2,
            href: "/dashboard/administrator/org-management",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Organization",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/organizations",
                  },
                  {
                    
                    title: "Org-Subtype",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/org-subtype",
                  },
                  {
                    title: "Locations",
                    icon: MapPin,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/locations",
                  },
                  {
                    title: "Departments",
                    icon: Warehouse,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookUser,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/dashboard/administrator/teams",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "teams",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/teams/",
                  },
                  {
                    
                    title: "Add Team Member",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/org-subtype",
                  },
            ]
        },
        {
            title: "Application Management",
            icon: Server,
            href: "/dashboard/administrator/application-management",
            color: "text-sky-500",
        },
        {
            title: "Logs and Reports",
            icon: FileClock,
            href: "/dashboard/administrator/logs_reports",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/dashboard/administrator/profile",
            color: "text-sky-500",
        },
    ],
    Authenticator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/hod/dashboard",
            color: "text-sky-500",
        },
        {
            title: "Traning Request",
            icon: LayoutDashboard,
            href: "/hod/users",
            color: "text-sky-500",
            
        },
        {
            title: "Organization-Management",
            icon: LayoutDashboard,
            href: "/administrator/organization",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Branches",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/branches",
                  },
                  {
                    title: "Departments",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/administrator/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/administrator/profile",
            color: "text-sky-500",
        },
    ],
    Siteadministrator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/employee/dashboard",
            color: "text-sky-500",
        },
        {
            title: "My-Course",
            icon: BookOpenText,
            href: "/employee/my-courses",
            color: "text-sky-500",
            
        },
        {
            title: "My-Exams",
            icon: NotebookPen,
            href: "/employee/exams",
            color: "text-sky-500",
        },
        {
            title: "My-Performance",
            icon: Trophy,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/employee/profile",
            color: "text-sky-500",
        },
    ]
    

};