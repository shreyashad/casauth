import axios from "axios";
import { refreshAccessToken } from "./tokenService";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export async function fetchApplicationdetails() {
    try {
        const response = await axios.post(`${API_BASE_URL}api/application-details/`, {
            name: process.env.APP_NAME
        });
        return response.data;
    } catch (error) {
        throw new Error("Failed to fetch application details");
    }
};



export async function validateTicket(serviceTicket, applicationId) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });
        return response.data; // Ensure this returns the expected user details
    } catch (error) {
        console.error('Error validating ticket:', error);
        throw new Error('Error validating ticket');
    }
};


// for user registration

export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};

export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};

export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-name-list/`,orgType);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};

export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-subtype-list/`,orgType);
        console.log("Org SubType Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubType:", error );
        throw error;
    }
};

export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-type-list/`,orgName);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};



export async function fetchLocationName(orgName,location_type) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-name-list/`,orgName, location_type);
        console.log("Location Name Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error );
        throw error;
    }
};


// for administrator dashboard related


export async function fetchOnlineUser(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user count:", error);
            throw error;
        }
    }
};

export async function fetchTotalUser(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching total user count:", error);
            throw error;
        }
    }
};

export async function fetchApplicationCount(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/application-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/application-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching total user count:", error);
            throw error;
        }
    }
};

export async function fetchUserListData(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Try refreshing the access token
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                // Retry the original request with the new token
                const retryResponse = await axios.get(`${API_BASE_URL}api/admin-user-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user details:", error);
            throw error;
        }
    }
};

export async function fetchUserDetails(userId, accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-details/${userId}/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Try refreshing the access token
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                // Retry the original request with the new token
                const retryResponse = await axios.get(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user details:", error);
            throw error;
        }
    }
};

export default async function createNewUser(accessToken, refreshToken, userData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/admin-user-list/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("New user created:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Handle token expiration and retry with a new token
            try {
              const newAccessToken = await refreshAccessToken(refreshToken);
              const retryResponse = await axios.post(`${API_BASE_URL}api/admin-user-list/`, userData, {
                headers: {
                  Authorization: `Bearer ${newAccessToken}`,
                  "Content-Type": "application/json",
                },
              });
              console.log("New user created after token refresh:", retryResponse.data);
              return retryResponse.data;
            } catch (refreshError) {
              console.error("Error refreshing access token:", refreshError);
              throw refreshError;
            }
          } else {
            console.error("Error creating user:", error);
            throw error;
          }
    }
};

export async function updateUserDetails(accessToken, refreshToken, userId, userData) {
    try {
        const response = await axios.put(`${API_BASE_URL}api/admin-user-details/${userId}/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("User updated:", response.data);
        return response.data;
      } catch (error) {
        if (error.response?.status === 401) {
          // Handle token expiration and retry with a new token
          try {
            const newAccessToken = await refreshAccessToken(refreshToken);
            const retryResponse = await axios.put(`${API_BASE_URL}api/admin-user-details/${userId}/`, userData, {
              headers: {
                Authorization: `Bearer ${newAccessToken}`,
                "Content-Type": "application/json",
              },
            });
            console.log("User updated after token refresh:", retryResponse.data);
            return retryResponse.data;
          } catch (refreshError) {
            console.error("Error refreshing access token:", refreshError);
            throw refreshError;
          }
        } else {
          console.error("Error updating user:", error);
          throw error;
        }
      }
    
};

export async function deleteUserDetails(accessToken, refreshToken, userId) {
    try {
      const response = await axios.delete(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      console.log("User deleted:", response.data);
      return response.data;
    } catch (error) {
      if (error.response?.status === 401) {
        // Handle token expiration and retry with a new token
        try {
          const newAccessToken = await refreshAccessToken(refreshToken);
          const retryResponse = await axios.delete(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
            headers: {
              Authorization: `Bearer ${newAccessToken}`,
            },
          });
          console.log("User deleted after token refresh:", retryResponse.data);
          return retryResponse.data;
        } catch (refreshError) {
          console.error("Error refreshing access token:", refreshError);
          throw refreshError;
        }
      } else {
        console.error("Error deleting user:", error);
        throw error;
      }
    }
};
  

