"use client";
import { useEffect, useState } from "react";
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { fetchDesignations, fetchLocationTypes, fetchOrgNames, fetchOrgSubTypes, fetchOrgTypes } from "@/app/api/server/route";

export default function RegisterPage() {
    const [formData, setFormData] = useState({
        first_name: "",
        last_name: "",
        emp_code: "",
        designation: "",
        org_type: "",
        org_name: "",
        org_sub_type: "",
        location_type: "",
        location_name: "",
        location_code: "",
        assigned_details: "",
        departments:"",
        username: "",
        password: "",
        confirm_password: "",
        mobile: "",
    });

    const [desigData, setDesigData] = useState([]);
    const [deptData, setDeptData] = useState([]);
    const [orgTypeData, setOrgTypeData] = useState([]);
    const [orgNamesData, setOrgNamesData] = useState([]);
    const [orgSubTypeData, setOrgSubTypeData] = useState([]);
    const [locationTypeData, setLocationTypeData] = useState([]);
    const [locationNamesData, setLocationNamesData] = useState([]);
    const [locationCodeData, setLocationCodeData] = useState([]);
    const [currentStep, setCurrentStep] = useState(0)
    const handleNext = () => {
        setCurrentStep(currentStep + 1)
    }

    const handlePrevious = () => {
        setCurrentStep(currentStep - 1)
    }

    useEffect (() => {
        const fetchData = async () => {
          try {
            const desig = await fetchDesignations();
            setDesigData(desig);
            const orgtype = await fetchOrgTypes();
            setOrgTypeData(orgtype);
            
           
          } catch (error) {
            console.error("Error fetching data:", error);
          }
        };
        fetchData();
      }, []);






    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSelectChange = async (name, value) => {
        setFormData({ ...formData, [name]: value});

        if (name === "org_type") {
            await fetchOrgNames(value);
            await fetchOrgSubTypes(value);

            setLocationTypeData([]);
            setLocationNamesData([]);
            setLocationCodeData([]);
        } else if (name === "org_name") {
            await fetchLocationTypes(value)
        }
    };



    

    useEffect(() => {
        const fetchDataBasedOnType = async () => {
            if (formData.org_type) {
                try {
                    const orgNamesRes = await fetchOrgNames(formData.org_type);
                    setOrgNamesData(orgNamesRes);
                    const subtype = await fe
                } catch (error) {
                    console.error("Error fetching organization names:", error);
                }
            }
        };
        fetchDataBasedOnType();
    }, [formData.org_type]);
    


    return(
        <div className="container mx-auto max-w-6xl py-12 md:py-16 lg:py-20 flex gap-8">
            <div className="w-1/3 bg-muted rounded-lg p-6 shadow-md">
                <div>
                    <div>
                        <div>
                            <div className="space-y-4">
                                <div className="flex items-center space-x-4">
                                    <div
                                        className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                        currentStep === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                        }`}
                                    >
                                        1
                                    </div>
                                    <h3 className={`text-lg font-semibold ${currentStep === 0 ? "text-primary" : ""}`}>Personal Info</h3>
                                </div>
                                <p className={`text-muted-foreground ${currentStep === 0 ? "text-primary" : ""}`}>
                                Enter your name, email, and phone number.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div>
                            <div className="space-y-4">
                                <div className="flex items-center space-x-4">
                                    <div
                                        className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                        currentStep === 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                        }`}
                                    >
                                        2
                                    </div>
                                    <h3 className={`text-lg font-semibold ${currentStep === 1 ? "text-primary" : ""}`}>Company Info</h3>
                                </div>
                                <p className={`text-muted-foreground ${currentStep === 1 ? "text-primary" : ""}`}>
                                Enter your company name, industry, and size.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div>
                            <div className="space-y-4">
                                <div className="flex items-center space-x-4">
                                <div
                                    className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                    currentStep === 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                    }`}
                                >
                                    3
                                </div>
                                <h3 className={`text-lg font-semibold ${currentStep === 2 ? "text-primary" : ""}`}>Account Info</h3>
                                </div>
                                <p className={`text-muted-foreground ${currentStep === 2 ? "text-primary" : ""}`}>
                                Create a username and password for your account.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      <div className="w-2/3 bg-background border rounded-lg p-6 shadow-lg">
        {currentStep === 0 && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>First Name</Label>
                <Input 
                    type="text"
                    name="first_name"
                    value={formData.first_name}
                    onChange={handleChange}
                    required 
                />
              </div>
              <div className="space-y-2">
                <Label>Last Name</Label>
                <Input 
                    type="text"
                    name="last_name"
                    value={formData.last_name}
                    onChange={handleChange}
                    required 
                />
              </div>
              <div className="space-y-2">
                <Label>Employee Code</Label>
                <Input
                    type="text"
                    name="emp_code"
                    value={formData.emp_code}
                    onChange={handleChange}
                    required
                />
              </div>
              <div className="space-y-2">
                <Label>Designation</Label>
                <Select>
                    <SelectTrigger>
                        <SelectValue placeholder="Select Designation" />
                    </SelectTrigger>
                    <SelectContent>
                        {desigData.map((designation) => (
                            <SelectItem key={designation.id} value={designation.name}>
                                {designation.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
              </div>

            </div>
            
            <div className="flex justify-between">
              <Button variant="outline" type="button" onClick={handleNext}>
                Next
              </Button>
            </div>
          </div>
        )}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                    <Label>Organization Type</Label>
                    <Select onValueChange={(value) => handleSelectChange("org_type", value)}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Org Type" />
                        </SelectTrigger>
                        <SelectContent>
                            {orgTypeData.map((orgtype, index) => (
                                <SelectItem key={index} value={orgtype}>
                                    {orgtype}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label>Organization Name</Label>
                    <Select onValueChange={(value) => handleSelectChange("org_name", value)}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Org Name" />
                        </SelectTrigger>
                        <SelectContent>
                            {orgNamesData.map((orgName) => (
                                <SelectItem key={orgName.id} value={orgName.name}>
                                    {orgName.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label>Organization Subtype</Label>
                    <Select onValueChange={(value) => handleSelectChange("org_sub_type", value)}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Org subType" />
                        </SelectTrigger>
                        <SelectContent>
                            {orgSubTypeData.map((orgSubtype) => (
                                <SelectItem key={orgSubtype.id} value={orgSubtype.name}>
                                    {orgSubtype.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label>Location Type</Label>
                    <Select onValueChange={(value) => handleSelectChange("location_type", value)}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Location Type" />
                        </SelectTrigger>
                        <SelectContent>
                            {locationTypeData.map((locationtype, index) => (
                                <SelectItem key={index} value={locationtype}>
                                    {locationtype}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label>Location Name</Label>
                    <Select>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Location Type" />
                        </SelectTrigger>
                        <SelectContent>
                            {locationNamesData.map((locationName) => (
                                <SelectItem key={locationName.id} value={locationName.name}>
                                    {locationName.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label>Location Code</Label>
                    <Select>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Location Type" />
                        </SelectTrigger>
                        <SelectContent>
                            {locationCodeData.map((locationCode, index) => (
                                <SelectItem key={index} value={locationCode}>
                                    {locationCode}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
            
            <div className="flex justify-between">
              <Button variant="outline" type="button" onClick={handlePrevious}>
                Previous
              </Button>
              <Button variant="outline" type="button" onClick={handleNext}>
                Next
              </Button>
            </div>
          </div>
        )}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" placeholder="Enter your username" />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm Password</Label>
                <Input id="confirm-password" type="password" />
              </div>
            </div>
            <div className="space-y-2">
                <Label>Mobile Number</Label>
                    <Input
                        type="tel"
                        name="mobile"
                        value={formData.mobile}
                        onChange={handleChange}
                        required
                    />
            </div>
            <div className="flex justify-between">
              <Button variant="outline" type="button" onClick={handlePrevious}>
                Previous
              </Button>
              <Button type="submit">Create Account</Button>
            </div>
          </div>
        )}
      </div>
    </div>
    );
}