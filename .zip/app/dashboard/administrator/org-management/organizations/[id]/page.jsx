import { fetchOrganizationDetails } from "@/app/api/server/route";
import { OrganizationForm } from "@/components/admin/organization/org-form";


function getOrgId(data) {
    try {
        return decodeURIComponent(data)
    } catch( error) {
        console.error('failed to decode org id')
        return data
    }
}

export default async function EditOrganization({ params }) {
    const data = params;
    const OrgId = getOrgId(data.id);

    const orgData = await fetchOrganizationDetails(OrgId);
    
    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
              <OrganizationForm initialData={orgData} />
            </div>
        </div>
    );
    
};