import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { fetchApplicationdetails, validateTicket } from "./app/api/server/route";
import axios from "axios";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export const {handlers, signIn, signOut, auth} = NextAuth({
    providers:[
        CredentialsProvider({
            name: "CAS",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
               
            },
            async authorize(credentials) {
                try {
                  const application = await fetchApplicationdetails();
                  const applicationId = application.app.id;
              
                  const response = await axios.post(`${API_BASE_URL}api/login/`, {
                    username: credentials.username,
                    password: credentials.password,
                    application_id: applicationId,
                  });
                  
                  if (response.status !== 200) {
                    throw new Error("Invalid credentials or application issue");
                  }
              
                  const user = response.data;
                  
                  const userDetails = await validateTicket(user.service_ticket, applicationId);
                  
                  
                  if (userDetails) {
                    return {
                        id: userDetails.id || user.id,
                        roles: userDetails.roles,
                        permissions: userDetails.permissions,
                        profile_pic: userDetails.profile_picture,
                        first_name: userDetails.first_name,
                        last_name: userDetails.last_name,
                        org_type: userDetails.org_type,
                        org_name: userDetails.org_name,
                        org_sub_type: userDetails.org_sub_type,
                        location_type: userDetails.location_type,
                        location_name: userDetails.location_name,
                        location_code: userDetails.location_code,
                        emp_code: userDetails.emp_code,
                        department: userDetails.department,
                        designation: userDetails.designation,
                        accessToken: user.access, // Ensure token is passed
                        refreshToken: user.refresh,

                    };
                  } else {
                    throw new Error("Invalid service ticket");
                  }
                } catch (error) {
                    console.error('Authentication failed:', error.response || error.message);
                    return null;
                }
              },
              
        }),
    ],
    pages: {
        signIn: '/login',
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
              token.accessToken = user.accessToken;
              token.refreshToken = user.refreshToken;
              token.user = {
                    id: user.id,
                    roles: user.roles,
                    permissions: user.permissions,
                    profile_pic: user.profile_picture,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    org_type: user.org_type,
                    org_name: user.org_name,
                    org_sub_type: user.org_sub_type,
                    location_type: user.location_type,
                    location_name: user.location_name,
                    location_code: user.location_code,
                    emp_code: user.emp_code,
                    department: user.department,
                    designation: user.designation,

                  
              }; 
            }
           
            return token;
          },
          
          async session({ session, token }) {
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.user = token.user || {}; // This should match the structure returned in `jwt`
          
            console.log("Session1 details:", session.user); // Verify the session object
            console.log("accessToken details:", session.accessToken);
            console.log("refreshToken details:", session.refreshToken);

            return session;
          }
          
    },
    session: { 
      strategy: 'jwt'
    },
});