import * as z from "zod";

const orgTypeEnum = z.enum([
  'MDIndia',
  'Insurance Company',
  'Broker',
  'Corporate'
]);


const locationEnum = z.enum([
    'HO',
    'RO',
    'DO',
    'UO',
    'Branch',
]);



export const LogingSchema = z.object({
    username: z.string().min(4, {
        message: "Username is required",
    }),
    password: z.string().min(1, {
        message:  "Password is required",
      }),
})

export const RegisterSchema = z.object({
    email: z.string().email({
      message: "Email is required",
    }),
    password: z.string().min(6, {
      message: "Minimum of 6 characters is required",
    }),
    name: z.string().min(1, {
      message: "Name is required",
    }),
  })


  export const ResetSchema = z.object({
    email: z.string().email({
      message: " Email is required",
    }),
  })
  
export const NewPasswordSchema = z.object({
      password: z
        .string()
        .min(6, {
          message: "Minimum of 6 characters is required",
        })
        .max(50, {
          message: "Maximum of 50 characters is allowed",
        })
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, {
          message: "Password must contain at least one uppercase letter, one lowercase letter, and one number",
        }),
      confirmPassword: z.string(),
    })
    .refine((data) => data.password === data.confirmPassword, {
      message: "Passwords don't match",
      path: ["confirmPassword"], // path of error
    })
  

export const OrgFormSchema = z.object({
    name: z.string().min(4, {
      message: "Username is required",
    })
    .max(250, {
      message: "Maximum of 250 characters is allowed"
    }),
    org_type: orgTypeEnum

})


export const OrgSubtypeFormSchema = z.object({
    subtype: z.string().min(3, {
      message: "SubType is required",
    })
    .max(250, {
       message: "Maximum of 250 characters is allowed"
    }),
    org_type: orgTypeEnum
})


export const LocationFormSchema = z.object({
    org_type: orgTypeEnum,
    

})


export const DepartmentFormSchema = z.object({
    name: z.string().min(4, {
      message: "Department Name is required",
    })
    .max(250, {
      message: "Maximum of 250 characters is allowed"
    }),
})


export const ProfileFormSchema = z.object({
    address: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    country: z.string().optional(),
    postal_code: z.string().optional(),
    phone_number: z.string().optional(),
    date_of_birth: z.string().optional(),
    bio: z.string().optional(),
})


// export const organizationFormSchema = z.object({
//       name: z.string().min(1, "Name is required").max(250, "must be 250 characters or less"),
//       org_type: orgTypeEnum
//     });

export const ApplicationFormSchema = z.object({
    name: z.string().min(4, {
      message: "department is required"
    })
    .max(250,{
        message: "must be 250 characters or less"
    }),
    description: z.string().min(4, {
        message: "Deparrment Description is required"
    })
    .max(250, {
        message: "must be 250 characters or less"
    }),
    base_url: z.string().min(4, {
        message: " Application url is required"
    }).url()
    .max(250, {
        message: "must be 250 characters or less"
    }),
    active: z.boolean({
      required_error: "isActive is required",
      invalid_type_error: "isActive must be a boolean",
    })
    .default(false)

})





const profileSchema = z.object({
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  postal_code: z.string().optional(),
  phone_number: z.string().optional(),
  date_of_birth: z.string().optional(),
  bio: z.string().optional(),
});


    
    export const designationFormSchema = z.object({
      name: z.string().min(1, "designation is required").max(250, "must be 250 characters or less")
    })
    
  
    
  
    
    export const locationFormSchema = z.object({
      org_name: z.string().min(1, "location is required").max(250, " must be 250 characters or less"),
      org_type: orgTypeEnum,
      location_type: locationEnum,
      location_name: z.string().min(1, "location name is required").max(250, " must be 250 characters or less"),
      location_code: z.string().min(1, "location code is required").max(250, "must be 250 characters or less"), 
    })
    
  
    export const UserManagementFormSchema = z.object({
      first_name: z.string().min(1, "first name is required").max(250, "must be 250 characters or less"),
      last_name: z.string().min(1, "last name is required ").max(250, "must be 250 characters or less"),
      org_type: orgTypeEnum,
      org_name:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      org_sub_type:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      location_type:locationEnum,
      location_name:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      location_code:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      emp_code:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      department:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      designation:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      mobile:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      username:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      password:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      assigned_pol_no:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      is_online:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
      is_verified:z.string().min(1, "ornization name is required").max(250,"must be 250 characters or less"),
    })
  
    export const profileFormSchema = z.object({
      bio: z.string().max(160).min(4),
    })
  
  
  
    export const UserrolesFormSchema = z.object({
      user: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      role: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      application: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_create: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_read: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_update: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_delete: z.string().min(1, "department is required").max(250, "must be 250 characters or less")
    })
  
    export const rolesFormSchema = z.object({
      name: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      permissions: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      application: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      
    })
  
    export const permissionFormSchema = z.object({
      name: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      description: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      application: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      
    })
  
    
    