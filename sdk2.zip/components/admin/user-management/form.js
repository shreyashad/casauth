"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation"
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { UserManagementFormSchema } from "@/schemas";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";



export const UserManagementForm = ({ initialData }) => {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initialData ? " Edit User": " Create User";
    const description = initialData ? " Edit a User": "Create a User";
    const toastMessage = initialData
    ? "User updated Successfully"
    : "User created Successfully";

    const action = initialData ? "Save Changes" : " Create";

    const form = useForm({
        resolver: zodResolver(UserManagementFormSchema),
        defaultValues: initialData || {
            first_name:"",
            last_name: "",
            org_type: "",
            org_name: "",
            org_sub_type:"",
            location_type:"",
            location_name:"",
            location_code:"",
            emp_code:"",
            department:"",
            designation:"",
            mobile:"",
            username:"",
            password:"",
            assigned_pol_no:"",
            is_online:"",
            is_verified:"",
            is_authenticator:"",
            is_site_admin:"",
            last_password_change:"",
            password_change_required:"",
            password_history_json:"",
            is_sso_user:"",
            sso_provider:""
        }
        });

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData) {
                await api.administrator.userManagement.update(initialData.id, values);
            } else {
                await  (values);
            }
            toast.success(toastMessage);
            router.push(`/administrator/user-management`);
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await api.userManagement.delete(initialData.id);
            toast.success("user deleted successfully");
            router.push(`/administrator/user-management`)
        } catch (error) {
            toast.error(error.message);
        }
        setLoading(false);
    };





    
    return(
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
            <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="first_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>First Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="first Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                           <FormField
                            control={form.control}
                            name="last_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Last Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="last Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="org_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                        defaultValue={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    defaultValue={field.value}
                                                    placeholder="Organization Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="MDIndia">MDIndia</SelectItem>
                                            <SelectItem value="Insurance Company">Insurance Company</SelectItem>
                                            <SelectItem value="Broker">Broker</SelectItem>
                                            <SelectItem value="Corporate">Corporate</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Orgnization Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="organization Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_sub_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>OrgSubType Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Orgnization subtype"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                            <FormField
                            control={form.control}
                            name="location_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                        defaultValue={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    defaultValue={field.value}
                                                    placeholder="Location Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="HO">HO</SelectItem>
                                            <SelectItem value="RO">RO</SelectItem>
                                            <SelectItem value="DO">DO</SelectItem>
                                            <SelectItem value="UO">UO</SelectItem>
                                            <SelectItem value="Branch">Branch</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="emp_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Employee Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Employee Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="department"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Department Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Department"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="designation"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Designation</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="designation"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="mobile"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Mobile No.</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="mobile no"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Username"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>password</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="password"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="assigned_pol_no"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Assigned policy no.</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="assigned pol no"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_online"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is online</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="is online"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_verified"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is verified</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="is verified"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_authenticator"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is Authenticator</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="is authenticator"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_site_admin"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is site admin</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="is site admin"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="emp_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Last password change</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="last password change"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="password_change_required"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Password change required</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="password change required"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="password_history_json"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Password history json</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="password history json"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_sso_user"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>is_sso_user</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="is sso user"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="sso_provider"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>sso provider</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="sso provider"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />

                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && (
                <AlertModal
                    title="Are you sure?"
                    description={`This action cannot be undone. Deleting user: ${initialData.first_name}`}
                    name={initialData?.first_name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );

};


        




