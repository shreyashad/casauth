"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { deleteOrganizationDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { useSession } from "next-auth/react";

export function OrgCellAction({ data }) {  // Use data prop
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/org-management/organizations/${data.id}`);
    };

    const deleteOrganization = async () => {
        try {
            await deleteOrganizationDetails(data.id, session.accessToken, session.refreshToken);
            toast.success("Organization deleted successfully");
            router.refresh();  // Refresh the page to reflect changes
        } catch (error) {
            toast.error("Error deleting organization");
        }
    };

    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={deleteOrganization}
                loading={false} // Handle loading state as needed
            />
        </div>
    );
}
