"use client";

import { createNewRole, deleteRoleDetails, fetchApplicationListData, fetchPermissionListData, updateRoleDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import MultiSelect from "@/components/ui/multi-select";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { rolesFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";



export const RolesManagementForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const title = initialData ? "Edit role" : "Create role";
    const description = initialData ? "Edit a role" : "Create a new role";
    const toastMessage = initialData
    ? "role updated successfully"
    : "role created successfully";
    const action = initialData ? "Save Changes" : "Create";

    const [applications, setApplications] = useState([]);
    const [permissions, setPermissions] = useState([]);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false); // For AlertModal


    useEffect(() => {
        const fetchData = async () => {
            try {
                const appRes = await fetchApplicationListData(session.accessToken, session.refreshToken);
                const perRes = await fetchPermissionListData(session.accessToken, session.refreshToken);
                setApplications(appRes);
                setPermissions(perRes);

            } catch (error) {
                toast.error("Error fetching data");
            }
        };
        fetchData();
    }, [session]);




    const form = useForm({
        resolver: zodResolver(rolesFormSchema),
        defaultValues: initialData || {
            name: "",
            permissions: [],
            application:"",
           
        },
    });

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData) {
                await updateRoleDetails(session.accessToken, session.refreshToken, initialData.id, values);
            } else {
                await createNewRole(session.accessToken, session.refreshToken,values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/roles-permission/roles`);
        } catch (error) {
            toast.error(error.message);
        }
        setLoading(false);
    };
    
    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteRoleDetails( initialData.id, session.accessToken, session.refreshToken);
            toast.success("Organization deleted successfully");
            router.push(`/administrator/roles-permission/roles`)
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return(
        <>
            <Card>
                <CardHeader>
                    <CardTitle>
                        <DashHeading title={title} description={description}/>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form
                            onSubmit={form.handleSubmit(onSubmit)}  className="w-full space-y-8"
                        >
                            <div className="grid-cols-2 gap-8 md:grid">
                                <FormField 
                                    control={form.control}
                                    name="name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Name</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...field}
                                                    placeholder="Name"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                /> 
                                <FormField
                                    control={form.control}
                                    name="application"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Application</FormLabel>
                                            <FormControl>
                                                <Select onValueChange={field.onChange}  value={field.value} disabled={loading}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select an application" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {applications.map((app) => (
                                                            <SelectItem key={app.id} value={app.id} >
                                                                {app.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="permissions"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Permissions</FormLabel>
                                            <FormControl>
                                                <MultiSelect 
                                                    options={permissions.map((perm) => ({
                                                        label: perm.name,
                                                        value: perm.id,
                                                      }))}
                                                      onValueChange={field.onChange}
                                                      defaultValue={field.value}
                                                      placeholder="Select permissions"
                                                      animation={0.5}
                                                />
                                                    
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                              
                            </div>
                            <div className="space-x-4">
                                <Button disabled={loading} className="ml-auto" type="submit">
                                    {action}
                                </Button>
                                <Button
                                    disabled={loading}
                                    className="ml-auto"
                                    type="button"
                                    onClick={() => {
                                        router.back();
                                    }}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </form>

                    </Form>
                    {initialData && (
                        <AlertModal
                            title="Are you Sure"
                            description="This action cannot be undone."
                            name={initialData?.name}
                            isOpen={open}
                            onClose={() => setOpen(false)}
                            onConfirm={onDelete}
                            loading={loading}
                        />
                    )}
                </CardContent>
            </Card>
        </>
    );
};