"use client";
import { deleteRoleDetails, fetchRoleDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";



export function RolesCellAction({ data }) {
    const { data: session, status } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);
    const handleEdit = () => {
        router.push(`/dashboard/administrator/roles-permission/roles/${data.id}`)
    };
    
    const deleteRoles = async (id) => {
        try {
            await deleteRoleDetails(id, session.accessToken, session.refreshToken);
            toast.success("user deleted successfully");
        } catch (error) {
            toast.error("Error while deleting Role")
        }
    };

    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />

                        </Button>

                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Roles</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                        variant="ghost"
                        size="icon"
                        className="hover:bg-secondary"
                        onClick={() => {
                            setAlertModalOpen(true);
                        }}
                        >
                        <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Roles</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={() => deleteRoles(data.id)}
                loading={false} 
            />
        </div>
    );
}