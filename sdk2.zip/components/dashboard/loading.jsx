"use client"

import {  PropagateLoader } from "react-spinners";

export const Loading = () => {
    return (
        <div className="flex h-full w-full items-center justify-center">
            <PropagateLoader color="foreground" size={50} />
        </div>
    )
}