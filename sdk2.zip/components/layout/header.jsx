import { cn } from "@/lib/utils";
import Image from "next/image";
import Link from "next/link";
import { ThemeToggle } from "./theme-toggle";
import UserNav from "./user-nav";


export default function Header() {
    return(
        <div className="supports-backdrp-blur:bg-background/60 fixed left-0 right-0 top-0 z-20 border-b bg-background/95 backdrop-blur">
            <nav className="flex h-16 items-center justify-between px-4">
                <Link href="#" className="hidden items-center justify-between gap-2 md:flex">
                    <Image
                        src= "/mdi_logo1.png"
                        width={50} 
                        height={50}
                        alt="Mdindia logo" 
                        priority 
                    />
                </Link>
                <div className={cn("block md:!hidden")}>

                </div>
                <div className="flex items-center gap-2">
                    <ThemeToggle />
                    <UserNav />
                </div>
            </nav>
        </div>
    )
}