"use client";
import { MenuIcon } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "../ui/sheet";
import Image from "next/image";
import { useEffect, useState } from "react";
import SideNav from "./side-nav";
import { DashboardMenuConfig } from "./sidebar-menu-list";



export const MobileSidebar = ({ dashboardType, className }) => {
    const [open, setOpen] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }

    const menuItems = DashboardMenuConfig[dashboardType] || [];
    return (
        <>
            <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                    <div className="flex items-center justify-center gap-2">
                        <MenuIcon />
                        <Image src="/mdi_logo1.png" width={50} height={50} />
                    </div>
                </SheetTrigger>
                <SheetContent side="left" className="w-72">
                    <div className="px-1 py-6pt-16">
                    <SideNav items={menuItems} setOpen={setOpen} />
                    </div>
                </SheetContent>
            </Sheet>
        </>
    );
};