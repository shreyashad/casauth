import { fetchOrgSubTypeDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { OrgSubTypeForm } from "@/components/admin/org-subtype/orgsubtype-form";

function getOrgSubtypeId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditOrgSubType({ params }) {
    const { id } = params;
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let orgSubtypeData = null;

    if (id === "new") {
        orgSubtypeData = {};
    } else {
        const orgSubtypeId = getOrgSubtypeId(id);
        orgSubtypeData = await fetchOrgSubTypeDetails(orgSubtypeId, session.accessToken, session.refreshToken);
    }

    return(
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <OrgSubTypeForm initialData={orgSubtypeData || {}} />
            </div>
        </div>
    );
};