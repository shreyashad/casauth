import { fetchUserDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { UserManagementForm } from "@/components/admin/user-management/user-form";


function getUserId(data) {
    try {
        return decodeURIComponent(data)
    } catch( error) {
        console.error('failed to decode user id')
        return data
    }
}

export default async function EditUser({ params }) {
  const data = params;
  const session = await auth(); 
  
 
  if (!session) {
    return new Response("Unauthorized", { status: 401 });
  }

  let userData = null;

  if (data){
    const userId = getUserId(data.id); 
    userData = await fetchUserDetails(userId, session.accessToken, session.refreshToken);

  }

 
  
  return(
    <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
              <UserManagementForm initialData={userData || {}} />
            </div>
        </div>
  );
};