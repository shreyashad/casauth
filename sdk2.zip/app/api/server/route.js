import axios from "axios";
import { refreshAccessToken } from "./tokenService";
import { Aperture } from "lucide-react";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export async function fetchApplicationdetails() {
    try {
        const response = await axios.post(`${API_BASE_URL}api/application-details/`, {
            name: process.env.APP_NAME
        });
        return response.data;
    } catch (error) {
        throw new Error("Failed to fetch application details");
    }
};



export async function validateTicket(serviceTicket, applicationId) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });
        return response.data; // Ensure this returns the expected user details
    } catch (error) {
        console.error('Error validating ticket:', error);
        throw new Error('Error validating ticket');
    }
};


// for user registration

export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};

export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};

export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-name-list/`,orgType);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};

export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-subtype-list/`,orgType);
        console.log("Org SubType Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubType:", error );
        throw error;
    }
};

export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-type-list/`,orgName);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};



export async function fetchLocationName(orgName,location_type) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-name-list/`,orgName, location_type);
        console.log("Location Name Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error );
        throw error;
    }
};


// for administrator dashboard related


export async function fetchOnlineUser(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user count:", error);
            throw error;
        }
    }
};

export async function fetchTotalUser(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching total user count:", error);
            throw error;
        }
    }
};

export async function fetchApplicationCount(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/application-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/application-count/`,{
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`, 
                    } 
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching total user count:", error);
            throw error;
        }
    }
};

export async function fetchUserListData(accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Try refreshing the access token
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                // Retry the original request with the new token
                const retryResponse = await axios.get(`${API_BASE_URL}api/admin-user-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user details:", error);
            throw error;
        }
    }
};

export default async function createNewUser(accessToken, refreshToken, userData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/admin-user-list/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("New user created:", response.data);
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Handle token expiration and retry with a new token
            try {
              const newAccessToken = await refreshAccessToken(refreshToken);
              const retryResponse = await axios.post(`${API_BASE_URL}api/admin-user-list/`, userData, {
                headers: {
                  Authorization: `Bearer ${newAccessToken}`,
                  "Content-Type": "application/json",
                },
              });
              console.log("New user created after token refresh:", retryResponse.data);
              return retryResponse.data;
            } catch (refreshError) {
              console.error("Error refreshing access token:", refreshError);
              throw refreshError;
            }
          } else {
            console.error("Error creating user:", error);
            throw error;
          }
    }
};



export async function fetchUserDetails(userId, accessToken, refreshToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-details/${userId}/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            // Try refreshing the access token
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                // Retry the original request with the new token
                const retryResponse = await axios.get(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching user details:", error);
            throw error;
        }
    }
};


export async function updateUserDetails(accessToken, refreshToken, userId, userData) {
    try {
        const response = await axios.put(`${API_BASE_URL}api/admin-user-details/${userId}/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("User updated:", response.data);
        return response.data;
      } catch (error) {
        if (error.response?.status === 401) {
          // Handle token expiration and retry with a new token
          try {
            const newAccessToken = await refreshAccessToken(refreshToken);
            const retryResponse = await axios.put(`${API_BASE_URL}api/admin-user-details/${userId}/`, userData, {
              headers: {
                Authorization: `Bearer ${newAccessToken}`,
                "Content-Type": "application/json",
              },
            });
            console.log("User updated after token refresh:", retryResponse.data);
            return retryResponse.data;
          } catch (refreshError) {
            console.error("Error refreshing access token:", refreshError);
            throw refreshError;
          }
        } else {
          console.error("Error updating user:", error);
          throw error;
        }
      }
    
};

export async function deleteUserDetails(accessToken, refreshToken, userId) {
    try {
      const response = await axios.delete(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      console.log("User deleted:", response.data);
      return response.data;
    } catch (error) {
      if (error.response?.status === 401) {
        // Handle token expiration and retry with a new token
        try {
          const newAccessToken = await refreshAccessToken(refreshToken);
          const retryResponse = await axios.delete(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
            headers: {
              Authorization: `Bearer ${newAccessToken}`,
            },
          });
          console.log("User deleted after token refresh:", retryResponse.data);
          return retryResponse.data;
        } catch (refreshError) {
          console.error("Error refreshing access token:", refreshError);
          throw refreshError;
        }
      } else {
        console.error("Error deleting user:", error);
        throw error;
      }
    }
};
  

// for roles management

export async function fetchRolesListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/roles-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching roles list data:", error);
            throw error;
        }
    }
};


export async function createNewRole(accessToken, refreshToken, roleData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles-list/`, roleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/roles-list/`, roleData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new role data:", error);
            throw error;
        }
    }
};



export async function fetchRoleDetails(roleId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching roles data:", error);
            throw error;
        }
    }
};




export async function updateRoleDetails(accessToken, refreshToken, roleId, roleData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, roleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, roleData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating roles data:", error);
            throw error;
        }
    }
};

export async function deleteRoleDetails(roleId, accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error deleting roles data:", error);
            throw error;
        }
    }
};

// for permissions Management


export async function fetchPermissionListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/permissions-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching permission list data:", error);
            throw error;
        }
    }
};


export async function createNewPermission(accessToken, refreshToken, permissionData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions-list/`, permissionData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/permissions-list/`, permissionData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new Permission data:", error);
            throw error;
        }
    }
};





export async function fetchPermissionDetails(permissionId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching permission data:", error);
            throw error;
        }
    }
};



export async function updatePermissionDetails(accessToken, refreshToken, permissionId, permissionData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, permissionData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, permissionData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating permissions  data:", error);
            throw error;
        }
    }
};

export async function deletePermissionDetails(permissionId, accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting permissions data:", error);
            throw error;
        }
    }
};



// for application Management

export async function fetchApplicationListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/applications-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching application list data:", error);
            throw error;
        }
    }
};


export async function createNewApplication(accessToken, refreshToken, appData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications-list/`, appData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/applications-list/`, appData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new Application data:", error);
            throw error;
        }
    }
};





export async function fetchApplicationDetails(applicationId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching applications data:", error);
            throw error;
        }
    }
};



export async function updateApplicationDetails(accessToken, refreshToken, applicationId, appData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, appData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, appData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating applications  data:", error);
            throw error;
        }
    }
};

export async function deleteApplicationDetails(applicationId, accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting applications data:", error);
            throw error;
        }
    }
};

// for organization management


export async function fetchOrganizationListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/organization-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/organization-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching organization list data:", error);
            throw error;
        }
    }
};


export async function createNewOrganization(accessToken, refreshToken, orgData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/organization-list/`, orgData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.post(`${API_BASE_URL}api/organization-list/`, orgData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new Organization data:", error);
            throw error;
        }
    }
};





export async function fetchOrganizationDetails(orgId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/organization/${orgId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/organization/${orgId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching organization data:", error);
            throw error;
        }
    }
};



export async function updateOrganizationDetails(accessToken, refreshToken, orgId, orgData) {
    try{
        const response = await axios.put(`${API_BASE_URL}api/organization/${orgId}/details/`, orgData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.put(`${API_BASE_URL}api/organization/${orgId}/details/`, orgData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating organization  data:", error);
            throw error;
        }
    }
};

export async function deleteOrganizationDetails(orgId, accessToken, refreshToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/organization/${orgId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.delete(`${API_BASE_URL}api/organization/${orgId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting organization data:", error);
            throw error;
        }
    }
};

//for organization subtype management

export async function fetchOrgSubTypeListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/org-subtype-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/org-subtype-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching org-subtype list data:", error);
            throw error;
        }
    }
};


export async function createNewOrgSubType(accessToken, refreshToken, orgsubtypeData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/org-subtype-list/`, orgsubtypeData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/org-subtype-list/`, orgsubtypeData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new org-subtype data:", error);
            throw error;
        }
    }
};





export async function fetchOrgSubTypeDetails(orgSubtypeId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching org-subtype data:", error);
            throw error;
        }
    }
};



export async function updateOrgSubTypeDetails(accessToken, refreshToken, orgSubtypeId, orgsubtypeData) {
    try{
        const response = await axios.put(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, orgsubtypeData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.put(`${API_BASE_URL}api/org-subtype/${orgId}/details/`, orgData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating org-subtype  data:", error);
            throw error;
        }
    }
};

export async function deleteOrgSubTypeDetails(orgSubtypeId, accessToken, refreshToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.delete(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting org-subtype data:", error);
            throw error;
        }
    }
};


// for location management



export async function fetchLocationListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/locations-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching locations list data:", error);
            throw error;
        }
    }
};


export async function createNewLocation(accessToken, refreshToken, locationsData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations-list/`, locationsData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/locations-list/`, locationsData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new locations data:", error);
            throw error;
        }
    }
};





export async function fetchLocationDetails(locationId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching locations data:", error);
            throw error;
        }
    }
};



export async function updateLocationDetails(accessToken, refreshToken, locationId, locationData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, locationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, locationData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating locations  data:", error);
            throw error;
        }
    }
};

export async function deleteLocationDetails(locationId, accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting locations data:", error);
            throw error;
        }
    }
};

// for department management


export async function fetchDepartmentListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/department-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching Department list data:", error);
            throw error;
        }
    }
};


export async function createNewDepartment(accessToken, refreshToken, departmentData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department-list/`, departmentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/department-list/`, departmentData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new Department data:", error);
            throw error;
        }
    }
};





export async function fetchDepartmentDetails(departmentId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching Department data:", error);
            throw error;
        }
    }
};



export async function updateDepartmentDetails(accessToken, refreshToken, departmentId, departmentData) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, departmentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, departmentData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating Department  data:", error);
            throw error;
        }
    }
};

export async function deleteDepartmentDetails(departmentId, accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting Department data:", error);
            throw error;
        }
    }
};


// for Designation Management

export async function fetchDesignationListData(accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designation-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/designation-list/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching Designation list data:", error);
            throw error;
        }
    }
};


export async function createNewDesignation(accessToken, refreshToken, designationData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/designation-list/`, designationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.post(`${API_BASE_URL}api/designation-list/`, designationData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error creating new Designation data:", error);
            throw error;
        }
    }
};





export async function fetchDesignationDetails(designationId,accessToken, refreshToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designation/${designationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.get(`${API_BASE_URL}api/designation/${designationId}/details`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error fetching Designation data:", error);
            throw error;
        }
    }
};



export async function updateDesignationDetails(accessToken, refreshToken, designationId, designationData) {
    try{
        const response = await axios.put(`${API_BASE_URL}api/designation/${designationId}/details/`, designationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.put(`${API_BASE_URL}api/designation/${designationId}/details/`, designationData, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                        "Content-Type": "application/json",
                    },
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error updating Designation  data:", error);
            throw error;
        }
    }
};

export async function deleteDesignationDetails(designationId, accessToken, refreshToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/designation/${designationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        if (error.response?.status === 401) {
            try {
                const newAccessToken = await refreshAccessToken(refreshToken);
                const retryResponse = await axios.delete(`${API_BASE_URL}api/designation/${designationId}/details/`, {
                    headers: {
                        Authorization: `Bearer ${newAccessToken}`,
                    }
                });
                return retryResponse.data;
            } catch (refreshError) {
                console.error("Error refreshing access token:", refreshError);
                throw refreshError;
            }
        } else {
            console.error("Error Deleting Designation data:", error);
            throw error;
        }
    }
};



