
import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";

 
 export async function middleware(req) {
  const token = await getToken({ req, secret: process.env.AUTH_SECRET });

  if (!token) {
    // Redirect to login if no token is found
    return NextResponse.redirect(new URL('/login', req.url));
  }
  // const session = await auth()

  // if (!session) {
  //   return NextResponse.redirect('/auth/login');
  // }

  const userRole = token.user.roles;
  console.log(userRole);
  const { pathname } = req.nextUrl;

  if (pathname.startsWith('/dashboard/administrator') && userRole !== 'Administrator') {
    return NextResponse.redirect(new URL('/login', req.url));
  }

  if (pathname.startsWith('/dashboard/authenticator') && userRole !== 'Authenticator') {
    return NextResponse.redirect(new URL('/login', req.url));
  }

  if (pathname.startsWith('/dashboard/site-admin') && userRole !== 'site-admin') {
    return NextResponse.redirect(new URL('/login', req.url));
  }


  return NextResponse.next();

}

 export const config = {
  matcher: ['/dashboard/:path*'],
 };




