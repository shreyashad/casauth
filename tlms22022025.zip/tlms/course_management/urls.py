from django.urls import path
from .views import *

urlpatterns = [
    path('difficulty-level-list/', DifficultyLevelListView.as_view(), name='difficulty-level-list'),
    path('create-new-difficulty-level/', DifficultyLevelCreateView.as_view(), name='create-new-difficulty-level'),
    path('difficulty-level/<uuid:pk>/details/', DifficultyLevelDetailView.as_view(), name='difficulty-level-details'),
    path('course-category-list/', CourseCategoryListView.as_view(), name='course-category-list'),
    path('create-new-course-category/', CourseCategoryCreateView.as_view(), name='create-new-course-category'),
    path('course-category/<uuid:pk>/details/', CourseCategoryDetailView.as_view(), name='course-category-details'),
    path('course-list/', CourseListView.as_view(), name='course-only-list'),
    path('course/', CourseView.as_view(), name='course-list'),
    # Retrieve, update, or delete a specific course by UUID
    path('courses/<uuid:pk>/', CourseView.as_view(), name='course-detail'),
    # Retrieve the total duration of a specific course
    path('courses/<uuid:pk>/total_duration/', CourseView.as_view(),
         name='course-total-duration'),
    # Retrieve a course along with its related content details (custom method)
    path('courses/<uuid:pk>/details/', CourseView.as_view(), name='course-details'),
    path('module/', ModuleView.as_view(), name='module-list'),
    path('module/<uuid:pk>/', ModuleView.as_view(),name='module-detail'),
    path('module/<uuid:pk>/details/', ModuleView.as_view(), name='module-related-details'),
    path('video/', VideoContentView.as_view(), name='video-list'),
    path('video/<uuid:pk>/details/', VideoContentView.as_view(),name='video-detail'),
    path('material/', MaterialContentView.as_view(), name='material-list'),
    path('material/<uuid:pk>/details/', MaterialContentView.as_view(),name='material-detail'),

]