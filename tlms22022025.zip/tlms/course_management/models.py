import os
from autoslug import AutoSlugField
from django.db import models
from django.db.models import TextField
import shutil
from accounts.choices import StatusChoice
from accounts.models import BaseModel
from certificate_management.models import Certificate


def course_upload_to(instance, filename):
    """
       This function generates a path based on course slug and the content type.
       Each type of content (module, video, material, etc.) will have its own subfolder.
       """
    # Get course slug
    course_slug = instance.course.slug if hasattr(instance, 'course') else 'default'

    # Determine content type (like module, video, material, etc.)
    content_type = instance._meta.model_name

    # Generate file path
    file_path = os.path.join('courses', course_slug, content_type, filename)

    return file_path


# Create your models here.
class DifficultyLevel(BaseModel):
    name = models.CharField(max_length=100, unique=True)


    class Meta:
        verbose_name = 'Difficulty Level'
        verbose_name_plural = 'Difficulty Levels'

    def __str__(self):
        return self.name

class CourseCategory(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    image = models.ImageField(upload_to='course_category/', null=True, blank=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'Course Category'
        verbose_name_plural = 'Course Categories'

    def __str__(self):
        return self.name

class ActiveCourseManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(status=StatusChoice.ACTIVE)



class Course(BaseModel):
    title = models.CharField(max_length=200, unique=True)
    slug = AutoSlugField(populate_from='title', unique=True)
    description = models.TextField()
    category = models.ForeignKey(CourseCategory, on_delete=models.DO_NOTHING)
    cover_image = models.ImageField(upload_to=course_upload_to, null=True, blank=True)
    duration = models.DurationField()
    difficulty_level = models.ForeignKey(DifficultyLevel, on_delete=models.SET_NULL, null=True, blank=True,
                                         related_name='courses')
    prerequisites = models.TextField()
    learning_objectives = models.TextField(blank=True, null=True)
    has_certificate = models.BooleanField(default=False)
    certificate = models.ForeignKey(Certificate, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        verbose_name = 'Course'
        verbose_name_plural = 'Courses'

    def __str__(self):
        return self.title

    def delete(self, *args, **kwargs):
        # Get the folder path for the course
        folder_path = os.path.join('media', 'courses', self.slug)

        # Delete the course's folder and all its contents
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)

        super().delete(*args, **kwargs)


class Module(BaseModel):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="modules")
    title = models.CharField(max_length=255, help_text="Title of the module")
    description = models.TextField(null=True, blank=True, help_text="Description of the module")
    order = models.PositiveIntegerField(help_text="Order of the module in the course")
    is_mandatory = models.BooleanField(default=True, help_text="Indicates if this module is mandatory for the course")
    cover_image = models.ImageField(upload_to=course_upload_to, null=True, blank=True)

    class Meta:
        verbose_name = "Module"
        verbose_name_plural = "Modules"
        ordering = ["order"]

    def __str__(self):
        return f"{self.course.title} - {self.title}"


class BaseContent(BaseModel):
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name="%(class)s_contents")
    title = models.CharField(max_length=255)
    order = models.PositiveIntegerField(help_text="Order of the content in the module")

    class Meta:
        abstract = True
        ordering = ["order"]

    def __str__(self):
        return f"{self.module.title} - {self.title}"

class VideoContent(BaseContent):
    cover_image = models.ImageField(upload_to=course_upload_to, blank=True, null=True)
    url = models.URLField(help_text="URL of the video")
    duration = models.DurationField(help_text="Duration of the video")


    class Meta(BaseContent.Meta):
        verbose_name = "Video Content"
        verbose_name_plural = "Video Contents"

class MaterialContent(BaseContent):
    file = models.FileField(upload_to=course_upload_to, help_text="Upload the material file")

    class Meta(BaseContent.Meta):
        verbose_name = "Material Content"
        verbose_name_plural = "Material Contents"




class QuizContent(BaseContent):
    instructions = models.TextField(null=True, blank=True, help_text="Instructions for the quiz")
    time_limit = models.DurationField(null=True, blank=True, help_text="Optional time limit for the quiz")
    max_attempts = models.PositiveIntegerField(default=0, help_text="0 for unlimited attempts")
    passing_score = models.PositiveIntegerField(default=50, help_text="Minimum passing score (in percentage)")

    class Meta:
        verbose_name = "Quiz Content"
        verbose_name_plural = "Quiz Contents"


class QuizQuestion(BaseModel):
    QUESTION_TYPES = [
        ("mcq", "Multiple Choice"),
        ("true_false", "True/False"),
        ("fill_in_blank", "Fill in the Blank"),
    ]

    quiz_content = models.ForeignKey(
        QuizContent, on_delete=models.CASCADE, related_name="quiz_questions"
    )
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    order = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.quiz_content.title} - {self.question_text}"


class QuizOption(models.Model):
    question = models.ForeignKey(
        QuizQuestion, on_delete=models.CASCADE, related_name="quiz_options"
    )
    option_text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"Option: {self.option_text} ({'Correct' if self.is_correct else 'Wrong'})"


class QuizAttempt(models.Model):
    user = models.UUIDField(help_text="User ID of the person who attempted the quizz")
    quiz_content = models.ForeignKey(
        QuizContent, on_delete=models.CASCADE, related_name="quiz_attempts"
    )
    score = models.PositiveIntegerField(default=0)
    attempt_time = models.DateTimeField(auto_now_add=True)
    completed = models.BooleanField(default=False)

    class Meta:
        unique_together = ("user", "quiz_content", "attempt_time")


class AssessmentContent(BaseContent):
    description = models.TextField(blank=True, help_text="Detailed description of the assessment.")
    total_marks = models.PositiveIntegerField(help_text="Total marks for the assessment.")
    passing_marks = models.PositiveIntegerField(help_text="Minimum marks required to pass.")
    due_date = models.DateTimeField(help_text="Deadline for completing the assessment.")
    evaluation_type = models.CharField(
        max_length=50,
        choices=[("AUTO", "Automatic"), ("MANUAL", "Manual Evaluation")],
        default="AUTO",
        help_text="Type of assessment evaluation."
    )

    def __str__(self):
        return f"Assessment: {self.title} in Module: {self.module.title}"



class CourseReview(BaseModel):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="reviews")
    user = models.UUIDField(help_text="User ID of the person who wrote the review")
    rating = models.PositiveIntegerField()
    review_text = models.TextField()

    class Meta:
        verbose_name = "Course Review"
        verbose_name_plural = "Course Reviews"