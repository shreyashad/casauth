from datetime import timedelta

from .models import *
from rest_framework import serializers

class DifficultyLevelListSerializer(serializers.ModelSerializer):
    class Meta:
        model = DifficultyLevel
        fields = ['id', 'name']

class CourseCategoryListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'image', 'description']

class CourseListSerializer(serializers.ModelSerializer):
    category = CourseCategoryListSerializer()
    difficulty_level = DifficultyLevelListSerializer()
    certificate = serializers.PrimaryKeyRelatedField(queryset=Certificate.objects.all(), required=False)

    class Meta:
        model = Course
        fields = ['id', 'title', 'slug', 'description','category','cover_image','duration','difficulty_level',
                  'prerequisites','certification','learning_objectives', 'status']


"""
for all course related nested serializers  
"""

class StatusChoiceField(serializers.ChoiceField):
    def __init__(self, **kwargs):
        kwargs["choices"] = StatusChoice.choices
        super().__init__(**kwargs)

class BaseContentSerializer(serializers.ModelSerializer):
    status = StatusChoiceField(required=False)
    class Meta:
        model = BaseContent
        fields = ['id', 'module', 'title', 'order', 'status']


class VideoContentSerializer(BaseContentSerializer):
    cover_image = serializers.ImageField(required=False)
    url = serializers.URLField()
    duration = serializers.DurationField()
    class Meta(BaseContentSerializer.Meta):
        model = VideoContent
        fields = BaseContentSerializer.Meta.fields + ['cover_image', 'url', 'duration']

class MaterialContentSerializer(serializers.ModelSerializer):
    file = serializers.FileField()
    class Meta(BaseContentSerializer.Meta):
        model = MaterialContent
        fields = BaseContentSerializer.Meta.fields + ['file']



class QuizOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuizOption
        fields = ['id', 'option_text', 'is_correct' ]


class QuizQuestionSerializer(serializers.ModelSerializer):
    quiz_options = QuizOptionSerializer(many=True, required=False)

    class Meta:
        model = QuizQuestion
        fields = ['id', 'question_text', 'question_type', 'order', 'quiz_options']


class QuizContentSerializer(BaseContentSerializer):
    instructions = serializers.CharField(required=False, allow_blank=True)
    time_limit = serializers.DurationField(required=False)
    max_attempts = serializers.IntegerField(default=0)
    passing_score = serializers.IntegerField(default=50)
    quiz_questions = QuizQuestionSerializer(many=True, required=False)


class Meta(BaseContentSerializer.Meta):
    model = QuizContent
    fields = BaseContentSerializer.Meta.fields + ['instructions', 'time_limit', 'max_attempts', 'passing_score',
                                                  'quiz_questions']


class AssessmentContentSerializer(BaseContentSerializer):
    description = serializers.CharField(required=False, allow_blank=True)
    total_marks = serializers.IntegerField()
    passing_marks = serializers.IntegerField()
    due_date = serializers.DateTimeField()
    evaluation_type = serializers.ChoiceField(choices=[('AUTO', 'Automatic'), ('MANUAL', 'Manual Evaluation')])

    class Meta(BaseContentSerializer.Meta):
        model = AssessmentContent
        fields = BaseContentSerializer.Meta.fields + ['description', 'total_marks', 'passing_marks', 'due_date', 'evaluation_type']



class ModuleSerializer(serializers.ModelSerializer):
    status = StatusChoiceField(required=False)
    video_contents = VideoContentSerializer(many=True, required=False)
    material_contents = MaterialContentSerializer(many=True, required=False)
    quiz_contents = QuizContentSerializer(many=True, required=False)
    assessment_contents = AssessmentContentSerializer(many=True, required=False)


    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'order', 'is_mandatory', 'status',  'video_contents',
                  'material_contents', 'quiz_contents', 'assessment_contents']

    def create(self, validated_data):
        video_data = validated_data.pop('video_contents',[])
        material_data = validated_data.pop('material_contents', [])
        quiz_data = validated_data.pop('quiz_contents', [])
        assessment_data = validated_data.pop('assessment_contents', [])
        module = Module.objects.create(**validated_data)

        for video in video_data:
            VideoContent.objects.create(module=module, **video)
        for material in material_data:
            MaterialContent.objects.create(module=module, **material)
        for quiz in quiz_data:
            quiz_content = QuizContent.objects.create(module=module, **quiz)
            for question in quiz.get('quiz_questions', []):
                quiz_question = QuizQuestion.objects.create(quiz_content=quiz_content, **question)
                for option in question.get('options', []):
                    QuizOption.objects.create(quiz_question=quiz_question, **option)
        for assessment in assessment_data:
            AssessmentContent.objects.create(module=module, **assessment)

        return module



class CourseSerializer(serializers.ModelSerializer):
    status = StatusChoiceField(required=False)
    modules = ModuleSerializer(many=True, required=False)
    category = CourseCategoryListSerializer()
    difficulty_level = DifficultyLevelListSerializer()
    certificate = serializers.PrimaryKeyRelatedField(queryset=Certificate.objects.all(), required=False)
    class Meta:
        model = Course
        fields = ['id','title', 'slug', 'description', 'category', 'cover_image', 'duration', 'difficulty_level',
                  'prerequisites', 'learning_objectives', 'has_certificate', 'certificate', 'status', 'modules' ]

    def get_total_duration(self, obj):
        # This method will still be used if you need the total duration as a read-only field
        total_duration = timedelta()

        for module in obj.modules.all():
            # Sum up the durations of video contents
            for video in module.video_contents.all():
                total_duration += video.duration
            # Add durations for material contents (if required)
            for material in module.material_contents.all():
                # Assuming material has no duration, or if you assign a default, you can add it here
                total_duration += timedelta()  # No specific duration for materials in this case

            # Add durations for quizzes (based on time_limit, if present)
            for quiz in module.quiz_contents.all():
                if quiz.time_limit:
                    total_duration += quiz.time_limit

            # If assessments have durations, you can also add them here
            for assessment in module.assessment_contents.all():
                # Assuming assessments do not have specific time limits, if they do, add them here
                total_duration += timedelta()  # No duration logic for assessment contents

        return total_duration


    def create(self, validated_data):
        modules_data = validated_data.pop('modules', [])
        course = Course.objects.create(**validated_data)

        # Initialize total duration for the course
        total_duration = timedelta()

        # Create associated modules and their content
        for module_data in modules_data:
            module = Module.objects.create(course=course, **module_data)
            for video_data in module_data.get('video_contents', []):
                video = VideoContent.objects.create(module=module, **video_data)
                total_duration += video.duration  # Add video duration to total_duration

            for material_data in module_data.get('material_contents', []):
                MaterialContent.objects.create(module=module, **material_data)
                # Assuming material has no duration, or you can add it if required

            for quiz_data in module_data.get('quiz_contents', []):
                quiz = QuizContent.objects.create(module=module, **quiz_data)
                if quiz.time_limit:
                    total_duration += quiz.time_limit  # Add quiz time limit to total_duration

            for assessment_data in module_data.get('assessment_contents', []):
                AssessmentContent.objects.create(module=module, **assessment_data)
                # Assuming assessment has no duration, add it if applicable

        # After all the modules and their content are created, assign the calculated duration
        course.duration = total_duration
        course.save()

        return course

    def update(self, instance, validated_data):
        modules_data = validated_data.pop('modules', [])
        instance.title = validated_data.get('title', instance.title)
        instance.slug = validated_data.get('slug', instance.slug)
        instance.description = validated_data.get('description', instance.description)
        instance.category = validated_data.get('category', instance.category)
        instance.cover_image = validated_data.get('cover_image', instance.cover_image)
        instance.difficulty_level = validated_data.get('difficulty_level', instance.difficulty_level)
        instance.prerequisites = validated_data.get('prerequisites', instance.prerequisites)
        instance.learning_objectives = validated_data.get('learning_objectives', instance.learning_objectives)
        instance.has_certificate = validated_data.get('has_certificate', instance.has_certificate)
        instance.certificate = validated_data.get('certificate', instance.certificate)
        instance.status = validated_data.get('status', instance.status)

        # Initialize total duration for the course
        total_duration = timedelta()

        # Update associated modules and their content
        for module_data in modules_data:
            module = Module.objects.get(id=module_data['id'])  # Assume modules are updated by their ID
            module.title = module_data.get('title', module.title)
            module.description = module_data.get('description', module.description)
            module.order = module_data.get('order', module.order)
            module.is_mandatory = module_data.get('is_mandatory', module.is_mandatory)
            module.cover_image = module_data.get('cover_image', module.cover_image)
            module.save()

            for video_data in module_data.get('video_contents', []):
                video = VideoContent.objects.create(module=module, **video_data)
                total_duration += video.duration  # Add video duration to total_duration

            for material_data in module_data.get('material_contents', []):
                MaterialContent.objects.create(module=module, **material_data)
                # Assuming material has no duration, or you can add it if required

            for quiz_data in module_data.get('quiz_contents', []):
                quiz = QuizContent.objects.create(module=module, **quiz_data)
                if quiz.time_limit:
                    total_duration += quiz.time_limit  # Add quiz time limit to total_duration

            for assessment_data in module_data.get('assessment_contents', []):
                AssessmentContent.objects.create(module=module, **assessment_data)
                # Assuming assessment has no duration, add it if applicable

        # After all the modules and their content are updated, assign the calculated duration
        instance.duration = total_duration
        instance.save()

        return instance




#
# class ModuleSerializer(serializers.ModelSerializer):
#     course = CourseSerializer()
#
#     class Meta:
#         model = Module
#         fields = ['id', 'course', 'title', 'description', 'order', 'is_mandatory', 'cover_image']
#
#
#
#
# class BaseContentSerializer(serializers.ModelSerializer):
#     module = ModuleSerializer()
#
#     class Meta:
#         model = BaseContent
#         fields = ['id', 'module', 'title', 'order']
#
#
# class VideoContentSerializer(BaseContentSerializer):
#     url = serializers.URLField()
#     duration = serializers.DurationField()
#     cover_image = serializers.ImageField(required=False)
#
#     class Meta(BaseContentSerializer.Meta):
#         model = VideoContent
#         fields = BaseContentSerializer.Meta.fields + ['url', 'duration', 'cover_image']
#
#
# class MaterialContentSerializer(BaseContentSerializer):
#     file = serializers.FileField()
#
#     class Meta(BaseContentSerializer.Meta):
#         model = MaterialContent
#         fields = BaseContentSerializer.Meta.fields + ['file']
#
#
# class QuizContentSerializer(BaseContentSerializer):
#     instructions = serializers.CharField(required=False)
#     time_limit = serializers.DurationField(required=False)
#     max_attempts = serializers.IntegerField(default=0)
#     passing_score = serializers.IntegerField(default=50)
#
#     class Meta(BaseContentSerializer.Meta):
#         model = QuizContent
#         fields = BaseContentSerializer.Meta.fields + ['instructions', 'time_limit', 'max_attempts', 'passing_score']
#
#
# class QuizQuestionSerializer(serializers.ModelSerializer):
#     quiz_content = QuizContentSerializer()
#
#     class Meta:
#         model = QuizQuestion
#         fields = ['id', 'quiz_content', 'question_text', 'question_type', 'order']
#
#
# class QuizOptionSerializer(serializers.ModelSerializer):
#     question = QuizQuestionSerializer()
#
#     class Meta:
#         model = QuizOption
#         fields = ['id', 'question', 'option_text', 'is_correct']
#
#
# class QuizAttemptSerializer(serializers.ModelSerializer):
#     user = serializers.UUIDField()
#     quiz_content = QuizContentSerializer()
#
#     class Meta:
#         model = QuizAttempt
#         fields = ['id', 'user', 'quiz_content', 'score', 'attempt_time', 'completed']
#
#
# class AssessmentContentSerializer(BaseContentSerializer):
#     description = serializers.CharField(required=False)
#     total_marks = serializers.IntegerField()
#     passing_marks = serializers.IntegerField()
#     due_date = serializers.DateTimeField()
#     evaluation_type = serializers.ChoiceField(choices=[("AUTO", "Automatic"), ("MANUAL", "Manual Evaluation")])
#
#     class Meta(BaseContentSerializer.Meta):
#         model = AssessmentContent
#         fields = BaseContentSerializer.Meta.fields + ['description', 'total_marks', 'passing_marks', 'due_date',
#                                                       'evaluation_type']
#
#
# class CourseReviewSerializer(serializers.ModelSerializer):
#     course = CourseSerializer()
#
#     class Meta:
#         model = CourseReview
#         fields = ['id', 'course', 'user', 'rating', 'review_text']
