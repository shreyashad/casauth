from corsheaders.checks import re_type
from django.shortcuts import render
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination

from accounts.authentication import CustomJWTAuthentication
from accounts.utils import log_retrieval_action
from .models import *
from .serializers import *
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny


# Create your views here.

class DifficultyLevelListView(generics.ListAPIView):
    authentication_classes = [CustomJWTAuthentication]
    queryset = DifficultyLevel.objects.all()
    serializer_class = DifficultyLevelListSerializer
    permission_classes = [IsAuthenticated]

class DifficultyLevelCreateView(generics.ListAPIView):
    queryset = DifficultyLevel.objects.all()
    serializer_class = DifficultyLevelListSerializer
    permission_classes = [IsAuthenticated]

class DifficultyLevelDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = DifficultyLevel.objects.all()
    serializer_class = DifficultyLevelListSerializer
    permission_classes = [IsAuthenticated]



class CourseCategoryListView(generics.ListAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategoryListSerializer
    permission_classes = [IsAuthenticated]

class CourseCategoryCreateView(generics.CreateAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategoryListSerializer
    permission_classes = [IsAuthenticated]

class CourseCategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategoryListSerializer
    permission_classes = [IsAuthenticated]


class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseListSerializer
    permission_classes = [IsAuthenticated]


class CoursePagination(PageNumberPagination):
    page_size = 10
    page_query_param = 'page_size'
    max_page_size = 100

class CourseView(APIView):
    permission_classes = [AllowAny]

    def get_course(self, pk):
        """
        Helper method to retrieve a specific course by ID along with its related content.
        """
        try:
            # Prefetch related data for modules and their contents (video, material, quiz, assessment)
            course = Course.objects.prefetch_related(
                'modules__video_contents',
                'modules__material_contents',
                'modules__quiz_contents__quiz_questions__quiz_options',
                'modules__assessment_contents'
            ).get(pk=pk)

            return course
        except Course.DoesNotExist:
            return None

    def get(self, request, *args, **kwargs):
        """
        List all courses with pagination.
        """
        courses = Course.objects.all()
        paginator = self.pagination_class()
        page = paginator.paginate_queryset(courses, request)
        if page is not None:
            serializer = CourseSerializer(page, many=True)
            return paginator.get_paginated_response(serializer.data)

        serializer = CourseSerializer(courses, many=True)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        """
        Create a new course.
        """
        serializer = CourseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, *args, **kwargs):
        """
        Update a course.
        """
        course = self.get_course(kwargs['pk'])
        if not course:
            return Response({"detail": "Course not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = CourseSerializer(course, data=request.data, partial=True)
        if serializer.is_valid():
            updated_course = serializer.save()
            return Response(CourseSerializer(updated_course).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        """
        Delete a specific course.
        """
        course = self.get_course(kwargs['pk'])
        if not course:
            return Response({"detail": "Course not found."}, status=status.HTTP_404_NOT_FOUND)

        course.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=['get'])
    def total_duration(self, request, pk=None):
        """
        Get the total duration of a specific course.
        """
        course = self.get_course(pk)
        if not course:
            return Response({"detail": "Course not found."}, status=status.HTTP_404_NOT_FOUND)

        total_duration = course.duration
        return Response({'total_duration': str(total_duration)})

    def get_course_details(self, request, pk=None):
        """
        Retrieve details course data with all related content serialized.
        """
        course = self.get_course(pk)
        if not course:
            return Response({"detail": "Course not found."}, status=status.HTTP_404_NOT_FOUND)
        log_retrieval_action(course, request)
        # Use the CourseSerializer to serialize the entire course, including related data
        serializer = CourseSerializer(course)

        return Response(serializer.data)


class ModuleView(APIView):
    permission_classes = [AllowAny]

    def get_module(self, pk):
        """
            Helper method to retrieve a specific module by ID along with its related content.
        """
        try:
            module = Module.objects.prefetch_related(
                'video_contents',  # Prefetch related video contents
                'material_contents',  # Prefetch related material contents
                'quiz_contents',  # Prefetch related quiz contents
                'assessment_contents'
            ).get(id=pk)

            return module
        except Module.DoesNotExist:
            return None
    def get(self, request, *args, **kwargs):
        modules = Module.objects.all()
        serializer = ModuleSerializer(modules, many=True)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        serializer = ModuleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        module = self.get_module(kwargs['pk'])
        if not module:
            return Response({"detail": "Module not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = ModuleSerializer(module, data=request.data, partial=True)
        if serializer.is_valid():
            updated_module = serializer.save()
            return Response(ModuleSerializer(updated_module).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        module = self.get_module(kwargs['pk'])
        if not module:
            return Response({"detail": "Module not found."}, status=status.HTTP_404_NOT_FOUND)

        module.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def get_module_details(self, request, pk=None):
        """
                Retrieve details module data with all related content serialized.
        """
        module = self.get_module(pk)
        if not module:
            return Response({"detail": "Module not found."}, status=status.HTTP_404_NOT_FOUND)

        log_retrieval_action(module, request)
        # Use the ModuleSerializer to serialize the entire module, including related data
        serializer = ModuleSerializer(module)
        return Response(serializer.data)



class VideoContentView(APIView):
    permission_classes = [AllowAny]

    def get_video_content(self, pk):
        try:
            return VideoContent.objects.get(pk=pk)
        except VideoContent.DoesNotExist:
            return None

    def get(self, request, *args, **kwargs):
        video_contents = VideoContent.objects.all()
        serializer = VideoContentSerializer(video_contents, many=True)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        serializer = VideoContentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        video_content = self.get_video_content(kwargs['pk'])
        if not video_content:
            return Response({"detail": "Video content not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = VideoContentSerializer(video_content, data=request.data, partial=True)
        if serializer.is_valid():
            updated_video_content = serializer.save()
            return Response(VideoContentSerializer(updated_video_content).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        video_content = self.get_video_content(kwargs['pk'])
        if not video_content:
            return Response({"detail": "Video content not found."}, status=status.HTTP_404_NOT_FOUND)

        video_content.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MaterialContentView(APIView):
    permission_classes = [AllowAny]

    def get_material_content(self, pk):
        try:
            return MaterialContent.objects.get(pk=pk)
        except MaterialContent.DoesNotExist:
            return None

    def get(self, request, *args, **kwargs):
        material_contents = MaterialContent.objects.all()
        serializer = MaterialContentSerializer(material_contents, many=True)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        serializer = MaterialContentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        material_content = self.get_material_content(kwargs['pk'])
        if not material_content:
            return Response({"detail": "Material content not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = MaterialContentSerializer(material_content, data=request.data, partial=True)
        if serializer.is_valid():
            updated_material_content = serializer.save()
            return Response(MaterialContentSerializer(updated_material_content).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        material_content = self.get_material_content(kwargs['pk'])
        if not material_content:
            return Response({"detail": "Material content not found."}, status=status.HTTP_404_NOT_FOUND)

        material_content.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
