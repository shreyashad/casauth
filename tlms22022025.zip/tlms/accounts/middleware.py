from django.utils.deprecation import MiddlewareMixin
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView


class AuthenticationMiddleware(MiddlewareMixin):
    def __call__(self, request,*args, **kwargs):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        if hasattr(view_func, 'cls') and issubclass(view_func.cls, APIView):
            # Check if AllowAny is in permission_classes
            if AllowAny in getattr(view_func.cls, 'permission_classes', []):
                return None  # Skip middleware for AllowAny views

        auth_header = request.headers.get('Authorization')
        service_ticket = request.GET.get('service_ticket')  # Only from GET if redirect
        app_id = request.headers.get('Application-Id') # Application ID from header

        if not app_id:
            raise PermissionDenied("Application ID is required")
        try: