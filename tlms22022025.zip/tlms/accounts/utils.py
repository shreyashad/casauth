import requests
from django.conf import settings
from django.core.cache import cache



def send_audit_log(data):
    try:
        response = requests.post(f"{settings.AUTH_SERVER_BASE_URL}api/audit-log/", data=data)
        if response.status_code != 201:
            raise Exception(f"Failed to send audit log: {response.content}")
    except Exception as e:
        # Log the error locally
        print(f"Error sending audit log: {str(e)}")

class ApplicationDetailsError(Exception): # Define custom Exception
    pass

def fetch_and_store_application_details():
    """Fetches application details from the auth server and stores them in the cache."""

    required_settings = ['AUTH_SERVER_BASE_URL', 'REGISTERED_APP_NAME']  # TLMS_APP_DETAILS removed

    for setting in required_settings:
        if not hasattr(settings, setting):
            raise ValueError(f"Missing required setting: {setting}")

    if cache.get(settings.TLMS_APP_DETAILS):
        return

    try:
        response = requests.post(
            f"{settings.AUTH_SERVER_BASE_URL}api/application-details/",
            data={'name': settings.REGISTERED_APP_NAME},
            timeout=10  # Add a timeout for the request
        )
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        app_data = response.json().get('app')

        if not app_data:
            error_message = response.json().get('error', 'Invalid response format: "app" key missing') # Extract error message from response, or a default message
            raise ApplicationDetailsError(error_message) # Raise custom exception

        cache.set(settings.TLMS_APP_DETAILS, app_data, timeout=60 * 60 * 24)  # Cache for 24 hours

    except requests.exceptions.RequestException as e:  # Catch requests-specific errors
        raise ApplicationDetailsError(f"Error fetching application details: {str(e)}")
    except (ValueError, KeyError) as e:  # Handle JSON decoding errors or missing keys
        raise ApplicationDetailsError(f"Error processing application details: {str(e)}")
    except Exception as e: # Catch other potential exceptions
        raise ApplicationDetailsError(f"An unexpected error occurred: {str(e)}")




def log_retrieval_action(obj, request):
    """
    Log the retrieval action for the object.
    """
    user = request.user if request.user.is_authenticated else None
    try:
        send_audit_log({
            "user": user.id if user else None,
            "application_name": "TLMS",  # Adjust this with your app name
            "action_type": "Read",
            "object_id": str(obj.id),
            "object_type": obj.__class__.__name__,
            "app_label": obj._meta.app_label,
            "details": f"{obj.__class__.__name__} '{str(obj)}' was retrieved."
        })
    except Exception as e:
        # Handle logging failure gracefully
        pass




# def fetch_and_store_application_details():
#     # Check if the application details are already in cache
#     app_data = cache.get(settings.TLMS_APP_DETAILS)
#
#     if app_data:
#         return app_data  # Return from cache if available
#
#     # Otherwise, fetch the application details from CAS API
#     try:
#         response = requests.post(f"{settings.AUTH_SERVER_BASE_URL}api/application-details/", data={'name': settings.REGISTERED_APP_NAME})
#         if response.status_code == 200:
#             app_data = response.json().get('app')
#             # Cache the details for 24 hours (adjust the timeout as needed)
#             cache.set(settings.TLMS_APP_NAME, app_data, timeout=60 * 60 * 24)
#             return app_data
#         else:
#             raise ValueError(f"Failed to fetch application details: {response.json().get('error')}")
#     except Exception as e:
#             raise ValueError(f"Error fetching application details: {str(e)}")