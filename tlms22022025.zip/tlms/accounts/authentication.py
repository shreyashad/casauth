import requests
from django.conf import settings
from django.core.cache import cache
from rest_framework import exceptions
from rest_framework.request import Request
from rest_framework_simplejwt.authentication import JWTAuthentication, AuthUser
from rest_framework_simplejwt.tokens import Token, AccessToken


class CustomJWTAuthentication(JWTAuthentication):
    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None

        raw_token = self.get_raw_token(header)
        if raw_token is None:
            return None
        print(raw_token)
        validated_token = self.validate_token(raw_token)
        return validated_token

    def validate_token(self, raw_token):
        access_token = AccessToken(raw_token)
        payload = access_token.payload
        # 1. Get the kid from the JWT header
        kid = access_token.header.get('kid')
        if not kid:
            raise exceptions.AuthenticationFailed('kid is missing in JWT header')

        # 2. Fetch the JWKS from the auth server (and cache it)
        jwks = cache.get('jwks')
        print(f"jwks stored in cache:{jwks}")
        if not jwks:
            jwks_url = f"{settings.AUTH_SERVER_BASE_URL}api/jwks/"
            print(f"Fetching JWKS from: {jwks_url}")
            try:
                jwks_response = requests.get(jwks_url)
                jwks_response.raise_for_status()
                jwks = jwks_response.json()
                print(f"JWKS Response: {jwks}")
                cache.set('jwks', jwks, 60*60) #Cache for 1 hour
            except requests.exceptions.RequestException as e:
                print(f"Failed to fetch JWKS: {e}")
                raise exceptions.AuthenticationFailed(f"Failed to fetch JWKS:  {e}")
            except (ValueError, KeyError):
                raise exceptions.AuthenticationFailed("Invalid JWKS format")

        # 3. Find the key with the matching kid
        key = None
        for k in jwks.get('keys', []):
            if k.get('kid') == kid:
                key = k
                break

        if not key:
            raise exceptions.AuthenticationFailed('No matching key found in JWKS')

        # 4. Verify the JWT signature using the key
        try:
            # Construct the public key object from the components
            n = int(key['n'], 16)  # Convert hex to int
            e = int(key['e'], 16)  # Convert hex to int
            from cryptography.hazmat.primitives.asymmetric import rsa
            public_key = rsa.RSAPublicNumbers(n, e).public_key()

            access_token.verify(public_key, 'RS256')  # Or the correct algorithm

        except Exception as e:  # Catch any verification errors
            print(e)
            raise exceptions.AuthenticationFailed('Invalid token signature')

        # 5. Extract and validate claims (after successful verification!)
        app_details = cache.get('TLMS_APP_DETAILS')
        if not app_details:
            raise exceptions.AuthenticationFailed('Application details not found')

        expected_app_id = app_details.get('id')
        expected_app_name = app_details.get('name')

        app_id = payload.get('application_id')
        app_name = payload.get('app_name')

        if not app_id or not app_name:
            raise exceptions.AuthenticationFailed('application_id or app_name claim is missing')

        if str(app_id) != str(expected_app_id):  # Compare string versions of UUIDs
            raise exceptions.AuthenticationFailed('Invalid application_id')
        if app_name != expected_app_name:
            raise exceptions.AuthenticationFailed('Invalid app_name')

        return (payload, access_token)  # Return payload and token (user object is typically retrieved later)
