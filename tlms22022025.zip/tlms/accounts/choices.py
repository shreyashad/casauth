from django.db import models

class StatusChoice(models.TextChoices):
    DRAFT = 'Draft', 'Draft'
    PUBLISHED = 'Published', 'Published'
    INACTIVE = 'Inactive', 'Inactive'
    ARCHIVED = 'Archived', 'Archived'
    RETIRED = 'Retired', 'Retired'
    PENDING_APPROVAL = 'Pending Approval', 'Pending Approval'
    REJECTED = 'Rejected', 'Rejected'
