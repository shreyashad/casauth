import requests
from django.conf import settings
from django.core.cache import cache
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework_simplejwt.authentication import JWTAuthentication

from .serializers import *
from .utils import fetch_and_store_application_details
import logging
logger = logging.getLogger(__name__)

# Create your views here.
class LoginView(APIView):
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']
        # Fetch application details from settings
        app_details = cache.get(settings.TLMS_APP_DETAILS)
        if not app_details:
            return Response({"error": "Application details not found in cache"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        application_id = app_details.get('id')
        credentials = {
            'username': username,
            'password': password,
            'application_id': application_id
        }
        # send the credentials to CAS
        try:
            login_response = requests.post(
                f"{settings.AUTH_SERVER_BASE_URL}api/cas-login/",
                data=credentials,
                # add a timeout for the request
                )
            if login_response.status_code != 200:
                try:
                    cas_error_data = login_response.json()
                    error_message = cas_error_data.get("error", "CAS login failed")
                    error_code = cas_error_data.get("code")
                except ValueError: # Handle cases where the response is not a json
                    error_message = f"CAS login failed with status code {login_response.status_code}"
                    error_code = None
                logger.error(f"CAS login failed: {error_message} (Status code: {login_response.status_code})")
                return Response({"error": error_message}, status=status.HTTP_401_UNAUTHORIZED)

            cas_data = login_response.json()
            session_key = cas_data.get('session_key')
            service_ticket = cas_data.get('service_ticket')
            access_token = cas_data.get('access')
            refresh_token = cas_data.get('refresh')
            session_expires_at = cas_data.get('session_expires_at')
            # checking for missing data form login response
            if not session_key or not service_ticket or not access_token or not refresh_token or not session_expires_at:
                logger.error("Missing data in CAS response")
                return Response({"error": "Invalid CAS response format (missing data)"},
                                status=status.HTTP_502_BAD_GATEWAY)
            # step 2: Validate the service ticket
            ticket_validation_url = f"{settings.AUTH_SERVER_BASE_URL}api/validate-ticket/"
            ticket_validation_data = {
                'service_ticket': service_ticket,
                'application_id': application_id
            }
            try:
                cas_validate_ticket_response = requests.post(
                    ticket_validation_url,
                    data=ticket_validation_data,
                    timeout=10 # add a timeout for the request
                )
               # Check for errors during ticket validation
                if cas_validate_ticket_response.status_code != 200:
                    try:
                        cas_ticket_error_data = cas_validate_ticket_response.json()
                        error_message = cas_ticket_error_data.get("error", "Ticket validation failed")
                        error_code = cas_ticket_error_data.get("code")
                    except ValueError: # Handle cases where the response is not a json
                        error_message = f"Ticket validation failed with status code {cas_validate_ticket_response.status_code}"
                        error_code = None
                    logger.error(
                        f"Ticket validation failed: {error_message} (Status code: {cas_validate_ticket_response.status_code})")
                    return Response({"error": error_message, "code": error_code},
                                    status=cas_validate_ticket_response.status_code)
                user_data = cas_validate_ticket_response.json()  # Parse JSON only if successful
                logger.info("Ticket validation response received successfully.")
            except requests.exceptions.RequestException as e:
                logger.error(f"Ticket validation failed: {e}")
                return Response({"error": f"Ticket validation failed:{str(e)}"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
            return Response({
                "message": "Login successful",
                "access_token": cas_data.get('access'),
                "user": user_data,
                "refresh_token": cas_data.get('refresh'),
                "sessionKey": session_key,
                "service_ticket": service_ticket,
                "sessionExp": cas_data.get('session_expires_at')
            }, status=status.HTTP_200_OK)
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to connect to CAS: {e}")
            return Response({"error": f"Failed to connect to CAS: {e}"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        except Exception as e:
            logger.exception(f"An unexpected error occurred during login: {e}")
            return Response({"error": "An unexpected error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class PasswordExpiredChangePassword(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ChangePassword(data=request.data)
        if serializer.is_valid():
            try:
                cas_response = requests.post(
                    f"{settings.AUTH_SERVER_BASE_URL}api/password-expired/",
                    data=serializer.validated_data,
                    timeout=10  # add a timeout for the request
                )
                if cas_response.status_code == 200:
                    return Response({"message": "Password changed successfully."}, status=status.HTTP_200_OK)
                elif cas_response.status_code == 400:
                    error_data = cas_response.json()
                    return Response(error_data, status=status.HTTP_400_BAD_REQUEST)
                    # Handle user not found
                elif cas_response.status_code == 404:
                    return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

                # Handle unexpected errors
                return Response({"error": "Failed to change password"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            except requests.exceptions.RequestException:
                return Response({"error": "CAS server unreachable"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class TokenRefreshProxyView(APIView):
    def post(self, request):
        refresh_token = request.data.get('refresh_token')
        if not refresh_token:
            return Response({'error': 'Refresh token is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            cas_response = requests.post(
                f"{settings.AUTH_SERVER_BASE_URL}api/token-refresh/",
                data={'refresh_token': refresh_token},
                timeout=10 # add a timeout for the request
            )
            if cas_response.status_code != status.HTTP_200_OK:
                return Response({'error': 'Token refresh failed', 'message': cas_response.json().get('error', 'Unknown error occurred')}, status=cas_response.status_code)
            cas_data = cas_response.json()
            return Response({'access_token': cas_data.get('access'), 'refresh_token': cas_data.get('refresh')}, status=status.HTTP_200_OK)
        except requests.exceptions.RequestException as e:
            return Response({'error': f'Failed to connect to CAS: {e}'}, status=status.HTTP_503_SERVICE_UNAVAILABLE)


class TLMSLogOutView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def post(self, request, *args, **kwargs):
        session_key = request.headers.get('X-Session_key')

        if not session_key:
            return Response({"error": "Session key missing. Please provide the session key in the Authorization header."}, status=status.HTTP_400_BAD_REQUEST)

        session_key = session_key.split(" ")[1]
        cas_headers = {
            "Authorization": f"Bearer {session_key}",
        }
        try:
            logout_response = requests.post(
                f"{settings.AUTH_SERVER_BASE_URL}api/logout/",
                headers=cas_headers,
                timeout=10 # add a timeout for the request
            )
            if logout_response.status_code == 200:
                # Additional TLMS-specific cleanup logic (if any)
                # Example: Update user-specific training session status
                # TrainingSession.objects.filter(user=request.user, is_active=True).update(is_active=False)

                return Response({'status': 'Logged out successfully'}, status=status.HTTP_200_OK)
            elif logout_response.status_code == 401:
                return Response({'error': 'Session expired or invalid session key.'},
                                status=status.HTTP_401_UNAUTHORIZED)
            else:
                return Response({'error': 'Failed to log out from CAS.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except requests.exceptions.RequestException as e:
            return Response({'error': 'Unable to communicate with CAS. Please try again later.'},
                            status=status.HTTP_503_SERVICE_UNAVAILABLE)
