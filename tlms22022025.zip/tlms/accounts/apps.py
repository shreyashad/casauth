from django.apps import AppConfig
from accounts.utils import ApplicationDetailsError
import logging

logger = logging.getLogger(__name__)

class AccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounts'

    def ready(self):
        from .utils import fetch_and_store_application_details
        try:
            fetch_and_store_application_details()
        except ApplicationDetailsError as e:  # Catch your custom exception
            logger.error(f"Error during application startup: {str(e)}")  # Log the error
        except Exception as e:  # Catch any other exceptions
            logger.exception(f"An unexpected error occurred during startup: {e}")  # Log the full traceback