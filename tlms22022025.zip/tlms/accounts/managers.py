from django.db import models
from accounts.choices import StatusChoice

class StatusManager(models.Manager):
    def drafts(self):
        return self.filter(status=StatusChoice.DRAFT)

    def published(self):
        return self.filter(status=StatusChoice.PUBLISHED)

    def inactive(self):
        return self.filter(status=StatusChoice.INACTIVE)

    def archived(self):
        return self.filter(status=StatusChoice.ARCHIVED)
