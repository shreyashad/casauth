from django.urls import path
from.views import *

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('token/refresh/', TokenRefreshProxyView.as_view(), name='token_refresh_proxy'),
    path('password-expired-change-password/', PasswordExpiredChangePassword.as_view(), name='password-expired'),

]