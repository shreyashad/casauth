from django.db import models
from uuid import uuid4

from .choices import StatusChoice
from .managers import StatusManager
from .utils import send_audit_log


class BaseModel(models.Model):
    id = models.UUIDField(default=uuid4, unique=True, editable=False, db_index=True, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.CharField(max_length=100, null=True, blank=True)
    updated_by = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(
        max_length=50,
        choices=StatusChoice.choices,
        default=StatusChoice.DRAFT,
    )

    objects = StatusManager()

    class Meta:
        indexes = [
            models.Index(fields=['created_at']),
            models.Index(fields=['updated_at']),
        ]
        abstract = True


    def save(self, *args, **kwargs):
        # Set created_by or updated_by before saving
        user_id = kwargs.get('user_id', None)

        if not self.id:  # New object (creating)
            self.created_by = user_id
        else:  # Existing object (updating)
            self.updated_by = user_id

        super(BaseModel, self).save(*args, **kwargs)

        # Send an audit log after the object is created/updated
        self._send_audit_log(action_type="Create" if not self.id else "Update")

    def delete(self, *args, **kwargs):
        # Delete object and send an audit log
        current_user = kwargs.get('user_id', None)  # This would be passed when calling delete
        app_label = self._meta.app_label
        super().delete(*args, **kwargs)

        # Send the audit log for delete action
        self._send_audit_log(action_type="Delete", current_user=current_user)

    def _send_audit_log(self, action_type, current_user=None):
        """
        Helper method to send an audit log with object details.
        """
        try:
            send_audit_log({
                "user": current_user.id if current_user else None,
                "application_name": "TLMS",  # Adjust this with your app name
                "action_type": action_type,
                "object_id": str(self.id),
                "object_type": self.__class__.__name__,
                "app_label": self._meta.app_label,
                "details": f"{self.__class__.__name__} '{str(self)}' was {action_type.lower()}d."
            })
        except Exception:
            pass  # Prevent logging issues from breaking the main operation