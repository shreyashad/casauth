#old CustomAuth
import requests
from django.conf import settings
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed, PermissionDenied
from django.core.cache import cache
from django.contrib.auth import get_user_model



class AuthenticatedUser:
    """
        Represents an authenticated user with additional metadata like roles, permissions, and teams.
    """
    def __init__(self, user_data):
        self.user_data = user_data or {}
        self.is_authenticated = True

    @property
    def username(self):
        return self.user_data.get('username','')

    @property
    def user_id(self):
        return self.user_data.get('user_id', '')

    @property
    def roles(self):
        return self.user_data.get('roles', [])  # Assuming roles are provided

    @property
    def permissions(self):
        return self.user_data.get('permissions', [])


    @property
    def teams(self):
        return self.user_data.get('teams', [])

    def has_permission(self, permission):
        """
        Check if the user has a specific permission.
        """
        return permission in self.permissions

    def has_role(self, role):
        """
        Check if the user has a specific role.
        """
        return role in self.roles



class CustomCASAuthentication(BaseAuthentication):
    """
       Custom authentication class for Central Authentication System (CAS).
    """
    def authenticate(self, request):
        token = request.headers.get('Authorization')
        print(f"token received form frontend:", token)
        user_data = self._introspect_token(token)

        if not user_data.get('user_id'):
            raise AuthenticationFailed('Invalid token data: Missing user_id.')

        user = AuthenticatedUser(user_data)
        self._attach_user_to_request(request, user)
        return user, token

    def authenticate_header(self, request):
        return 'Bearer realm="api"'

    def _get_token_from_header(self, request):
        """
        Extract and validate the token from the Authorization header.
       """
        token = request.headers.get('Authorization')
        if not token:
            raise AuthenticationFailed('Authorization header is missing')

        if token.startswith('Bearer '):
            token = token[7:]
        else:
            raise AuthenticationFailed('Invalid token header format. Expected "Bearer <token>".')



    def _introspect_token(self, token):
        """
        Perform a token introspection by making a request to the auth server.
        """
        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}api/token/introspect/",
                params={'token': token, 'app_name': 'TLMS'},
                timeout=5 # add a timeout for the request
            )
            response.raise_for_status()
        except requests.RequestException as e:
            raise AuthenticationFailed(f'Token introspection failed: {str(e)}')

        try:
            return response.json()
        except ValueError:
            raise AuthenticationFailed('Invalid response from token introspection endpoint.')







        token = token or request.GET.get('token')

        if not token:
            return None

        if token.startswith('Bearer '):
            token = token[7:]
        else:
            raise AuthenticationFailed('Invalid token header')

        #Check chache first
        cached_user_data = cache.get(f"token:{token}")
        if cached_user_data:
            return (AutheticatedUser(cached_user_data), token)

        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}api/token/introspect/",
                params={'token': token}
            )
            response.raise_for_status()
        except requests.RequestException as e:

            raise AuthenticationFailed(f'Token introspection failed: {str(e)}')

        user_data = response.json()
        if not user_data.get('user_id'):
            raise AuthenticationFailed('Invalid token data')

        # Cache the valid token
        cache.set(f"token:{token}", user_data, timeout=300) # Cache for 5 minutes

        user = AutheticatedUser(user_data)
        request.user_id = user.user_id
        request.username = user.username
        return (user, token)

    def authenticate_header(self, request):
        return 'Bearer realm="api"'

-------------------------------
import requests
import json
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import exceptions
from rest_framework_simplejwt.tokens import AccessToken
from django.core.cache import cache

class CustomJWTAuthentication(JWTAuthentication):
    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None

        raw_token = self.get_raw_token(header)
        if raw_token is None:
            return None

        validated_token = self.validate_token(raw_token)
        return validated_token

    def validate_token(self, raw_token):
        access_token = AccessToken(raw_token)
        payload = access_token.payload

        # 1. Get the kid from the JWT header
        kid = access_token.header.get('kid')
        if not kid:
            raise exceptions.AuthenticationFailed('kid is missing in JWT header')

        # 2. Fetch the JWKS from the auth server (and cache it)
        jwks = cache.get('jwks')
        if not jwks:
            try:
                jwks_response = requests.get(f"{settings.AUTH_SERVER_BASE_URL}jwks/")
                jwks_response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
                jwks = jwks_response.json()
                cache.set('jwks', jwks, 60*60)  # Cache for 1 hour
            except requests.exceptions.RequestException as e:
                raise exceptions.AuthenticationFailed(f"Failed to fetch JWKS: {e}")
            except (ValueError, KeyError):
                raise exceptions.AuthenticationFailed("Invalid JWKS format")

        # 3. Find the key with the matching kid
        key = None
        for k in jwks.get('keys', []):
            if k.get('kid') == kid:
                key = k
                break

        if not key:
            raise exceptions.AuthenticationFailed('No matching key found in JWKS')

        # 4. Verify the JWT signature using the key
        try:
            # Construct the public key object from the components
            n = int(key['n'], 16) # Convert hex to int
            e = int(key['e'], 16) # Convert hex to int
            from cryptography.hazmat.primitives.asymmetric import rsa
            public_key = rsa.RSAPublicNumbers(n, e).public_key()

            access_token.verify(public_key, 'RS256')  # Or the correct algorithm

        except Exception as e:  # Catch any verification errors
            print(e)
            raise exceptions.AuthenticationFailed('Invalid token signature')


        # 5. Extract and validate claims (after successful verification!)
        app_details = cache.get('TLMS_APP_DETAILS')
        if not app_details:
            raise exceptions.AuthenticationFailed('Application details not found')

        expected_app_id = app_details.get('id')
        expected_app_name = app_details.get('name')

        app_id = payload.get('application_id')
        app_name = payload.get('app_name')

        if not app_id or not app_name:
            raise exceptions.AuthenticationFailed('application_id or app_name claim is missing')

        if str(app_id) != str(expected_app_id): # Compare string versions of UUIDs
            raise exceptions.AuthenticationFailed('Invalid application_id')
        if app_name != expected_app_name:
            raise exceptions.AuthenticationFailed('Invalid app_name')

        return (payload, access_token) # Return payload and token (user object is typically retrieved later)


REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'tlms.authentication.CustomJWTAuthentication', # Use your custom class
    ),
}