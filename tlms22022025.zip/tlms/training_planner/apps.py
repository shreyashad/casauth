from django.apps import AppConfig


class TrainingPlannerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'training_planner'
