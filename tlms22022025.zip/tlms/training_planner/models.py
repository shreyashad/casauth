import requests
from django.conf import settings
from django.db import models
from rest_framework.exceptions import ValidationError
from datetime import timedelta, date, datetime
from accounts.models import BaseModel
from course_management.models import Course



# Create your models here.

class TrainingModes(BaseModel):
    MODE_CHOICES = (
        ('self_learning', 'Self-learning'),
        ('offline', 'Classroom-based (Offline)'),
        ('online', 'Live-session (Online)'),
    )
    name = models.CharField(max_length=50,choices=MODE_CHOICES, unique=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = "Training Mode"
        verbose_name_plural = "Training Modes"

    def __str__(self):
        return self.name



class TrainingRoom(BaseModel):
    name = models.CharField(max_length=100)
    capacity = models.PositiveIntegerField(default=0)
    description = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = "Training Room"
        verbose_name_plural = "Training Rooms"

    def __str__(self):
        return self.name

class Trainer(BaseModel):
    user = models.UUIDField(unique=True, help_text="User ID of the trainer")
    expertise = models.TextField(help_text="Trainer's area of expertise", blank=True, null=True)
    availability = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Trainer"
        verbose_name_plural = "Trainers"

    def __str__(self):
        return f"Trainer - {self.user_id}"

    def fetch_trainer_details(self):
        """Fetch trainer details from CAS using the user_id."""
        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}api/user-details/{self.user_id}/"
            )
            if response.status_code == 200:
                return response.json()  # Assuming CAS returns a JSON response
            else:
                raise ValueError(f"Failed to fetch trainer details: {response.json().get('error')}")
        except Exception as e:
            raise ValueError(f"Error fetching trainer details: {str(e)}")


class TrainingRequest(BaseModel):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="training_requests")
    team = models.UUIDField(help_text="Team ID of the team requesting the training")
    requester = models.UUIDField(help_text="User ID of the person requesting the training")
    receiver = models.UUIDField(help_text="User ID of the person to receive the training")
    preferred_mode = models.CharField(max_length=20, choices=[('online', 'Online'), ('offline', 'Offline')], default='online')
    employees = models.TextField(help_text="List of employee IDs involved in the training")
    additional_notes = models.TextField(blank=True, null=True, help_text="Additional response notes")

    class Meta:
        verbose_name = "Training Request"
        verbose_name_plural = "Training Requests"

    def get_employee_list(self):
        return self.employees.split(",")


    def __str__(self):
        return f"Training Request for {self.course.title} by {self.requester.username}"


class TrainingSchedule(BaseModel):
    training_request = models.ForeignKey(TrainingRequest, on_delete=models.SET_NULL,null=True,blank=True, related_name="scheduled_session", help_text="Training Request ID")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="scheduled_session", help_text="Course ID")
    preferred_mode = models.ForeignKey(TrainingModes, on_delete=models.CASCADE, related_name="scheduled_session", help_text="Training Mode")
    employees = models.TextField(help_text="List of employee IDs involved in the training")
    trainers = models.ForeignKey(Trainer, on_delete=models.SET_NULL, null=True, blank=True, help_text="Trainer ID")
    room = models.ForeignKey(TrainingRoom, on_delete=models.SET_NULL, null=True, blank=True, help_text="Training Room ID")
    online_link = models.URLField(null=True, blank=True, help_text="Online link for the training")
    scheduled_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    duration_hours = models.PositiveIntegerField(blank=True, null=True, help_text="Duration of the training in hours")
    additional_notes = models.TextField(blank=True, null=True, help_text="Additional response notes")

    def fetch_user_data(self, user_ids):
        """ Fetch users details from CAS for the given user ID """
        if not user_ids:
            return []
        user_details = []
        for user_id in user_ids:
            try:
                response = requests.get(f"{settings.AUTH_SERVER_BASE_URL}api/user-details/{self.user_id}/", data={'user_id': user_id})
                if response.status_code == 200:
                    user_details.append(response.json())
                else:
                    raise ValueError(f"Failed to fetch user details: {response.json().get('error')}")
            except Exception as e:
                raise ValueError(f"Error fetching user details: {str(e)}")
        return user_details

    def get_employees(self):
        employee_ids =[emp_id.strip() for emp_id in self.employees.split(",")]
        return self.fetch_user_data(employee_ids)



    def clean(self):
        if self.preferred_mode.name == 'online' and not self.online_link:
            raise ValidationError('Online link is required for online training')
        if self.preferred_mode != 'online' and self.online_link:
            raise ValidationError("Online link should be left blank for offline/self-learning training.")

        if not self.duration_hours and not self.start_time and not self.end_time:
            self.duration_hours = (datetime.combine(date.today(), self.end_time) - datetime.combine(date.today(),
                                                                                                    self.start_time)).seconds / 3600
        return super().clean()

    class Meta:
        verbose_name = "Training Schedule"
        verbose_name_plural = "Training Schedules"