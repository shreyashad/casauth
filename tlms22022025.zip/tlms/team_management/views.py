from django.shortcuts import render

# Create your views here.


# tlms/team_management/views.py
from .serializers import TeamCreateSerializer
import requests
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.exceptions import ValidationError

CAS_BASE_URL = 'http://cas-system-url/api/'  # The base URL of your CAS API


class CreateTeamView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        # Step 1: Validate input using the serializer
        serializer = TeamCreateSerializer(data=request.data)
        if serializer.is_valid():
            team_name = serializer.validated_data.get('name')
            description = serializer.validated_data.get('description', '')

            # Step 2: Prepare data to send to CAS API
            team_data = {
                "name": team_name,
                "description": description,
            }

            jwt_token = request.headers.get('Authorization')
            if not jwt_token:
                raise ValidationError({"error": "JWT token is required"})

            headers = {
                "Authorization": jwt_token,
                "Content-Type": "application/json",
                "X-Application-Name": "TLMS",
            }

            # Step 3: Communicate with the CAS system
            try:
                response = requests.post(
                    f'{CAS_BASE_URL}create-teams/',
                    json=team_data,
                    headers=headers
                )

                if response.status_code == 201:
                    return Response(response.json(), status=status.HTTP_201_CREATED)
                else:
                    return Response(response.json(), status=response.status_code)

            except requests.exceptions.RequestException as e:
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
