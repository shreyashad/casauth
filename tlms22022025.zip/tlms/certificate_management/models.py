import random
import string
from django.utils import timezone

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models

from accounts.models import BaseModel


# Create your models here.
def generate_certificate_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

def generate_unique_certificate_code():
    code = generate_certificate_code()  # Generate a new code
    while Certificate.objects.filter(code=code).exists():  # Check if it already exists in the database
        code = generate_certificate_code()  # Keep generating until a unique code is found
    return code



class CertificateType(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'Certificate Type'
        verbose_name_plural = 'Certificate Types'

    def __str__(self):
        return self.name





class Certificate(BaseModel):
    title = models.CharField(max_length=255, unique=True)
    description = models.TextField(null=True, blank=True, help_text="Description of the certificate")
    issued_to = models.UUIDField(null=True, blank=True, help_text="User ID of the person who received the certificate")
    issue_date = models.DateTimeField(default=timezone.now)
    certificate_code = models.CharField(max_length=255, unique=True, default=generate_unique_certificate_code,
                                        help_text="Unique code for the certificate"
                                        )
    certificate_type = models.ForeignKey(CertificateType, on_delete=models.CASCADE)
    criteria_value = models.JSONField(default=dict)  # Store specific criteria for issuing the certificate
    is_generated = models.BooleanField(default=False)  # To track if the certificate has been generated

    # Generic relation to allow linking the certificate to any model (Course, Module, Badge, etc.)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')


    class Meta:
        verbose_name = "Certificate"
        verbose_name_plural = "Certificates"
        ordering = ['issue_date']

    def __str__(self):
        return f"Certificate for {self.title} - {self.certificate_code}"


#
# class CertificateIssuance(models.Model):
#     user = models.UUIDField(null=True, blank=True, help_text="User ID of the person who received the certificate")
#     certificate = models.ForeignKey(Certificate, on_delete=models.CASCADE, related_name='issuances')
#     issued_on = models.DateTimeField(auto_now_add=True)
#     issue_status = models.CharField(max_length=50, choices=[('pending', 'Pending'), ('issued', 'Issued')], default='pending')
#     issued_by = models.UUIDField(null=True, blank=True, help_text="User ID of the person who issued the certificate")
#
#     class Meta:
#         verbose_name = "Certificate Issuance"
#         verbose_name_plural = "Certificate Issuances"
#         unique_together = ['user', 'certificate']
#
#     def __str__(self):
#         return f"Certificate {self.certificate.title} issued to {self.user.username} on {self.issued_on}"
#
#     def mark_as_issued(self):
#         self.issue_status = 'issued'
#         self.save()


class CertificateTemplate(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(null=True, blank=True)
    template_file = models.FileField(upload_to='certificate_templates/', null=True, blank=True)

    class Meta:
        verbose_name = "Certificate Template"
        verbose_name_plural = "Certificate Templates"

    def __str__(self):
        return self.name


class CertificateVerification(BaseModel):
    certificate = models.ForeignKey(Certificate, on_delete=models.CASCADE, related_name='validations')
    is_verified = models.BooleanField(default=False)
    class Meta:
        verbose_name = "Certificate Verification"
        verbose_name_plural = "Certificate Verifications"

    def __str__(self):
        return f"{'Verified' if self.is_verified else 'Not Verified'} for {self.certificate.title}"




class CertificateProgress(BaseModel):
    user = models.UUIDField(null=True, blank=True, help_text="User ID of the person who received the certificate")
    progress_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.0, help_text="Progress percentage")
    eligible_for_certificate = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Certificate Progress"
        verbose_name_plural = "Certificate Progresses"

    def __str__(self):
        return f"{self.user.username} - Progress"

    def check_eligibility(self):
        # Method to check if the user qualifies for a certificate based on progress
        if self.progress_percentage >= 80:
            self.eligible_for_certificate = True
        else:
            self.eligible_for_certificate = False
        self.save()


class CertificateRequest(BaseModel):
    user = models.UUIDField(null=True, blank=True, help_text="User ID of the person requesting the certificate")
    request_date = models.DateTimeField(auto_now_add=True)
    request_status = models.CharField(max_length=50, choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')], default='pending')
    certificate_type = models.ForeignKey(CertificateType, on_delete=models.CASCADE)
    class Meta:
        verbose_name = "Certificate Request"
        verbose_name_plural = "Certificate Requests"

    def __str__(self):
        return f"Certificate request by {self.user.username} on {self.request_date}"

    def approve_request(self):
        self.request_status = 'approved'
        self.save()

    def reject_request(self):
        self.request_status = 'rejected'
        self.save()



class BadgeCategory(BaseModel):
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name



class Badge(BaseModel):
    CRITERIA_CHOICES = [
        ('COMPLETION', 'Completion-Based'),
        ('PERFORMANCE', 'Performance-Based'),
        ('ENGAGEMENT', 'Engagement-Based'),
        ('CUSTOM', 'Custom Criteria'),
    ]
    name = models.CharField(max_length=255, unique=True)  # Badge name (e.g., "Expert Python Developer")
    description = models.TextField(null=True, blank=True)  # Description of what the badge represents
    image = models.ImageField(upload_to='badges_images/', null=True, blank=True)  # Optional: Image to represent the badge
    criteria_type = models.CharField(
        max_length=50,
        choices=CRITERIA_CHOICES,
        default='COMPLETION',
        help_text="Type of criteria required to earn the badge"
    )
    criteria = models.JSONField(
        default=dict,
        help_text="Specific criteria details, stored as JSON (e.g., course_id, score thresholds)"
    )
    awarded_at = models.DateTimeField(auto_now_add=True)  # Timestamp when the badge was created

    class Meta:
        verbose_name = 'Badge'
        verbose_name_plural = 'Badges'

    def __str__(self):
        return self.name

class UserBadge(BaseModel):
    user = models.UUIDField(help_text="User ID of the person who received the badge")
    badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
    awarded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'User Badge'
        verbose_name_plural = 'User Badges'
        unique_together = ['user', 'badge']

    def __str__(self):
        return f"User {self.user} awarded {self.badge.name}"
