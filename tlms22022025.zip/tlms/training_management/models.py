from datetime import timezone

from django.db import models

from accounts.models import BaseModel
from training_planner.models import TrainingSchedule, Trainer, TrainingModes


# Create your models here.



class TrainingPlan(BaseModel):
    schedule_training = models.ForeignKey(TrainingSchedule, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE)
    # Trainer assigned to this plan


class TrainingSession(BaseModel):
    training_schedule = models.ForeignKey(TrainingSchedule, on_delete=models.CASCADE, related_name="training_sessions_schedule",
                                          help_text="Training Schedule associated with this session")
    training_plan = models.ForeignKey(TrainingSchedule, on_delete=models.CASCADE, related_name="training_sessions_plan")
    training_mode = models.ForeignKey(TrainingModes, on_delete=models.DO_NOTHING, related_name="training_sessions")
    start_time = models.DateTimeField()
    location = models.CharField(max_length=200, blank=True,
                                null=True)  # Used for offline location or online meeting link
    additional_notes = models.TextField(blank=True, null=True)
    attendance_marked = models.BooleanField(default=False,
                                            help_text="Whether attendance has been marked for this session")
    attendance_open = models.BooleanField(default=False)  # Indicates if attendance marking is open
    attendance_start_time = models.DateTimeField(null=True, blank=True)  # The time when attendance marking starts
    attendance_end_time = models.DateTimeField(null=True, blank=True)  # The time when attendance marking ends

    def __str__(self):
        return f"{self.schedule.request.course.name} - {self.start_time}"

    # Method to check if session is online or offline
    def is_online(self):
        return self.training_mode.name == self.ONLINE

    def is_offline(self):
        return self.training_mode.name == self.OFFLINE

    def open_attendance(self):
        """Method to toggle attendance availability."""
        self.attendance_open = True
        self.attendance_start_time = timezone.now()
        self.attendance_end_time = self.attendance_start_time + timezone.timedelta(minutes=15)  # 15 minutes window
        self.save()

    def close_attendance(self):
        """Method to close attendance marking."""
        self.attendance_open = False
        self.save()

    def is_attendance_open(self):
        """Check if attendance can still be marked."""
        if self.attendance_open and timezone.now() <= self.attendance_end_time:
            return True
        return False

class AttendanceRecord(BaseModel):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE, related_name="attendances")
    participant = models.UUIDField(help_text="Employee attending the training")
    attendance_time = models.DateTimeField(null=True, blank=True)
    departure_time = models.DateTimeField(null=True, blank=True)
    is_present = models.BooleanField(default=False)
    late_arrival = models.BooleanField(default=False)
    toggled_by_trainer = models.BooleanField(default=False)  # Indicates if attendance was toggled by the trainer

    def mark_attendance(self, attendance_time):
        """Mark the attendance if allowed by the session's rules."""
        if self.session.is_attendance_open():  # Ensure that attendance can be marked
            self.attendance_time = attendance_time
            self.toggled_by_trainer = True
            self.save()
            return True  # Successfully marked attendance
        return False  # Attendance cannot be marked due to session rules

    def mark_departure(self, departure_time):
        """Mark the departure time of the participant."""
        self.departure_time = departure_time
        self.save()


class TrainingExecution(BaseModel):
    training_session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE, related_name="executions",
                                         help_text="Training Session for which execution details are tracked")
    execution_start_time = models.DateTimeField(help_text="When the session execution started")
    execution_end_time = models.DateTimeField(help_text="When the session execution ended")
    execution_status = models.CharField(max_length=50, choices=[('in_progress', 'In Progress'), ('completed', 'Completed')],
                              default='in_progress', help_text="Status of the execution")
    breaks = models.TextField(blank=True, null=True,
                              help_text="List of breaks during the session, stored as a comma-separated list with time intervals")
    total_break_time = models.DurationField(help_text="Total break time taken during the session")
    additional_notes = models.TextField(blank=True, null=True,
                                        help_text="Additional notes related to the training execution")

    class Meta:
        verbose_name = "Training Execution"
        verbose_name_plural = "Training Executions"

    def __str__(self):
        return f"Execution of session for {self.training_session.course.title} on {self.training_session.session_date}"


class Break(BaseModel):
    training_execution = models.ForeignKey(TrainingExecution, on_delete=models.CASCADE, related_name="execution_breaks",
                                           help_text="Training Execution for which the break is being recorded")
    break_start_time = models.DateTimeField(help_text="Start time of the break")
    break_end_time = models.DateTimeField(help_text="End time of the break")
    break_duration = models.DurationField(help_text="Duration of the break")
    reason = models.CharField(max_length=255, help_text="Reason for the break (optional)")

    class Meta:
        verbose_name = "Break"
        verbose_name_plural = "Breaks"

    def __str__(self):
        return f"Break from {self.break_start_time} to {self.break_end_time}"
