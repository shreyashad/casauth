
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated,AllowAny
from rest_framework_simplejwt.authentication import JWTAuthentication
from .serializers import *


class OrganizationListCreateAPIView(generics.ListCreateAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)


class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class OrganizationSubTypeListCreateAPIView(generics.ListCreateAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    # permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class LocationsListCreateAPIView(generics.ListCreateAPIView):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    # permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class LocationsRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)



class DepartmentListCreateAPIView(generics.ListCreateAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    # permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class DepartmentListAPIView(generics.ListAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    # permission_classes = [AllowAny]



class DepartmentRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class DesignationListCreateAPIView(generics.ListCreateAPIView):
    queryset = Designation.objects.all()
    serializer_class = DepartmentSerializer
    # permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



class DesignationListAPIView(generics.ListAPIView):
    queryset = Designation.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [AllowAny]




class DesignationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Designation.objects.all()
    serializer_class = DepartmentSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)




class OrgTypeListView(APIView):
    def get(self, request, *args, **kwargs):
        org_types = Organization.objects.values_list('org_type', flat=True).distinct()
        return Response(org_types, status=status.HTTP_200_OK)


class OrgNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            organizations = Organization.objects.filter(org_type=org_type)
        else:
            organizations = Organization.objects.all()
        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)


class OrgSubTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            org_sub_types = OrganizationSubType.objects.filter(org_type=org_type)
        else:
            org_sub_types = OrganizationSubType.objects.all()
        serializer = OrgSubTypeSerializer(org_sub_types, many=True)
        return Response(serializer.data)

class LocationTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        if org_name:
            location_type = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
        else:
            location_type = Locations.objects.values_list('location_type', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)


class LocationNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')
        if org_name and location_type:
            location_type = Locations.objects.filter(org_name=org_name, location_type=location_type)
        else:
            location_type = Locations.objects.filter(org_name=org_name)

        return Response(location_type, status=status.HTTP_200_OK)


class LocationCodeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')
        location_name = request.query_params.get('location_name')

        if org_name and location_type and location_name:
            location_type = Locations.objects.filter(org_name=org_name, location_type=location_type, location_name=location_name).values_list('location_code', flat=True).distinct()
        else:
            location_type = Locations.objects.filter(org_name=org_name,location_name=location_name).values_list('location_code', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)



