from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated

# Create your views here.


class AuditLogListView(generics.ListAPIView):
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        """
               Optionally filter logs based on request parameters (e.g., by user, application, or action type).
               """
        queryset = AuditLogEntry.objects.all()

        # Filtering by user
        user = self.request.query_params.get('user')
        if user:
            queryset = queryset.filter(user__username=user)

        # Filtering by application
        application = self.request.query_params.get('application')
        if application:
            queryset = queryset.filter(application__name=application)

        # Filtering by action type
        action_type = self.request.query_params.get('action_type')
        if action_type:
            queryset = queryset.filter(action_type=action_type)

        return queryset


class AuditLogDetailView(generics.RetrieveAPIView):
    queryset = AuditLogEntry.objects.all()
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]
