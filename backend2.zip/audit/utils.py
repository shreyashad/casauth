from django.utils import timezone
from .models import *



def log_audit_entry(user, application, action_type, object_id, object_type=None, details=None):
    """
    Helper function to create an audit log entry.
    """
    if object_type is None:
        object_type = ContentType.objects.get_for_model(type(object_id))

    audit_log = AuditLogEntry.objects.create(
        user=user,
        application=application,
        action_type=action_type,
        object_id=str(object_id),
        object_type=object_type,
        details=details,
    )
    return audit_log


def update_user_application_status(user, application, is_online):
    """
    Helper function to update user application status.
    """
    status, created = UserApplicationStatus.objects.update_or_create(
        user=user,
        application=application,
        defaults={
            'is_online': is_online,
            'last_active': timezone.now(),
        }
    )
    return status
