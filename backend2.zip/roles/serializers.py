from rest_framework import serializers
from .models import Application, Permission, Role, UserRole
from accounts.models import CustomUser


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [ 'username']  # Adjust fields as needed


class ApplicationSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)

    class Meta:
        model = Application
        fields = ['id', 'name', 'description', 'base_url', 'active', 'created_at', 'updated_at', 'created_by',
                  'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)


class PermissionSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    application = ApplicationSerializer(read_only=True)

    class Meta:
        model = Permission
        fields = ['id', 'name', 'description', 'application',  'created_at',
                  'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)

class RoleSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    application = ApplicationSerializer(read_only=True)
    permissions = PermissionSerializer(many=True, read_only=True)

    class Meta:
        model = Role
        fields = ['id', 'name', 'description', 'application', 'permissions', 'created_at', 'updated_at', 'created_by',
                  'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)



class UserRoleSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    role = RoleSerializer(read_only=True)
    application = ApplicationSerializer(read_only=True)

    class Meta:
        model = UserRole
        fields = ['id', 'user', 'role', 'application', 'can_create', 'can_read', 'can_update', 'can_delete',
                  'created_at', 'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)
