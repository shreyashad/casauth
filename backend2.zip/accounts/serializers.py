from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import *
from django.contrib.auth.hashers import make_password

class CustomUserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})



    class Meta:
        model = CustomUser
        fields = [
            'first_name', 'last_name', 'emp_code', 'designation','department', 'org_type',
            'org_name', 'org_sub_type', 'assigned_details', 'location_type', 'location_name', 'location_code',
            'username', 'password', 'confirm_password','mobile'
        ]

    def validate(self, data):
        if data['password'] !=data['confirm_password']:
            raise serializers.ValidationError("Password do not match")
        if CustomUser.objects.filter(username=data['username']).exists():
            raise serializers.ValidationError({"username": "This username is already taken."})
        if CustomUser.objects.filter(mobile=data['mobile']).exists():
            raise serializers.ValidationError({"mobile": "This mobile number is already registered."})
        if CustomUser.objects.filter(emp_code=data['emp_code']).exists():
            raise serializers.ValidationError({"emp_code": "This employee code is already in use."})

        return data

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        raw_password = validated_data.pop('password')
        hashed_password = make_password(raw_password)

        user = CustomUser.objects.create(
            **validated_data,
            password=hashed_password,
            last_password_change=timezone.now(),
            password_history_json=json.dumps([hashed_password])
        )
        user.save()
        return user



class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'id', 'first_name', 'last_name', 'org_type', 'org_name',
            'org_sub_type', 'location_type', 'location_name', 'location_code',
            'emp_code', 'department', 'designation', 'mobile', 'username',
            'password', 'assigned_details', 'is_online', 'is_staff', 'is_verified',

        ]

        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user

    def update(self, instance, validated_data):
        if 'password' in validated_data:
            password = validated_data.pop('password')
            instance.set_password(password)
        return super().update(instance, validated_data)

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = [
            'id', 'user', 'address', 'city', 'state', 'country', 'postal_code',
            'phone_number', 'date_of_birth', 'profile_picture', 'bio'
        ]





class ChangePasswordSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    mobile = serializers.CharField(max_length=20)
    new_password = serializers.CharField(write_only=True, style={'input_type': 'password'})
    old_password = serializers.CharField(write_only=True, style={'input_type': 'password'})





class ChangePasswordUserSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate(self, data):
        user = self.context['request'].user
        old_password = data.get('old_password')
        new_password = data.get('new_password')

        if not user.check_password(old_password):
            raise serializers.ValidationError("Old password is incorrect.")
        if old_password == new_password:
            raise serializers.ValidationError("New password must be different from the old password.")

        if user.is_password_in_history(new_password):
            raise serializers.ValidationError("New password cannot be the same as any of the last 3 passwords.")

        return data

    def save(self):
        user = self.context['request'].user
        new_password = self.validated_data['new_password']
        user.set_password(new_password)
        user.save()



class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'is_administrator', 'is_authenticator', 'is_site_admin']




class AuthenticatorFilterSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthenticatorFilterSettings
        fields = [
            'filter_org_type', 'filter_org_name', 'filter_org_sub_type',
            'filter_location_type', 'filter_location_name', 'filter_department'
        ]
