# from django.shortcuts import render
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from rest_framework_simplejwt.tokens import RefreshToken
# from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
# from django.contrib.auth import authenticate
# from .serializers import *
#
# # Create your views here.
#
#
# # class CustomTokenObtainPairView(TokenObtainPairView):
# #
# #     def post(self, request, *args, **kwargs):
# #         username = request.data.get('username')
# #         password = request.data.get('password')
# #
# #         user = authenticate(request, username=username, password=password)
# #
# #         if user:
# #             if not user.is_active:
# #                 return Response({'error': 'User account is disabled'}, status=status.HTTP_401_UNAUTHORIZED)
# #
# #             if not user.is_verified:
# #                 return Response({'error': 'User account is not verified'}, status=status.HTTP_401_UNAUTHORIZED)
# #
# #             refresh = RefreshToken.for_user(user)
# #             token = {
# #                 'refresh': str(refresh),
# #                 'access': str(refresh.access_token),
# #             }
# #             return Response(token, status=status.HTTP_200_OK)
# #         else:
# #             return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
#
#
# """added this part to cas app views."""
# #
# # class LoginAPIView(APIView):
# #     serializer_class = LoginSerializer
# #
# #     def post(self, request, *args, **kwargs):
# #         serializer = self.serializer_class(data=request.data)
# #         serializer.is_valid(raise_exception=True)
# #         user = serializer.validated_data['user']
# #         log_audit_entry(user, Application.objects.get(name='Your CAS Application'), 'Login', user.id, 'User login')
# #
# #         refresh = RefreshToken.for_user(user)
# #         token = {
# #             'refresh': str(refresh),
# #             'access': str(refresh.access_token),
# #         }
# #
# #         return Response(token, status=status.HTTP_200_OK)
# #
# # class CustomTokenRefreshView(TokenRefreshView):
# #     pass
#
#
#
# # class RegistrationView(APIView):
# #     def get(self, request, *args, **kwargs):
# #         return Response({"message": "Please register user using POST method."}, status=status.HTTP_200_OK)
# #
# #     def post(self, request, *args, **kwargs):
# #         serializer = CustomUserRegistrationSerializer(data=request.data)
# #         if serializer.is_valid():
# #             user = serializer.save()
# #
# #             try:
# #                 application = Application.objects.get(name='Your CAS Application')
# #             except Application.DoesNotExist:
# #                 return Response({"message": "Application not found."}, status=status.HTTP_404_NOT_FOUND)
# #
# #             create_admin_notification(user)
# #
# #             log_audit_entry(request.user, application.objects.get(name='Your CAS Application'), 'Create', user.id,
# #                             'User registration')
# #             return Response({"message": "Registration successful"}, status=status.HTTP_201_CREATED)
# #         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#
#
# class RegistrationView(APIView):
#     def post(self, request, *args, **kwargs):
#         serializer = CustomUserRegistrationSerializer(data=request.data)
#         if serializer.is_valid():
#             user = serializer.save()
#             return Response({"message": "Registration successful"}, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)


    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        if username and password:
            user = authenticate(username=username, password=password)

            if user:
                if not user.is_active:
                    raise serializers.ValidationError("User account is disabled.")
                if not user.is_verified:
                    raise serializers.ValidationError("User is not verified.")

                data['user'] = user
            else:
                raise serializers.ValidationError("Unable to log in with provided credentials.")
        else:
            raise serializers.ValidationError("Must include 'username' and 'password'.")

        return data
# accounts/views.py
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from accounts.serializers import UserRegistrationSerializer
from accounts.models import CustomUser
from notifications.models import Notification

class UserRegistrationView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            self.send_notification_to_admins(user)
            return Response({'detail': 'User registered successfully.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def send_notification_to_admins(self, user):
        admin_users = CustomUser.objects.filter(is_administrator=True)
        for admin in admin_users:
            Notification.objects.create(
                user=admin,
                application=None,  # Adjust based on your application model
                title='New User Registered',
                message=f'A new user {user.username} has been registered.',
                notification_type='info'
            )
----------------------------------------------------
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class UserListView(generics.ListCreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return super().get_queryset()


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return super().get_object()


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class UserCreateView(generics.CreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        serializer.save()


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class UserUpdateView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return super().get_object()


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class UserDeleteView(generics.DestroyAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return super().get_object()


from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from django.contrib.auth.forms import SetPasswordForm
from .models import CustomUser


class ChangePasswordView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        form = SetPasswordForm(user, data=request.data)
        if form.is_valid():
            form.save()
            return Response({'status': 'password set'}, status=status.HTTP_200_OK)
        return Response(form.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class ListAdministratorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_administrator=True)


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class ListAuthenticatorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_authenticator=True)


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from .models import CustomUser
from .serializers import CustomUserSerializer

class ListSiteAdminsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_site_admin=True)


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from .models import CustomUser
from .serializers import CustomUserSerializer


class AssignRolesView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        serializer = self.get_serializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from .models import CustomUser


class RevokeRolesView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        user.is_administrator = False
        user.is_authenticator = False
        user.is_site_admin = False
        user.save()
        return Response({'status': 'roles revoked'})


from rest_framework import serializers
from .models import CustomUser, UserProfile

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'id', 'first_name', 'last_name', 'org_type', 'org_name',
            'org_sub_type', 'location_type', 'location_name', 'location_code',
            'emp_code', 'department', 'designation', 'mobile', 'username',
            'password', 'assigned_details', 'is_online', 'is_staff', 'is_verified',
            'is_authenticator', 'is_site_admin', 'is_administrator', 'last_password_change',
            'password_change_required', 'password_history_json'
        ]
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user

    def update(self, instance, validated_data):
        if 'password' in validated_data:
            password = validated_data.pop('password')
            instance.set_password(password)
        return super().update(instance, validated_data)

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = [
            'id', 'user', 'address', 'city', 'state', 'country', 'postal_code',
            'phone_number', 'date_of_birth', 'profile_picture', 'bio'
        ]


from rest_framework import serializers
from django.contrib.auth.forms import SetPasswordForm


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate(self, data):
        user = self.context['request'].user
        old_password = data.get('old_password')
        new_password = data.get('new_password')

        if not user.check_password(old_password):
            raise serializers.ValidationError("Old password is incorrect.")
        if old_password == new_password:
            raise serializers.ValidationError("New password must be different from the old password.")

        if user.is_password_in_history(new_password):
            raise serializers.ValidationError("New password cannot be the same as any of the last 3 passwords.")

        return data

    def save(self):
        user = self.context['request'].user
        new_password = self.validated_data['new_password']
        user.set_password(new_password)
        user.save()


from rest_framework import serializers
from .models import CustomUser

class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'is_administrator', 'is_authenticator', 'is_site_admin']
-----------------------------

from django.utils import timezone
from django.contrib.auth.hashers import make_password, check_password
from django.core.exceptions import ValidationError
import json
import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin


class CustomUserManager(BaseUserManager):
    def create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError('The Username must be set')
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(username, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(
        default=uuid.uuid4, unique=True, editable=False, db_index=True, primary_key=True
    )
    username = models.CharField(max_length=150, unique=True)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    # Other fields as necessary...
    mobile = models.CharField(max_length=20, unique=True)  # For simplicity, assume phone numbers are in string format
    password = models.CharField(max_length=128)
    last_password_change = models.DateTimeField(null=True, blank=True)
    password_change_required = models.BooleanField(default=False)
    password_history_json = models.TextField(default='[]')

    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['mobile']

    def is_password_expired(self):
        if not self.last_password_change:
            return False
        return (timezone.now() - self.last_password_change).days >= 30

    def is_password_in_history(self, raw_password):
        password_history = json.loads(self.password_history_json)
        for hashed_password in password_history:
            if check_password(raw_password, hashed_password):
                return True
        return False

    def set_password(self, raw_password):
        if self.is_password_in_history(raw_password):
            raise ValidationError("The new password cannot be the same as any of the last 3 passwords.")

        # Set the new password and update history
        hashed_password = make_password(raw_password)
        super().set_password(raw_password)

        # Update password history
        password_history = json.loads(self.password_history_json)
        password_history.append(hashed_password)
        if len(password_history) > 3:
            password_history.pop(0)
        self.password_history_json = json.dumps(password_history)

        # Update the last password change time
        self.last_password_change = timezone.now()
        self.password_change_required = self.is_password_expired()
        super().save()

    def save(self, *args, **kwargs):
        if self.password_change_required and not self.is_password_expired():
            self.password_change_required = False
        super().save(*args, **kwargs)


-----------------


@property
def password_history(self):
    return json.loads(self.password_history_json)


@password_history.setter
def password_history(self, value):
    self.password_history_json = json.dumps(value)

    def set_password(self, raw_password):
        if self.is_password_in_history(raw_password):
            raise ValidationError("The new password cannot be the same as any of the last 3 password.")

        hashed_password = make_password(raw_password)
        super().set_password(raw_password)
        self.last_password_change = timezone.now()
        password_history = self.password_history
        password_history.append(self.password)
        if len(self.password_history) > 3:
            password_history.pop(0)
        self.password_history = password_history

    def save(self, *args, **kwargs):
        if self.password_change_required and not self.is_password_expired():
            self.password_change_required = False
        super().save(*args, **kwargs)

