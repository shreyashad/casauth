"use client";
import { LogOut } from "lucide-react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { UserAvatar } from "./user-avatar";
import { signOut, useSession } from "next-auth/react";
import { Loading } from "../dashboard/loading";



export default function UserNav() {
   const { data: session, status } = useSession();

   if (status === 'loading ') {
    return <Loading />;
   }

   if (!session || !session.user) {
    return <div>No user data available</div>;
  }


    return(
        <DropdownMenu>
            <DropdownMenuTrigger>
                <UserAvatar
                    user={{ name: session.user.first_name || null, image: session.user.profile_picture || null}}
                />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                <div className="flex flex-col space-y-1 leading-none">
                        {session.user && <p className="font-medium">{session.user.first_name}</p>}
                        {session.user.username && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {session.user.username}
                            </p>
                        )}
                    </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={async () =>{
                            await signOut();
                        }}
                    >
                        <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                        Log Out
                    </Button>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}