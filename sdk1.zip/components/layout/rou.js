import { LogOut } from "lucide-react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { auth, signOut } from "@/auth";


export default async function UserNav() {
    const session = await auth()
    return (
        <DropdownMenu>
            <DropdownMenuTrigger>

            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                        {session.user.user.first_name && <p className="font-medium">{session.user.user.firts_name}</p>}
                        {user.email && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {session.user.user.email}
                            </p>
                        )}
                    </div>
                </div>
            </DropdownMenuContent>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
                <form
                    action={async () => {
                   
                    await signOut()
                    }}
                >
                <Button>
                    <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                    Log Out
                </Button>
                </form>
            </DropdownMenuItem>
        </DropdownMenu>
    )
}
----------------------------
"use client";

import { useSidebar } from "@/hooks/useSidebar";
import { useState } from "react";
import { DashboardMenuConfig } from "./sidebar-menu-list";
import { cn } from "@/lib/utils";
import { BsArrowLeftShort } from "react-icons/bs";
import SideNav from "./side-nav";

export default function Sidebar({ dashboardType, className }) {
    const { isOpen, toggle } = useSidebar();
    const [status, setStatus] = useState(false);

    const handleToggle = () => {
        setStatus(true);
        toggle();
        setTimeout(() => setStatus(false), 500);
    };

    const menuItems = DashboardMenuConfig[dashboardType] || [];

    return (
        <nav
            className={cn(
                `relative hidden h-screen border-r pt-20 md:flex flex-col`,
                status && "duration-500",
                isOpen ? "w-72" : "w-[78px]",
                className
            )}
        >
            <BsArrowLeftShort
                className={cn(
                    "absolute -right-3 top-20 cursor-pointer rounded-full border bg-background text-3xl text-foreground",
                    !isOpen && "rotate-180"
                )}
                onClick={handleToggle}
            />
            <div className="flex-1 overflow-y-auto">
                <div className="px-3 py-2">
                    <div className="mt-3 space-y-1">
                        <SideNav
                            className="text-background opacity-0 transition-all duration-300 group-hover:z-50 group-hover:ml-4 group-hover:rounded group-hover:bg-foreground group-hover:p-2 group-hover:opacity-100"
                            items={menuItems}
                        />
                    </div>
                </div>
            </div>
        </nav>
    );
}
