import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { fetchApplicationdetails, validateTicket } from "./app/api/server/route";
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";

export const {handlers, signIn, signOut, auth} = NextAuth({
    providers: [
        CredentialsProvider({
            name: "CAS",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                try {
                    const application = await fetchApplicationdetails();
                    const applicationId = application.app.id;

                    const response = await axios.post(`${API_BASE_URL}api/login/`, {
                        username: credentials.username,
                        password: credentials.password,
                        application_id: applicationId,
                    });

                    if (response.status !== 200) {
                        throw new Error("Invalid credentials or application issue");
                    }

                    const user = response.data;

                    const userDetails = await validateTicket(user.service_ticket, applicationId);
                    if (userDetails) {
                        return {
                            id: userDetails.id || user.id,
                            accessToken: user.access_token,
                            refreshToken: user.refresh_token,
                            roles: userDetails.data.roles,
                            permissions: userDetails.data.permissions,
                        };
                    } else {
                        throw new Error("Invalid service ticket");
                    }
                } catch (error) {
                    console.error('Authentication failed:', error.response || error.message);
                    return null;
                }
            }
        })
    ],
    pages: {
        signIn: '/login',
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.roles = user.roles;
                token.permissions = user.permissions;
                token.user = user;
            }
            return token;
        },

        async session({ session, token }) {
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.roles = token.roles;
            session.permissions = token.permissions;
            session.user = token.user;

            return session;
        }
    },
    session: { strategy: 'jwt' },
});
