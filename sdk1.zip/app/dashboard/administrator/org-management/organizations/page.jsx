import { fetchOrganizationListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import OrganizationClient from "@/components/admin/organization/org-client";
import { OrgColumns } from "@/components/admin/organization/org-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function OrganizationManagement() {
    const session = await auth();
    console.log("sesiion deatisl:" ,session.accessToken);
    
    const orgdata = await fetchOrganizationListData(session.accessToken, session.refreshToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/org-management/"
                mdipagetitle="Organization Management"
                pagetitle="Organization"
            />
            
            <OrganizationClient />
            <Separator />
            <div>
                <DataTable columns={OrgColumns} data={orgdata} />
            </div>
        </div>
    );
}
