import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || '';

// Function to refresh access token
export async function refreshAccessToken(refreshToken) {
  try {
    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
        refresh: refreshToken
    });
    console.log('New Access Token:', response.data.access);
    return response.data.access;
  } catch (error) {
    console.error('Error refreshing token:', error);
    throw error;
  }
};
