"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { deleteOrgSubTypeDetails } from "@/lib/administrator/org_api";
import { Pencil, Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";


export function OrgSubTypeCellAction({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/org-management/org-subtypes/${data.id}`);
    };

    const deleteOrgSubType = async () => {
        try {
            await deleteOrgSubTypeDetails(data.id, session.accessToken);
            toast.success("Organization SubType deleted successfully");
            setAlertModalOpen(false);
            router.refresh();
        } catch (error) {
            toast.error("Error deleting  Org Type");
        }
    };
    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update OrgType</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete OrgType</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <AlertModal 
                title="Are you sure?"
                description="This action cannot be undone."
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={deleteOrgSubType}
                loading={false}
            />
        </div>
    );
};