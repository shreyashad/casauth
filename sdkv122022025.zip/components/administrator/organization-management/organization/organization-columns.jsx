"use client";

import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { OrganizationCellAction } from "./organization-cell-actions";

export const OrganizationColumns = [
    {
        id: "select",
        header: ({ table }) => (
            <Checkbox
              checked={
                table.getIsAllPageRowsSelected() ||
                (table.getIsSomePageRowsSelected() && "indeterminate")
              }
              onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
              aria-label="Select all"
              className="translate-y-[2px]"
            />
          ),
          cell: ({ row }) => (
            <Checkbox
              checked={row.getIsSelected()}
              onCheckedChange={(value) => row.toggleSelected(!!value)}
              aria-label="Select row"
              className="translate-y-[2px]"
            />
          ),
          enableSorting: false,
          enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Name"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.name}</div>;
        }
    },
    {
        accessorKey: "org_type",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Organization Type"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.org_type}</div>;
        }
    },
    {
            id: "actions",
            enableSorting: false,
            cell: ({ row }) => <OrganizationCellAction data={row.original} />, 
    }
];

