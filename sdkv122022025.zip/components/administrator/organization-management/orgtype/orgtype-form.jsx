"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { createNewOrgType, updateOrgTypeDetails } from "@/lib/administrator/org_api";
import { OrgTypeFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";


export const OrgTypeForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Organization Type" : "Create Organization Type";
    const description = initialData && initialData.id ? "Edit an Organization Type" : "Create a new Organization Type";
    const toastMessage = initialData && initialData.id ? "Organization Type updated successfully" : "Organization Type created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(OrgTypeFormSchema),
        defaultValues: initialData || {
            org_type: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);


    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                const updateForm = await updateOrgTypeDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateForm);
            } else {
                const newApp = await createNewOrgType(session.accessToken, values);
                console.log("Create Response:", newApp);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/org-management/org-types`);
        } catch(error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };



    return (
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                        <FormField 
                            control={form.control}
                            name="org_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Type</FormLabel>
                                    <FormControl>
                                        <Input 
                                            {...field}
                                            placeholder="Org type"

                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};