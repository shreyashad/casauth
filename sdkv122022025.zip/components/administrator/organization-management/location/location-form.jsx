"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { createNewLocation, updateLocationDetails } from "@/lib/administrator/org_api";
import { fetchOrgNames } from "@/lib/auth/auth_api";
import { LocationFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";


export const LocationForm = ({ initialData, orgTypedata }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Organization Location" : "Create Organization Location";
    const description = initialData && initialData.id ? "Edit an Organization Location" : "Create a new Organization Location";
    const toastMessage = initialData && initialData.id ? "Organization Location updated successfully" : "Organization Location created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
    const [orgNamesData, setOrgNamesData] = useState([]);


    const form = useForm({
        resolver: zodResolver(LocationFormSchema),
        defaultValues: initialData || {
            org_type: "",
            org_name: "",
            location_type: "",
            location_name: "",
            location_code:"",
        },
    });

    const orgType = form.watch("org_type");

    useEffect(() => {
        const fetchOrganizationNames = async () => {
            if (orgType) {
                setLoading(true);
                try {
                    const orgNames = await fetchOrgNames(orgType);
                    setOrgNamesData(orgNames || []);  // Populate orgNamesData with API response
                } catch (err) {
                    toast.error("Error fetching organization names.");
                } finally {
                    setLoading(false);
                }
            }
        };
        
        console.log("orgnamds:", fetchOrganizationNames);
        fetchOrganizationNames();
    }, [orgType]);  // Trigger effect when org_type changes


    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
                const updateForm = await updateLocationDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateForm);
            } else {
                const newlocation = createNewLocation(session.accessToken, values);
                console.log("Create Response:", newlocation);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/org-management/locations`);
        } catch(error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };




    return(
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField 
                                control={form.control}
                                name="org_type"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Organization Type</FormLabel>
                                        <Select
                                            disabled={!orgTypedata?.length}  // Only disable if no data
                                            value={field.value}  // Bind to form state
                                            onValueChange={field.onChange} 
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder="Organiztion Type"
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {orgTypedata?.length > 0 ? (
                                                    orgTypedata.map((orgtype) => (
                                                        <SelectItem key={orgtype.id} value={orgtype.org_type}>
                                                            {orgtype.org_type}
                                                        </SelectItem>
                                                    ))
                                                ): (
                                                    <SelectItem disabled>
                                                        No Org Type found
                                                    </SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="org_name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Organization Name</FormLabel>
                                        <Select 
                                             disabled={loading  || !orgNamesData.length}
                                             onValueChange={field.onChange}
                                             value={field.value}
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            orgNamesData.length > 0
                                                                ? "Organization Name"
                                                                : "No organizations available"
                                                        }
                                                    
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                            {orgNamesData.length > 0 ? (
                                                orgNamesData.map((org) => (
                                                    <SelectItem key={org.id} value={org.name}>
                                                        {org.name}
                                                    </SelectItem>
                                                ))
                                            ) : (
                                                <SelectItem disabled>
                                                    No organizations found
                                                </SelectItem>
                                            )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                            control={form.control}
                            name="location_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    placeholder="Location Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="HO">HO</SelectItem>
                                            <SelectItem value="RO">RO</SelectItem>
                                            <SelectItem value="DO">DO</SelectItem>
                                            <SelectItem value="UO">UO</SelectItem>
                                            <SelectItem value="Branch">Branch</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
}