"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useRouter } from "next/navigation";


export function ApplicationCard({ id, name, base_url, status, des}) {
    const router = useRouter();

    const handleCardClick = () => {
        router.push(`/dashboard/administrator/dashboard/application/${id}`);
    };
    return(
        <Card 
            onClick={handleCardClick}
            className="border shadow-2xl"
        
        >
            <CardHeader>
                <CardTitle className="text-center">{name}</CardTitle>
                <CardDescription>
                <span>
                    {status ? "🟢 Published" : "🔴 Offline"}
                </span>
                </CardDescription>
            </CardHeader>
            <CardContent>
                <h4 className="text-bold text-gray-700 mt-2">🔗URL:-  {base_url}</h4>
                <p>» Description:- {des}</p>
            </CardContent>

        </Card>
    );
}