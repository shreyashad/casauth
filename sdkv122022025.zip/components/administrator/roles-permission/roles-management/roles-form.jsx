"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import DragDropList from "@/components/ui/drag-drop-list";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { fetchPermissionListByApplication } from "@/lib/administrator/rolesPermission_api";
import { RolesFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";


export const RolesForm = ({ initialData, appData }) => {
    const  {data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState();
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Role" : "Create Role";
    const description = initialData && initialData.id ? "Edit an Role" : "Create a new Role";
    const toastMessage = initialData && initialData.id ? "Role updated successfully" : "Role created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const [permissionData, setPermissionData] = useState([]);
    const [selectedApplication, setSelectedApplication] = useState("");
    const [selectedPermissions, setSelectedPermissions] = useState(initialData?.permissions || []);
    
    

    const form = useForm({
        resolver: zodResolver(RolesFormSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            application: "",
            permissions: [],
            default_for_application: false,
        },
    });

    useEffect(() => {
        if (initialData) {
            form.reset(initialData);
            setSelectedPermissions(initialData.permissions || []);
            setSelectedApplication(initialData.application || "");
        }
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
               const updateform = await updateApplicationDetails(session.accessToken, initialData.id, values);
               console.log("Update Response:", updateform);
            } else {
                const newRole = await createNewApplication(session.accessToken, values);
                console.log("Create Response:", newRole);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        }
        finally {
            setLoading(false);
        }
    };

    const handleApplicationChange = (value) => {
        setSelectedApplication(value);
        form.setValue("application", value);
        form.setValue("permissions", []);
      
        if (value) {
          fetchPermissions(value);
        } else {
          setPermissionData([]);
        }
    };

    const fetchPermissions = async (applicationId) => {
        try {
          const permissionRes = await fetchPermissionListByApplication(session.accessToken, applicationId);
          const permissionsFormatted = permissionRes.map((permission) => ({
            id: permission.id,
            label: permission.name,
            description: permission.description,
          }));

          console.log("permission list as per app:", permissionRes);
          setPermissionData(permissionsFormatted);
        } catch (error) {
          toast.error("Error fetching permissions");
        }
    };



    return(
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField 
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input 
                                                {...field}
                                                placeholder="Name"
                                                disabled={loading}

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="application"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Application</FormLabel>
                                        <Select
                                            disabled={loading || !appData.length}
                                            onValueChange={(value) =>{
                                                handleApplicationChange(value);
                                                field.onChange(value)
                                            }}
                                            value={field.value}
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            appData.length > 0
                                                                ? "Application "
                                                                : "No Application available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {appData.length > 0 ? appData.map((apps) => (
                                                    <SelectItem key={apps.id} value={apps.id}>
                                                        {apps.name}
                                                    </SelectItem>
                                                )) : (
                                                    <SelectItem disabled>No Application found</SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="permissions"
                                render={({ field }) => (  
                                    <FormItem>
                                        <FormLabel>Permissions</FormLabel>
                                        <DragDropList 
                                            allItems={permissionData}
                                            selectedItems={selectedPermissions}
                                            onItemsChange={setSelectedPermissions}
                                            // allItems={permissionData}
                                            // selectedItems={selectedPermissions}
                                            // onItemsChange={(newItems) => {
                                            //     setSelectedPermissions(newItems);
                                            //     form.setValue("permissions", newItems.map(item => item.id)); // Sync with form
                                            // }}
                                        />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};