"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { RolesCellAction } from "./roles-cell-actions";




export const RolesColumns = [
    {
        id: "select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),
        cell: ({ row }) => (
            <Checkbox
                checked={row.getIsSelected()}
                onCheckedChange={(value) => row.toggleSelected(!!value)}
                aria-label="Select row"
                className="translate-y-[2px]"
            />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Name"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.name}</div>;
        }
    },
    {
        accessorKey: "application",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Application"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.application.name}</div>;
        }
    },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <RolesCellAction data={row.original} />,
    }
];