"use client";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { Checkbox } from "@/components/ui/checkbox";
import { UserRoleCellAction } from "./user-roles-cell-actions";


export const UserRoleColumns = [
    {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
            className="translate-y-[2px]"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
    {
        accessorKey: "user",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"User"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.user.username}</div>;
        }
    },
    {
        accessorKey: "application",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Application"} />,
        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.application.name}</div>;
      }
    },
    {
        accessorKey: "status",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Status"} />,
        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.status}</div>;
      }
    },
    {
        accessorKey: "role",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Role"} />,
        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.role.name}</div>;
      }
    },

    {
      
      id: "actions",
      enableSorting: false,
      cell: ({ row }) => <UserRoleCellAction data={row.original} />, // Ensure data is passed correctly
    }
];