import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export default function DragDropList({
  allItems,
  selectedItems,
  onItemsChange,
  getItemId,        // function to get the item's ID
  getItemLabel,     // function to get the item's label (for display)
}) {
  const [availableItems, setAvailableItems] = useState(
    allItems.filter(item => !selectedItems.includes(getItemId(item)))
  );
  const [assignedItems, setAssignedItems] = useState(
    allItems.filter(item => selectedItems.includes(getItemId(item)))
  );

  const onDragEnd = (result) => {
    const { source, destination } = result;

    if (!destination) {
      return;
    }

    if (source.droppableId === destination.droppableId) {
      const items = reorder(
        source.droppableId === 'available' ? availableItems : assignedItems,
        source.index,
        destination.index
      );

      if (source.droppableId === 'available') {
        setAvailableItems(items);
      } else {
        setAssignedItems(items);
      }
    } else {
      const result = move(
        source.droppableId === 'available' ? availableItems : assignedItems,
        source.droppableId === 'available' ? assignedItems : availableItems,
        source,
        destination
      );

      setAvailableItems(result.available);
      setAssignedItems(result.assigned);
    }

    onItemsChange(assignedItems.map(item => getItemId(item)));
  };

  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
  };

  const move = (source, destination, droppableSource, droppableDestination) => {
    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.splice(droppableSource.index, 1);

    destClone.splice(droppableDestination.index, 0, removed);

    const result = {};
    result[droppableSource.droppableId] = sourceClone;
    result[droppableDestination.droppableId] = destClone;

    return {
      available: result['available'] || sourceClone,
      assigned: result['assigned'] || destClone
    };
  };

  const handleSelectAll = () => {
    setAssignedItems([...assignedItems, ...availableItems]);
    setAvailableItems([]);
    onItemsChange(allItems.map(item => getItemId(item)));
  };

  const handleDeselectAll = () => {
    setAvailableItems([...availableItems, ...assignedItems]);
    setAssignedItems([]);
    onItemsChange([]);
  };

  const handleToggleItem = (item) => {
    if (assignedItems.some(i => getItemId(i) === getItemId(item))) {
      setAssignedItems(assignedItems.filter(i => getItemId(i) !== getItemId(item)));
      setAvailableItems([...availableItems, item]);
    } else {
      setAssignedItems([...assignedItems, item]);
      setAvailableItems(availableItems.filter(i => getItemId(i) !== getItemId(item)));
    }
    onItemsChange(assignedItems.map(i => getItemId(i)));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between">
        <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
        <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
      </div>
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Droppable droppableId="available">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
              >
                <h3 className="font-bold mb-2">Available Items</h3>
                {availableItems.map((item, index) => (
                  <Draggable key={getItemId(item)} draggableId={getItemId(item).toString()} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className="bg-white p-2 mb-2 rounded shadow-sm"
                      >
                        <div className="flex items-center">
                          <Checkbox
                            id={`available-${getItemId(item)}`}
                            checked={false}
                            onCheckedChange={() => handleToggleItem(item)}
                          />
                          <Label htmlFor={`available-${getItemId(item)}`} className="ml-2">
                            {getItemLabel(item)}
                          </Label>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
          <Droppable droppableId="assigned">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
              >
                <h3 className="font-bold mb-2">Assigned Items</h3>
                {assignedItems.map((item, index) => (
                  <Draggable key={getItemId(item)} draggableId={getItemId(item).toString()} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className="bg-white p-2 mb-2 rounded shadow-sm"
                      >
                        <div className="flex items-center">
                          <Checkbox
                            id={`assigned-${getItemId(item)}`}
                            checked={true}
                            onCheckedChange={() => handleToggleItem(item)}
                          />
                          <Label htmlFor={`assigned-${getItemId(item)}`} className="ml-2">
                            {getItemLabel(item)}
                          </Label>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </div>
      </DragDropContext>
    </div>
  );
}name = models.CharField(max_length=150)
description = models.TextField(blank=True)
application = models.ForeignKey(Application, on_delete=models.CASCADE)
permissions = models.ManyToManyField(Permission)
default_for_application


\
-----
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import DragDropList from "@/components/ui/drag-drop-list";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fetchPermissionListByApplication } from "@/lib/administrator/rolesPermission_api";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-hot-toast";

export const RolesForm = ({ initialData, appData }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState();
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Role" : "Create Role";
    const description = initialData && initialData.id ? "Edit an existing Role" : "Create a new Role";
    const toastMessage = initialData && initialData.id ? "Role updated successfully" : "Role created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const [permissionData, setPermissionData] = useState([]);
    const [selectedApplication, setSelectedApplication] = useState("");
    const [selectedPermissions, setSelectedPermissions] = useState(initialData?.Permissions || []);

    const form = useForm({
        resolver: zodResolver(),
        defaultValues: initialData || {
            name: "",
            description: "",
            application: "",
            Permissions: [],
            default_for_application: false,
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            const payload = { ...values, Permissions: selectedPermissions };
            if (initialData && initialData.id) {
                const updateResponse = await updateApplicationDetails(session.accessToken, initialData.id, payload);
                console.log("Update Response:", updateResponse);
            } else {
                const newRole = await createNewApplication(session.accessToken, payload);
                console.log("Create Response:", newRole);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleApplicationChange = (value) => {
        setSelectedApplication(value);
        form.setValue("application", value);
        form.setValue("Permissions", []);
        setSelectedPermissions([]);

        if (value) {
            fetchPermissions(value);
        } else {
            setPermissionData([]);
        }
    };

    const fetchPermissions = async (applicationId) => {
        try {
            const permissionRes = await fetchPermissionListByApplication(session.accessToken, applicationId);
            setPermissionData(permissionRes);
        } catch (error) {
            toast.error("Error fetching permissions");
        }
    };

    return (
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                placeholder="Name"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="application"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Application</FormLabel>
                                        <Select
                                            disabled={loading || !appData.length}
                                            onValueChange={(value) => {
                                                handleApplicationChange(value);
                                                field.onChange(value);
                                            }}
                                            value={field.value}
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue
                                                        placeholder={
                                                            appData.length > 0
                                                                ? "Select Application"
                                                                : "No Applications available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {appData.length > 0 ? (
                                                    appData.map((apps) => (
                                                        <SelectItem key={apps.id} value={apps.id}>
                                                            {apps.name}
                                                        </SelectItem>
                                                    ))
                                                ) : (
                                                    <SelectItem disabled>
                                                        No Applications found
                                                    </SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="Permissions"
                                render={() => (
                                    <FormItem>
                                        <FormLabel>Permissions</FormLabel>
                                        <DragDropList
                                            allItems={permissionData}
                                            selectedItems={selectedPermissions}
                                            onItemsChange={setSelectedPermissions}
                                        />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
--------
// gimini
// components/DraggableList.jsx
import React, { useState, useRef, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { cn } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Trash2Icon } from "lucide-react";

const DraggableList = ({ items, onSubmit, initialSelectedItems = [] }) => {
  const [selectedItems, setSelectedItems] = useState(initialSelectedItems);
  const [availableItems, setAvailableItems] = useState(items.filter(item => !initialSelectedItems.includes(item.id)));
  const droppableAvailableId = useRef(`droppable-available-${Math.random()}`).current;
  const droppableSelectedId = useRef(`droppable-selected-${Math.random()}`).current;

  useEffect(() => {
    const validInitialSelectedItems = initialSelectedItems.filter(id => items.some(item => item.id === id));
    setSelectedItems(validInitialSelectedItems);
    setAvailableItems(items.filter(item => !validInitialSelectedItems.includes(item.id)));
  }, [items, initialSelectedItems]);

  const handleOnDragEnd = (result) => {
    if (!result.destination) return;

    const sourceList = result.source.droppableId.startsWith("droppable-available") ? availableItems : selectedItems;
    const destList = result.destination.droppableId.startsWith("droppable-available") ? availableItems : selectedItems;

    const updatedSourceList = Array.from(sourceList);
    const updatedDestList = Array.from(destList);

    const [removed] = updatedSourceList.splice(result.source.index, 1);
    updatedDestList.splice(result.destination.index, 0, removed);

    if (result.source.droppableId !== result.destination.droppableId) {
      if (result.source.droppableId.startsWith("droppable-available")) {
        setAvailableItems(updatedSourceList);
        setSelectedItems(updatedDestList);
      } else {
        setSelectedItems(updatedSourceList);
        setAvailableItems(updatedDestList);
      }
    } else {
        if (result.source.droppableId.startsWith("droppable-available")) {
            setAvailableItems(updatedDestList)
        } else {
            setSelectedItems(updatedDestList)
        }
    }
  };

  const handleSubmit = () => {
    onSubmit(selectedItems.map(item => item.id));
  };

  const handleRemoveSelected = () => {
    const itemsToRemove = selectedItems.filter(item => selectedItems.includes(item.id))
    setAvailableItems([...availableItems, ...itemsToRemove])
    setSelectedItems([])
  }

  return (
    <div className="w-full flex space-x-4">
      <div className="w-1/2">
        <h3 className="font-medium mb-2">Available Items</h3>
        <DragDropContext onDragEnd={handleOnDragEnd}>
          <Droppable droppableId={droppableAvailableId}>
            {(provided) => (
              <ul {...provided.droppableProps} ref={provided.innerRef} className="border rounded-md p-2 space-y-1 h-[300px] overflow-y-auto">
                {availableItems.map((item, index) => (
                  <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                    {(provided) => (
                      <li
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        ref={provided.innerRef}
                        className="border rounded-md p-2 bg-white shadow-sm hover:bg-gray-100 cursor-pointer"
                      >
                        {item.label}
                      </li>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </ul>
            )}
          </Droppable>
        </DragDropContext>
      </div>
      <div className="w-1/2">
        <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Selected Items</h3>
            <div className="flex space-x-2">
                <Button variant="destructive" size="sm" onClick={handleRemoveSelected} disabled={selectedItems.length === 0}>
                    <Trash2Icon className="h-4 w-4 mr-2" />Remove Selected
                </Button>
            </div>
        </div>
        <DragDropContext onDragEnd={handleOnDragEnd}>
          <Droppable droppableId={droppableSelectedId}>
            {(provided) => (
              <ul {...provided.droppableProps} ref={provided.innerRef} className="border rounded-md p-2 space-y-1 h-[300px] overflow-y-auto">
                {selectedItems.map((item, index) => (
                  <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                    {(provided) => (
                      <li
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        ref={provided.innerRef}
                        className="border rounded-md p-2 bg-white shadow-sm hover:bg-gray-100 cursor-pointer"
                      >
                        {item.label}
                      </li>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </ul>
            )}
          </Droppable>
        </DragDropContext>
        <Button className="mt-2 w-full" onClick={handleSubmit}>Submit</Button>
      </div>
    </div>
  );
};

export default DraggableList;
--------
export default function DragDropList({
  allItems,
  selectedItems,
  onItemsChange,
}) {
  const getItemId = (item) => {
      // Replace with the correct property for your items
      return item.id;
  };

  const getItemLabel = (item) => {
      // Replace with the correct property for your items
      return item.name;
  };

  const [availableItems, setAvailableItems] = useState(
      allItems.filter(item => !selectedItems.includes(getItemId(item)))
  );

  const [assignedItems, setAssignedItems] = useState(
      allItems.filter(item => selectedItems.includes(getItemId(item)))
  );

  const onDragEnd = (result) => {
      const { source, destination } = result;

      if (!destination) {
          return;
      }
    
      if (source.droppableId === destination.droppableId) {
          const items = reorder(
              source.droppableId === 'available' ? availableItems : assignedItems,
              source.index,
              destination.index
          );
  
          if (source.droppableId === 'available') {
              setAvailableItems(items);
          } else {
              setAssignedItems(items);
          }
      } else {
          const result = move(
              source.droppableId === 'available' ? availableItems : assignedItems,
              source.droppableId === 'available' ? assignedItems : availableItems,
              source,
              destination
          );
  
          setAvailableItems(result.available);
          setAssignedItems(result.assigned);
      }
    
      onItemsChange(assignedItems.map(item => getItemId(item)));
  };

  const reorder = (list, startIndex, endIndex) => {
      const result = Array.from(list);
      const [removed] = result.splice(startIndex, 1);
      result.splice(endIndex, 0, removed);
      return result;
  };

  const move = (source, destination, droppableSource, droppableDestination) => {
      const sourceClone = Array.from(source);
      const destClone = Array.from(destination);
      const [removed] = sourceClone.splice(droppableSource.index, 1);
  
      destClone.splice(droppableDestination.index, 0, removed);
  
      const result = {};
      result[droppableSource.droppableId] = sourceClone;
      result[droppableDestination.droppableId] = destClone;
  
      return {
        available: result['available'] || sourceClone,
        assigned: result['assigned'] || destClone
      };
  };

  const handleSelectAll = () => {
      setAssignedItems([...assignedItems, ...availableItems]);
      setAvailableItems([]);
      onItemsChange(allItems.map(item => getItemId(item)));
  };
  
  const handleDeselectAll = () => {
      setAvailableItems([...availableItems, ...assignedItems]);
      setAssignedItems([]);
      onItemsChange([]);
  };

  const handleToggleItem = (item) => {
      if (assignedItems.some(i => getItemId(i) === getItemId(item))) {
          setAssignedItems(assignedItems.filter(i => getItemId(i) !== getItemId(item)));
          setAvailableItems([...availableItems, item]);
      } else {
          setAssignedItems([...assignedItems, item]);
          setAvailableItems(availableItems.filter(i => getItemId(i) !== getItemId(item)));
      }
      onItemsChange(assignedItems.map(i => getItemId(i)));
  };

  return (
      <div className="space-y-4">
          <div className="flex justify-between">
              <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
              <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
          </div>
          <DragDropContext onDragEnd={onDragEnd}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Droppable droppableId="available">
                      {(provided) => (
                          <div
                              {...provided.droppableProps}
                              ref={provided.innerRef}
                              className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                          >
                              <h3 className="font-bold mb-2">Available Items</h3>
                              {availableItems.map((item, index) => (
                                  <Draggable key={getItemId(item)} draggableId={getItemId(item).toString()} index={index}>
                                      {(provided) => (
                                          <div
                                              ref={provided.innerRef}
                                              {...provided.draggableProps}
                                              {...provided.dragHandleProps}
                                              className="bg-white p-2 mb-2 rounded shadow-sm"
                                          >
                                              <div className="flex items-center">
                                                  <Checkbox
                                                      id={`available-${getItemId(item)}`}
                                                      checked={false}
                                                      onCheckedChange={() => handleToggleItem(item)}
                                                  />
                                                  <Label htmlFor={`available-${getItemId(item)}`} className="ml-2">
                                                      {getItemLabel(item)}
                                                  </Label>
                                              </div>
                                          </div>
                                      )}
                                  </Draggable>
                              ))}
                              {provided.placeholder}
                          </div>
                      )}
                  </Droppable>
                  <Droppable droppableId="assigned">
                      {(provided) => (
                          <div
                              {...provided.droppableProps}
                              ref={provided.innerRef}
                              className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                          >
                              <h3 className="font-bold mb-2">Assigned Items</h3>
                              {assignedItems.map((item, index) => (
                                  <Draggable key={getItemId(item)} draggableId={getItemId(item).toString()} index={index}>
                                      {(provided) => (
                                          <div
                                              ref={provided.innerRef}
                                              {...provided.draggableProps}
                                              {...provided.dragHandleProps}
                                              className="bg-white p-2 mb-2 rounded shadow-sm"
                                          >
                                              <div className="flex items-center">
                                                  <Checkbox
                                                      id={`assigned-${getItemId(item)}`}
                                                      checked={true}
                                                      onCheckedChange={() => handleToggleItem(item)}
                                                  />
                                                  <Label htmlFor={`assigned-${getItemId(item)}`} className="ml-2">
                                                      {getItemLabel(item)}
                                                  </Label>
                                              </div>
                                          </div>
                                      )}
                                  </Draggable>
                              ))}
                              {provided.placeholder}
                          </div>
                      )}
                  </Droppable>
              </div>
          </DragDropContext>
      </div>
  );
};
-----------
"use client";

import { useEffect, useState } from "react";
import { Button } from "./button";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { Checkbox } from "./checkbox";
import { Label } from "./label";

export default function DragDropList({
    allItems,
    selectedItems,
    onItemsChange,
}) {
    const [availableItems, setAvailableItems] = useState([]);
    const [assignedItems, setAssignedItems] = useState([]);

    // Update the available and assigned items based on selectedItems
    useEffect(() => {
        setAvailableItems(allItems.filter(item => !selectedItems.includes(item.id)));
        setAssignedItems(allItems.filter(item => selectedItems.includes(item.id)));
    }, [allItems, selectedItems]);

    const onDragEnd = (result) => {
        const { source, destination } = result;

        if (!destination) {
            return;
        }

        // Case 1: If the item is dropped within the same list
        if (source.droppableId === destination.droppableId) {
            const items = reorder(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.index,
                destination.index
            );

            if (source.droppableId === "available") {
                setAvailableItems(items);
            } else {
                setAssignedItems(items);
            }
        }
        // Case 2: If the item is moved between lists (available <-> assigned)
        else {
            const result = move(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.droppableId === "available" ? assignedItems : availableItems,
                source,
                destination
            );

            setAvailableItems(result.available);
            setAssignedItems(result.assigned);
        }

        // After the drag and drop operation, call onItemsChange with updated assignedItems
        onItemsChange(assignedItems.map(item => item.id));
    };

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const move = (source, destination, droppableSource, droppableDestination) => {
        const sourceClone = Array.from(source);
        const destClone = Array.from(destination);
        const [removed] = sourceClone.splice(droppableSource.index, 1);

        destClone.splice(droppableDestination.index, 0, removed);

        const result = {};
        result[droppableSource.droppableId] = sourceClone;
        result[droppableDestination.droppableId] = destClone;

        return {
            available: result["available"] || sourceClone,
            assigned: result["assigned"] || destClone,
        };
    };

    const handleSelectAll = () => {
        setAssignedItems([...assignedItems, ...availableItems]);
        setAvailableItems([]);
        onItemsChange(allItems.map(item => item.id));
    };

    const handleDeselectAll = () => {
        setAvailableItems([...availableItems, ...assignedItems]);
        setAssignedItems([]);
        onItemsChange([]);
    };

    const handleToggleItem = (item) => {
        if (assignedItems.some(i => i.id === item.id)) {
            // Move item back to Available
            setAssignedItems(assignedItems.filter(i => i.id !== item.id));
            setAvailableItems([...availableItems, item]);
        } else {
            // Move item to Assigned
            setAssignedItems([...assignedItems, item]);
            setAvailableItems(availableItems.filter(i => i.id !== item.id));
        }
        
        // Update the selectedItems based on current assignedItems
        onItemsChange(assignedItems.map(i => i.id));
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between">
                <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
                <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
            </div>

            <Drag DropContext onDragEnd={onDragEnd}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Available Items */}
                    <Droppable droppableId="available">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px] max-h-[300px] overflow-y-auto"
                            >
                                <h3 className="font-bold mb-2">Available Items</h3>
                                {availableItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm cursor-pointer"
                                                onClick={() => handleToggleItem(item)} // OnClick move item to Assigned
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`available-${item.id}`}
                                                        checked={false}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`available-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>

                    {/* Assigned Items */}
                    <Droppable droppableId="assigned">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px] max-h-[300px] overflow-y-auto"
                            >
                                <h3 className="font-bold mb-2">Assigned Items</h3>
                                {assignedItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm cursor-pointer"
                                                onClick={() => handleToggleItem(item)} // OnClick move item to Available
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`assigned-${item.id}`}
                                                        checked={true}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`assigned-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                </div>
            </DragDropContext>
        </div>
    );
}