"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { uploadPermissionsFromExcel } from "@/lib/administrator/rolesPermission_api";
import { Plus } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation"
import { useState } from "react";

export const PermissionClient = () => {
    const router = useRouter();
    const [file, setFile] = useState(null);
    const [error, setError] = useState(null);
    const [message, setMessage] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const { data: session } = useSession();


    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile && selectedFile.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
            setError("Please select a valid Excel file (.xlsx).");
            setFile(null);
        } else {
            setFile(selectedFile);
            setError(null); // Clear any previous error
        }
    };


    const handleUpload = async (event) => {
        event.preventDefault();

        if (!file) {
            setError("Please select an Excel file.");
            return;
        }
        setIsUploading(true); // Set uploading state to true
        setError(null); // Clear any previous error
        setMessage(null); // Clear any previous message
        
        const formData = new FormData();
        formData.append('file', file);
        try {
            const response = await uploadPermissionsFromExcel(session.accessToken, formData);
            setMessage(response.message);
            setFile(null);
        } catch (err) {
            setError(err.message);
        } finally {
            setIsUploading(false); // Reset uploading state
        }
    };

    return(
        <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Permission Management</h2>
            <div className="flex items-center justify-between gap-4">
                <div className="flex items-center justify-between">
                    <form onSubmit={handleUpload}>
                        <Input
                            type="file"
                            accept=".xlsx"
                            onChange={handleFileChange}
                        />
                        <Button type="submit">Upload</Button>
                        
                    </form>
                    
                </div>

                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/roles-permission/permissions/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
            {error && <div className="text-red-500">{error}</div>}
            {message && <div className="text-green-500">{message}</div>}
        </div>
    );
};