"use client";

import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";

export const LogsColumns = [
        {
          accessorKey: "application_name",
          header: ({ column }) => <DataTableColumnHeader column={column} title={"Application"} />,
          cell: ({ row }) => {
              return <div className="flex items-center">{row.original.application_name}</div>;
          }
        },
        {
          accessorKey: "username",
          header: ({ column }) => <DataTableColumnHeader column={column} title={"User"} />,
          cell: ({ row }) => {
              return <div className="flex items-center">{row.original.username}</div>;
          }
        },
        {
          accessorKey: "action_type",
          header: ({ column }) => <DataTableColumnHeader column={column} title={"Log Type"} />,
          cell: ({ row }) => {
              return <div className="flex items-center">{row.original.action_type}</div>;
          }
        },
        {
            accessorKey: "details",
            header: ({ column }) => <DataTableColumnHeader column={column} title={"Detials"} />,
            cell: ({ row }) => {
                return <div className="flex items-center">{row.original.details}</div>;
            }
        },
        {
            accessorKey: "timestamp",
            header: ({ column }) => <DataTableColumnHeader column={column} title={"Time"} />,
            cell: ({ row }) => {
                return <div className="flex items-center">{row.original.timestamp}</div>;
            }
        },
];