"use client";
import { useState } from "react";
import { Calendar } from "../ui/calendar";

export function CalendarComponent() {
    const [date, setDate] = useState(new Date);
    return(
        <div className="rounded-md border-2 shadow-lg w-full">
            <div className="w-full max-w-full overflow-hidden">
                <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="w-full h-auto rounded-md border shadow"
                />
            </div>
        </div>
    );
};