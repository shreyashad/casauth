"use client";
import { X } from "lucide-react";
import { Button } from "../button";
import { Input } from "../input";
import { DataTableViewOptions } from "./data-table-view-options"
import { DataTableFacetedFilter } from "./data-table-faceted-filter";


export function DataTableToolbar({ table, globalFilterColumnId, facetedFilters=[] }) {
    const isFiltered = table.getState().columnFilters.length > 0;
    
    return (
        <div className="flex item-center justify-between">
            <div className="flex flex-1 item-center space-x-2">
                {globalFilterColumnId && (
                    <Input 
                        placeholder={`Filter ${globalFilterColumnId}...`}
                        value={(table.getColumn(globalFilterColumnId)?.getFilterValue() || "" )}
                        onChange={(even) => 
                            table.getColumn(globalFilterColumnId)?.setFilterValue(event.target.value)
                        }
                        className="h-8 w-[150px] lg:w-[250px]"
                    />
                )}
                {facetedFilters.map((filter) => (
                    <DataTableFacetedFilter 
                        key={filter.id}
                        column={table.getColumn(filter.id)}
                        title={filter.title}
                       
                    />
                ))}
                {isFiltered && (
                    <Button
                        variant="ghost"
                        onClick={() => table.resetColumnFilters()}
                        className="h-8 px-2 lg:px-3"
                    >
                        Reset
                        <X />
                    </Button>
                )}
            </div>
            <DataTableViewOptions table={table} />
        </div>
    )
};