"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import DragDropList from "@/components/ui/drag-drop-list";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fetchPermissionListByApplication } from "@/lib/administrator/rolesPermission_api";
import { RolesFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

export const RolesForm = ({ initialData, appData }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState();
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Role" : "Create Role";
    const description = initialData && initialData.id ? "Edit an Role" : "Create a new Role";
    const toastMessage = initialData && initialData.id ? "Role updated successfully" : "Role created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const [permissionData, setPermissionData] = useState([]);
    const [selectedApplication, setSelectedApplication] = useState(initialData?.application || "");
    const [selectedPermissions, setSelectedPermissions] = useState(initialData?.Permissions || []);
    
    const form = useForm({
        resolver: zodResolver(RolesFormSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            application: "",
            permissions: [], // This will be updated dynamically
            default_for_application: false,
        },
    });

    // Reset form when initialData changes (useEffect to handle initialData changes)
    useEffect(() => {
        if (initialData) {
            form.reset(initialData);
            setSelectedPermissions(initialData.Permissions || []);
            setSelectedApplication(initialData.application);
        }
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                const updateform = await updateApplicationDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateform);
            } else {
                const newRole = await createNewApplication(session.accessToken, values);
                console.log("Create Response:", newRole);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    // Handle application change and fetch corresponding permissions
    const handleApplicationChange = (value) => {
        setSelectedApplication(value);
        form.setValue("application", value); // Sync form field
        form.setValue("permissions", []); // Clear previously selected permissions

        if (value) {
            fetchPermissions(value);
        } else {
            setPermissionData([]);
        }
    };

    // Fetch permissions based on the selected application
    const fetchPermissions = async (applicationId) => {
        try {
            const permissionRes = await fetchPermissionListByApplication(session.accessToken, applicationId);
            const permissionsFormatted = permissionRes.data.map((permission) => ({
                id: permission.id, // Permission ID
                label: permission.name, // Permission Name (or description if needed)
                description: permission.description, // Optional: you can use this if needed
            }));
            setPermissionData(permissionsFormatted);
        } catch (error) {
            toast.error("Error fetching permissions");
        }
    };

    return (
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField control={form.control} name="name" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Name</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Name" disabled={loading} />
                                    </FormControl>
                                </FormItem>
                            )} />

                            <FormField control={form.control} name="application" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Application</FormLabel>
                                    <Select
                                        disabled={loading || !appData.length}
                                        onValueChange={(value) => {
                                            handleApplicationChange(value);
                                            field.onChange(value);
                                        }}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue 
                                                    placeholder={appData.length > 0 ? "Select Application" : "No Application available"} />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {appData.length > 0 ? appData.map((apps) => (
                                                <SelectItem key={apps.id} value={apps.id}>
                                                    {apps.name}
                                                </SelectItem>
                                            )) : (
                                                <SelectItem disabled>No Application found</SelectItem>
                                            )}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )} />

                            <FormField control={form.control} name="permissions" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Permissions</FormLabel>
                                    <DragDropList
                                        allItems={permissionData} // List of all permissions available for the application
                                        selectedItems={selectedPermissions} // Permissions selected for the role
                                        onItemsChange={(newItems) => {
                                            setSelectedPermissions(newItems);
                                            form.setValue("permissions", newItems.map(item => item.id)); // Sync with form
                                        }}
                                    />
                                </FormItem>
                            )} />
                        </div>

                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
---
import { useEffect, useState } from "react";
import { Button } from "./button";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { Checkbox } from "./checkbox";
import { Label } from "./label";

export default function DragDropList({
    allItems,
    selectedItems,
    onItemsChange,
}) {
    const [availableItems, setAvailableItems] = useState([]);
    const [assignedItems, setAssignedItems] = useState([]);

    useEffect(() => {
        setAvailableItems(allItems.filter(item => !selectedItems.includes(item.id)));
        setAssignedItems(allItems.filter(item => selectedItems.includes(item.id)));
    }, [allItems, selectedItems]);

    const onDragEnd = (result) => {
        const { source, destination } = result;

        if (!destination) {
            return;
        }

        if (source.droppableId === destination.droppableId) {
            const items = reorder(
                source.droppableId === 'available' ? availableItems : assignedItems,
                source.index,
                destination.index
            );

            if (source.droppableId === 'available') {
                setAvailableItems(items);
            } else {
                setAssignedItems(items);
            }
        } else {
            const result = move(
                source.droppableId === 'available' ? availableItems : assignedItems,
                source.droppableId === 'available' ? assignedItems : availableItems,
                source,
                destination
            );

            setAvailableItems(result.available);
            setAssignedItems(result.assigned);
        }

        onItemsChange(assignedItems.map(item => item.id));
    };

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const move = (source, destination, droppableSource, droppableDestination) => {
        const sourceClone = Array.from(source);
        const destClone = Array.from(destination);
        const [removed] = sourceClone.splice(droppableSource.index, 1);

        destClone.splice(droppableDestination.index, 0, removed);

        return {
            available: sourceClone,
            assigned: destClone
        };
    };

    const handleSelectAll = () => {
        setAssignedItems([...assignedItems, ...availableItems]);
        setAvailableItems([]);
        onItemsChange(allItems.map(item => item.id));
    };

    const handleDeselectAll = () => {
        setAvailableItems([...availableItems, ...assignedItems]);
        setAssignedItems([]);
        onItemsChange([]);
    };

    const handleToggleItem = (item) => {
        if (assignedItems.some(i => i.id === item.id)) {
            setAssignedItems(assignedItems.filter(i => i.id !== item.id));
            setAvailableItems([...availableItems, item]);
        } else {
            setAssignedItems([...assignedItems, item]);
            setAvailableItems(availableItems.filter(i => i.id !== item.id));
        }
        onItemsChange(assignedItems.map(i => i.id));
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between">
                <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
                <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
            </div>
            <DragDropContext onDragEnd={onDragEnd}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Droppable droppableId="available">
                        {( provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                            >
                                <h3 className="font-bold mb-2">Available Items</h3>
                                {availableItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm"
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`available-${item.id}`}
                                                        checked={false}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`available-${item.id}`} className="ml-2">
                                                        {item.name}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                    <Droppable droppableId="assigned">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                            >
                                <h3 className="font-bold mb-2">Assigned Items</h3>
                                {assignedItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm"
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`assigned-${item.id}`}
                                                        checked={true}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`assigned-${item.id}`} className="ml-2">
                                                        {item.name}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                </div>
            </DragDropContext>
        </div>
    );
}----
--
"use client";

import { useEffect, useState } from "react";
import { Button } from "./button";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { Checkbox } from "./checkbox";
import { Label } from "./label";

export default function DragDropList({
    allItems,
    selectedItems,
    onItemsChange,
}) {
    const [availableItems, setAvailableItems] = useState([]);
    const [assignedItems, setAssignedItems] = useState([]);

    // Update the available and assigned items based on selectedItems
    useEffect(() => {
        setAvailableItems(allItems.filter(item => !selectedItems.includes(item.id)));
        setAssignedItems(allItems.filter(item => selectedItems.includes(item.id)));
    }, [allItems, selectedItems]);

    const onDragEnd = (result) => {
        const { source, destination } = result;

        if (!destination) {
            return;
        }

        // Case 1: If the item is dropped within the same list
        if (source.droppableId === destination.droppableId) {
            const items = reorder(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.index,
                destination.index
            );

            if (source.droppableId === "available") {
                setAvailableItems(items);
            } else {
                setAssignedItems(items);
            }
        }
        // Case 2: If the item is moved between lists (available <-> assigned)
        else {
            const result = move(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.droppableId === "available" ? assignedItems : availableItems,
                source,
                destination
            );

            setAvailableItems(result.available);
            setAssignedItems(result.assigned);
        }

        // After the drag and drop operation, call onItemsChange with updated assignedItems
        onItemsChange(assignedItems.map(item => item.id));
    };

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const move = (source, destination, droppableSource, droppableDestination) => {
        const sourceClone = Array.from(source);
        const destClone = Array.from(destination);
        const [removed] = sourceClone.splice(droppableSource.index, 1);

        destClone.splice(droppableDestination.index, 0, removed);

        const result = {};
        result[droppableSource.droppableId] = sourceClone;
        result[droppableDestination.droppableId] = destClone;

        return {
            available: result["available"] || sourceClone,
            assigned: result["assigned"] || destClone,
        };
    };

    const handleSelectAll = () => {
        setAssignedItems([...assignedItems, ...availableItems]);
        setAvailableItems([]);
        onItemsChange(allItems.map(item => item.id));
    };

    const handleDeselectAll = () => {
        setAvailableItems([...availableItems, ...assignedItems]);
        setAssignedItems([]);
        onItemsChange([]);
    };

    const handleToggleItem = (item) => {
        if (assignedItems.some(i => i.id === item.id)) {
            setAssignedItems(assignedItems.filter(i => i.id !== item.id));
            setAvailableItems([...availableItems, item]);
        } else {
            setAssignedItems([...assignedItems, item]);
            setAvailableItems(availableItems.filter(i => i.id !== item.id));
        }
        onItemsChange(assignedItems.map(i => i.id));
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between">
                <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
                <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
            </div>

            <DragDropContext onDragEnd={onDragEnd}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Available Items */}
                    <Droppable droppableId="available">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                            >
                                <h3 className="font-bold mb-2">Available Items</h3>
                                {availableItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm"
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`available-${item.id}`}
                                                        checked={false}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`available-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>

                    {/* Assigned Items */}
                    <Droppable droppableId="assigned">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px]"
                            >
                                <h3 className="font-bold mb-2">Assigned Items</h3>
                                {assignedItems.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm"
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`assigned-${item.id}`}
                                                        checked={true}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`assigned-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                </div>
            </DragDropContext>
        </div>
    );
}
