"use client";

import { useMemo, useState } from "react";
import { Button } from "./button";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { Checkbox } from "./checkbox";
import { Label } from "./label";

export default function DragDropList({
    allItems,
    selectedItems,
    onItemsChange,
}) {
    const [availableItems, setAvailableItems] = useState(allItems);
    const [assignedItems, setAssignedItems] = useState([]);

    // useMemo to compute available and assigned items based on selectedItems
    const availableItemsMemo = useMemo(() => {
        return allItems.filter(item => !selectedItems.includes(item.id));
    }, [allItems, selectedItems]);

    const assignedItemsMemo = useMemo(() => {
        return allItems.filter(item => selectedItems.includes(item.id));
    }, [allItems, selectedItems]);

    // Update the state of availableItems and assignedItems when selectedItems changes
    const updateState = (newSelectedItems) => {
        setAvailableItems(allItems.filter(item => !newSelectedItems.includes(item.id)));
        setAssignedItems(allItems.filter(item => newSelectedItems.includes(item.id)));
    };

    const onDragEnd = (result) => {
        const { source, destination } = result;

        if (!destination) return;

        // Handle drag within the same list (Available or Assigned)
        if (source.droppableId === destination.droppableId) {
            const items = reorder(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.index,
                destination.index
            );

            if (source.droppableId === "available") {
                setAvailableItems(items);
            } else {
                setAssignedItems(items);
            }
        } else {
            // Handle drag between lists (Available <-> Assigned)
            const result = move(
                source.droppableId === "available" ? availableItems : assignedItems,
                source.droppableId === "available" ? assignedItems : availableItems,
                source,
                destination
            );

            setAvailableItems(result.available);
            setAssignedItems(result.assigned);
        }

        // Update the selectedItems and call onItemsChange to pass back to parent
        onItemsChange(assignedItemsMemo.map(item => item.id));
    };

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const move = (source, destination, droppableSource, droppableDestination) => {
        const sourceClone = Array.from(source);
        const destClone = Array.from(destination);
        const [removed] = sourceClone.splice(droppableSource.index, 1);

        destClone.splice(droppableDestination.index, 0, removed);

        const result = {};
        result[droppableSource.droppableId] = sourceClone;
        result[droppableDestination.droppableId] = destClone;

        return {
            available: result["available"] || sourceClone,
            assigned: result["assigned"] || destClone,
        };
    };

    const handleSelectAll = () => {
        const allIds = allItems.map(item => item.id);
        setAssignedItems(allItems);
        setAvailableItems([]);
        onItemsChange(allIds);
    };

    const handleDeselectAll = () => {
        setAvailableItems(allItems);
        setAssignedItems([]);
        onItemsChange([]);
    };

    const handleToggleItem = (item) => {
        if (assignedItems.some(i => i.id === item.id)) {
            // Move item back to Available
            const newAssignedItems = assignedItems.filter(i => i.id !== item.id);
            const newAvailableItems = [...availableItems, item];
            setAssignedItems(newAssignedItems);
            setAvailableItems(newAvailableItems);
            onItemsChange(newAssignedItems.map(i => i.id));
        } else {
            // Move item to Assigned
            const newAssignedItems = [...assignedItems, item];
            const newAvailableItems = availableItems.filter(i => i.id !== item.id);
            setAssignedItems(newAssignedItems);
            setAvailableItems(newAvailableItems);
            onItemsChange(newAssignedItems.map(i => i.id));
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between">
                <Button onClick={handleSelectAll} variant="outline" size="sm">Select All</Button>
                <Button onClick={handleDeselectAll} variant="outline" size="sm">Deselect All</Button>
            </div>

            <DragDropContext onDragEnd={onDragEnd}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Available Items */}
                    <Droppable droppableId="available">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px] max-h-[300px] overflow-y-auto"
                            >
                                <h3 className="font-bold mb-2">Available Items</h3>
                                {availableItemsMemo.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm cursor-pointer"
                                                onClick={() => handleToggleItem(item)} // OnClick move item to Assigned
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`available-${item.id}`}
                                                        checked={false}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`available-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>

                    {/* Assigned Items */}
                    <Droppable droppableId="assigned">
                        {(provided) => (
                            <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-md min-h-[200px] max-h-[300px] overflow-y-auto"
                            >
                                <h3 className="font-bold mb-2">Assigned Items</h3>
                                {assignedItemsMemo.map((item, index) => (
                                    <Draggable key={item.id} draggableId={item.id.toString()} index={index}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className="bg-white p-2 mb-2 rounded shadow-sm cursor-pointer"
                                                onClick={() => handleToggleItem(item)} // OnClick move item to Available
                                            >
                                                <div className="flex items-center">
                                                    <Checkbox
                                                        id={`assigned-${item.id}`}
                                                        checked={true}
                                                        onCheckedChange={() => handleToggleItem(item)}
                                                    />
                                                    <Label htmlFor={`assigned-${item.id}`} className="ml-2">
                                                        {item.label}
                                                    </Label>
                                                </div>
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                </div>
            </DragDropContext>
        </div>
    );
}
