"use client";

import { handleSignOut } from "@/lib/auth/auth_api";
import { useSession } from "next-auth/react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Button } from "../ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { LogOutIcon } from "lucide-react";



export default function UserNav() {
    const { data: session, status } = useSession();

    if (status === "loading") {
        return  
    }

    if (!session || !session.user) {
        return <div> No user data available</div>;
    }

    return(
        <DropdownMenu>
            <DropdownMenuTrigger>
                <Button variant="outline" size="icon" className="relative bg-blue border rounded-full">
                  <Avatar >
                        <AvatarImage src={session.user.profile_picture} alt={session.user.first_name} /> 
                        <AvatarFallback className="bg-blue">{session.user.first_name.split(' ').map(n => n[0].toUpperCase()).join('')}{session.user.last_name.split(' ').map(n => n[0].toUpperCase()).join('')}</AvatarFallback>
                    </Avatar>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                <div className="flex flex-col space-y-1 leading-none">
                        {session.user && <p className="font-medium">{session.user.first_name}</p>}
                        {session.user.username && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {session.user.username}
                            </p>
                        )}
                    </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={async () =>{
                            await handleSignOut(session.accessToken, session.sessionKey);
                        }}
                    >
                        <LogOutIcon className="mr-2 h-4 w-4" aria-hidden="true" />
                        Log Out
                    </Button>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );

};