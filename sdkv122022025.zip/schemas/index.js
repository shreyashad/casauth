// schema for authentication related forms

import { z } from "zod";

// schema for applications management realted form

export const ApplicationFormSchema = z.object({
    name: z.string().min(4, {
        message: " Application name is required"
    }),
    description: z.string().optional(),
    base_url: z.string().min(4, {
        message: "application Url Is required"
    }).url(),
    active: z.boolean({

    }).default(false)
});


// schema for Organization Management

// for Organization Type Form

export const OrgTypeFormSchema = z.object({
    org_type: z.string().min(4,{
        message: "Org type is required"
    })
});

// for Organization SubType Form

export const OrgSubTypeFormSchema = z.object({
    org_type: z.string().min(4,{
        message: "Organization type is required"
    }),
    subtype: z.string().min(4,{
        message: "Subtype is required"
    })

});

// for Organization Form

export const OrganizationFormSchema = z.object({
    name: z.string().min(1, {
        message: "Organization is required"
    }).max(250, "Organization name must be at most 250 characters"),
    org_type: z.string().min(4,{
        message: "Organization type is required"
    }),
    sector: z.string().min(4,{
        message: "Organization Sector is required"
    }), 

});

// for Organization Location Form

export const LocationFormSchema = z.object({
    org_type: z.string().min(4,{
        message: "Organization type is required"
    }),
    org_name: z.string().min(4,{
        message: "Organization Name is required"
    }),
    location_type: z.string().min(4,{
        message: "Location type is required"
    }),
    location_name: z.string().min(4,{
        message: "Organization location is required"
    }),
    location_code: z.string().min(4,{
        message: "Organization location code is required"
    }).optional(),
})

// org_type = models.CharField(max_length=150)
//     org_name = models.CharField(max_length=250, )
//     location_type = models.CharField(max_length=150, choices=LocationType.choices)
//     location_name = models.CharField(max_length=250)
//     location_code = models.CharField(max_length=150)
// schema for Roles and Permissions Management

// for Roles Form
export const RolesFormSchema = z.object({
    name: z.string().min(1, {
        message: "Role is required"
    }).max(150, "Role name must be at most 150 characters"),
    description: z.string().optional(),
    application: z.string().nonempty({ message: "Application selection is required"}),
    permissions: z.array(z.string()).nonempty({ message: "At least one permission must be selected"}),
    default_for_application: z.boolean().optional(),
});
// for Permission Form

export const PermissionFormSchema = z.object({
    name: z.string().min(4,{
        message: "Permission is required"
    }),
    description: z.string().optional(),
    application:  z.string().min(4,{
        message: "Application is required"
    }),
});

export const PasswordResetRequestFormSchema = z.object({
    username: z.string().min(4,{ 
      message: "Username is required"
    }),
    emp_code: z.string().min(1, { 
      message: "Employee code is required"
    }),
    mobile: z.string().min(10, { 
      message: "Mobile number must be at least 10 characters long"
    }),
});