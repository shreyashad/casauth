"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { getpasswordResetRequest } from "@/lib/auth/auth_api";
import { PasswordResetRequestFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useForm } from "react-hook-form";



export default function PasswordResetRequest() {
    const [formData, setFormData] = useState({
        username: "",
        emp_code: "",
        mobile: "",
    });
    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState("");

    const form = useForm({
        resolver: zodResolver(PasswordResetRequestFormSchema),
        defaultValues: {
            username: "",
            emp_code: "",
            mobile:"",
        },
    });

    const onSubmit = async (values) => {
        const result = await getpasswordResetRequest(values)
    }

    return(
        <Card>
            <CardHeader>
                <CardTitle></CardTitle>
                <CardDescription></CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div>
                        <FormField 
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl>
                                        <Input 
                                            {...field}
                                            placeholder="Enter your Username"

                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="emp_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Employee Code</FormLabel>
                                    <FormControl>
                                        <Input 
                                            {...field}
                                            placeholder="Enter your Username"

                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="mobile"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Mobile</FormLabel>
                                    <FormControl>
                                        <Input 
                                            {...field}
                                            placeholder="Enter your Mobile number"

                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        </div>
                    </form>

                </Form>
            </CardContent>
        </Card>
    );
};