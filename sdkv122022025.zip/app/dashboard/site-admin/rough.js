
import NextAuth, { CredentialsSignin } from "next-auth"
import Credentials from "next-auth/providers/credentials"

// Custom error classes for different scenarios
class InvalidLoginError extends CredentialsSignin {
  code = "invalid_credentials"
}

class PasswordExpiredError extends CredentialsSignin {
  code = "password_expired"
}

class PasswordChangeRequiredError extends CredentialsSignin {
  code = "password_change_required" 
}

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      credentials: {
        username: { label: "Username" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        try {
          // Your existing login logic here
          
          if (!response.ok) {
            const error = await response.json()
            
            // Handle different error scenarios based on status codes
            switch (response.status) {
              case 401:
                throw new InvalidLoginError()
              case 403:
                if (error.error.includes("Password expired")) {
                  throw new PasswordExpiredError()
                }
                if (error.error.includes("Password change required")) {
                  throw new PasswordChangeRequiredError() 
                }
                throw new CredentialsSignin()
              default:
                return null
            }
          }

          return response.json()
        } catch (error) {
          throw error
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.accessToken = user.accessToken
      }
      return token
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken
      return session
    }
  }
})

----------
export const { handlers, signIn, signOut, auth  } = NextAuth({
    secret: process.env.AUTH_SECRET,
    debug: true,
    providers: [
        Credentials({
            name: "credentials", 
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                try {
                    const application = await fetchAuthApplicationDetails();
                    const appId = application.app.id;

                    const loginResponse = await axios.post(`${API_BASE_URL}api/cas-login/`, {
                        username: credentials.username,
                        password: credentials.password,
                        application_id: appId,
                    });
                    console.log("loginResponse:", loginResponse );
                    // if (!loginResponse.ok) {
                    //     const error = await loginResponse

                    //     switch(loginResponse.status)
                    // }



                    const loginData = loginResponse.data;

                    // Validate Ticket API Call
                    const validateTicketResponse = await validateTicket(loginData.service_ticket, appId);

                    
                    const userDetails = validateTicketResponse.data;

                    return {
                        id: userDetails.id || loginData.id,
                        name: `${userDetails.first_name} ${userDetails.last_name}` || userDetails.username,
                        roles: userDetails.roles,
                        permissions: userDetails.permissions,
                        profile_picture: userDetails.profile_picture,
                        first_name: userDetails.first_name,
                        last_name: userDetails.last_name,
                        org_type: userDetails.org_type,
                        org_name: userDetails.org_name,
                        org_sub_type: userDetails.org_sub_type,
                        location_type: userDetails.location_type,
                        location_name: userDetails.location_name,
                        location_code: userDetails.location_code,
                        emp_code: userDetails.emp_code,
                        department: userDetails.department,
                        designation: userDetails.designation,
                        accessToken: loginData.access,
                        refreshToken: loginData.refresh,
                        sessionKey: loginData.session_key,
                        service_ticket: loginData.service_ticket,
                        sessionExp: new Date(loginData.session_expires_at).getTime(),
                    };
                } catch(error) {
                    console.error("Authentication Error:", error);
                    return error
                }
            },
        })
    ],
    pages: {
        signIn: "/login",
    },
    events: {
        async signIn(message) {
            console.log("Sign in attempt", message)
        },
        async signOut(message) {
            console.log("Sign out", message)
        },
        async error(error) {
            console.error("Auth error:", error)
        }
    },
    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            if (user) {
                return true;
            }
            return false; // This will trigger the error page with CredentialsSignin error
        },

        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            if (token.sessionExp && Date.now() > token.sessionExp) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                        refresh: token.refreshToken,
                    });

                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.sessionExp = Date.now() + (60 * 60 * 1000); // Update expiration time
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error);
                    throw new Error("Session expired, please log in again.");
                    // Optionally, you might want to clear the tokens or redirect to sign-in
                }
            }
            return token;
        },
        async session({ session, token }) {
            if (!token || !token.accessToken) {
                // If there's no valid token, handle it as expired
                session.error = "Session expired, please log in again.";
                return session;
            }

            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionKey = token.sessionKey;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            console.log("user session details:", session);
            return session;
        }
    },

    session: {
        strategy: "jwt"
    },
});
-----------
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";

async function authenticateUser(credentials) {
  try {
    const application = await fetchAuthApplicationDetails(); // Assuming this function is defined elsewhere
    const appId = application.app.id;

    const loginResponse = await axios.post(`${API_BASE_URL}api/cas-login/`, {
      username: credentials.username,
      password: credentials.password,
      application_id: appId,
    });

    if (loginResponse.status !== 200) {
      // Handle login errors based on status code
      let errorMessage = "Invalid credentials"; // Default message
      if (loginResponse.data && loginResponse.data.message) {
        errorMessage = loginResponse.data.message;
      } else if (loginResponse.status === 401) {
          errorMessage = "Unauthorized"
      } else if (loginResponse.status === 400) {
          errorMessage = "Bad Request"
      } else if (loginResponse.status === 500) {
          errorMessage = "Internal Server Error"
      }

      throw new Error(errorMessage); // Throw an error to be caught by the try-catch
    }


    const loginData = loginResponse.data;

    const validateTicketResponse = await validateTicket(loginData.service_ticket, appId); // Assuming this function is defined elsewhere

    if (validateTicketResponse.status !== 200) {
      // Handle ticket validation errors
        let errorMessage = "Failed to validate ticket.";
        if(validateTicketResponse.data && validateTicketResponse.data.message){
            errorMessage = validateTicketResponse.data.message;
        }
      throw new Error(errorMessage);
    }

    const userDetails = validateTicketResponse.data;

    return {
      id: userDetails.id || loginData.id,
      name: `${userDetails.first_name} ${userDetails.last_name}` || userDetails.username,
      roles: userDetails.roles,
      permissions: userDetails.permissions,
      profile_picture: userDetails.profile_picture,
      first_name: userDetails.first_name,
      last_name: userDetails.last_name,
      org_type: userDetails.org_type,
      org_name: userDetails.org_name,
      org_sub_type: userDetails.org_sub_type,
      location_type: userDetails.location_type,
      location_name: userDetails.location_name,
      location_code: userDetails.location_code,
      emp_code: userDetails.emp_code,
      department: userDetails.department,
      designation: userDetails.designation,
      accessToken: loginData.access,
      refreshToken: loginData.refresh,
      sessionKey: loginData.session_key,
      service_ticket: loginData.service_ticket,
      sessionExp: new Date(loginData.session_expires_at).getTime(),
    };
  } catch (error) {
    console.error("Authentication Error:", error);
    throw error; // Re-throw the error to be handled by NextAuth
  }
}


export const { handlers, signIn, signOut, auth } = NextAuth({
  // ... other NextAuth options
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        try {
          const user = await authenticateUser(credentials);
          return user;
        } catch (error) {
           // Important: Handle the error appropriately for NextAuth
          console.error("Authorize error:", error);
          throw new Error(error.message || "Authentication failed"); // Or a more generic message
        }
      },
    }),
  ],
  // ... other NextAuth options

    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            if (user) {
                return true;
            }
            return false; // This will trigger the error page with CredentialsSignin error
        },
        // ... other callbacks
    }
});