import { auth } from "@/auth";
import { PieChartCard } from "@/components/common/charts/pie-chart-card";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { CalendarComponent } from "@/components/common/my-calendar";
import { StatsCard } from "@/components/common/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fectchApplicationWiseUserChartData, fetchApplicationCount, fetchOnlineUser } from "@/lib/administrator/dashboard_api";
import { Gamepad, UserRound } from "lucide-react";
import { toast } from "sonner";



export default async function AdministratorPage() {
    const session = await auth();
    console.log("admin session details:", session);
    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }
    const onlineUsers = await fetchOnlineUser(session.accessToken);
    const applicationCount = await fetchApplicationCount(session.accessToken);
    const appwiseChartData = await fectchApplicationWiseUserChartData(session.accessToken);

    const  transformedData = appwiseChartData.map(item => ({
      name: item.application__name,
      value: item.online_count,
    }));
    console.log("transformed data:", transformedData);

    

   
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator/"
                hometitle="Home"
                mdipagelink="/dashboard/administrator/"
                mdipagetitle="Administrator"
                pagetitle="Dashboard"
            />
            <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                    <StatsCard 
                        title="Online users" 
                        value={onlineUsers.online_user}
                        desc="Total currently active users"
                        icon={<UserRound />}
                    />
                    <StatsCard 
                        title="Total Applications"
                        value={applicationCount.apps_count}
                        desc="Total number of application been registered"
                        icon={ <Gamepad /> }

                    />
                    <StatsCard />
                    <StatsCard />
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                    <PieChartCard 
                        title="Users By Application"
                        description="On-line users by applications"
                        data={transformedData}
                        
                    />
                   <CalendarComponent />
                </div>
                <Card>
                    <CardHeader>
                        <CardTitle></CardTitle>
                    </CardHeader>
                </Card>
            </div>
        </div>
    );
}