import { auth } from "@/auth";
import { ApplicationCard } from "@/components/administrator/applications/application-card";
import { PieChartCard } from "@/components/common/charts/pie-chart-card";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { StatsCard } from "@/components/common/stats-card";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { fetchApplicationListData } from "@/lib/administrator/applications_api";

export default async function ApplicationsDashboardManagementPage() {
    const session = await auth();
    
    const appData = await fetchApplicationListData(session.accessToken);
        return(
                <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                    <DashboradBreadCrumb 
                        homelink="/dashboard/administrator"
                        hometitle="Applications Dashboard"
                        mdipagelink="/dashboard/administrator/dashboard/application"
                        mdipagetitle="Applications Management Dashboard"
                        pagetitle="Applications"
                    />
                    <div className="space-y-6">
                        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                            <StatsCard 
                            title="Total Requests"
                            desc="Total number of request across all applications for today"
                            />
                            <StatsCard 
                                title="Average Response Time"
                                desc="Average Response Time across all applications for today"

                            />
                            <StatsCard 
                                title="Total Logs"
                                desc="Average Response Time across all applications for today"
                            />
                            <StatsCard 
                                title="CPU/Memory/Disk Usage "
                                desc="aggregated usage across all applications for today "
                            />
                        </div>
                    </div>
                    <h2 className="text-xl font-semibold text-gray-800">Applications</h2>
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                        {appData.map((app) => (
                            <ApplicationCard
                                key={app.id}
                                id={app.id}
                                name={app.name}
                                base_url={app.base_url}
                                status={app.active}
                                des={app.description}
                                
                            />
                        ))}
                    </div>
                </div>
                    
            );
    
};