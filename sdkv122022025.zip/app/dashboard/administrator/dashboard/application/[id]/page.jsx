import { auth } from "@/auth";
import { AreaLineCardCard } from "@/components/common/charts/area-line-chart-card";
import { BarChartCard } from "@/components/common/charts/bar-chart-card";
import { LineChartCard } from "@/components/common/charts/line-chart-card";
import { MultiLineChartCard } from "@/components/common/charts/multi-line-chart-card";
import { ResourceUsageChart } from "@/components/common/charts/pie-bar-chart-card";
import { PieChartCard } from "@/components/common/charts/pie-chart-card";
import { PieChartCardWithOutTable } from "@/components/common/charts/pie-chart-withouttable-card";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { StatsCard } from "@/components/common/stats-card";
import { fetchApplicationDetails } from "@/lib/administrator/applications_api";
import { fetchAnomalies, fetchApplicationDetailMetrix, fetchCurrentResourceUsage, fetchErrorTrends, fetchRequestMethodDistribution, fetchStatusCodeDistribution, fetchTotalRequestsOverTime } from "@/lib/administrator/logs_reports_api";
import { format } from "date-fns";

export default async function ApplicationDashboardPage ({ params }) {
    const session = await auth();
    const { id } = params;
    const appDetails = await fetchApplicationDetails(id, session.accessToken);
    const appMetrix = await fetchApplicationDetailMetrix(id, session.accessToken);
    const totalRequestsOverTime = await fetchTotalRequestsOverTime(id, session.accessToken);
    const formattedDataTotalOverTime = totalRequestsOverTime.map((item) => ({
        name: format(new Date(item.time_bucket), "MMM d"), // Format date as "Jan 10"
        value: item.total_requests, // Map total_requests to value
    }));

    const statusCodeData = await fetchStatusCodeDistribution(id, session.accessToken);
    const requestMethodData = await fetchRequestMethodDistribution(id, session.accessToken);
    const  transformedrequestMethodData = requestMethodData.map(item => ({
        name: item.method,
        value: item.request_count,
      }));

    const errorTrendsData = await fetchErrorTrends(id, session.accessToken);
    const formattederrorTrendsData = errorTrendsData.map((item) => ({
        name: format(new Date(item.day), "MMM d"), // Format date as "Jan 10"
        value: item.error_count, // Map total_requests to value
    }));

    const currentResourceUsageData = await fetchCurrentResourceUsage(id, session.accessToken);
    

    const anomaliesData = await fetchAnomalies(id, session.accessToken);
    const formattedanomaliesDataData = anomaliesData.map((entry) => ({
        time: new Date(entry.timestamp).toLocaleTimeString(), // Format timestamp as readable time
        cpu: entry.cpu_usage,
        memory: entry.memory_usage,
        disk: entry.disk_usage,
    }));

    console.log("currentResourceUsageData data:",formattedanomaliesDataData );
    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator"
                hometitle="Applications Dashboard"
                mdipagelink="/dashboard/administrator/dashboard/application"
                mdipagetitle="Applications Management Dashboard"
                pagetitle={`${appDetails.name} Applications `}
            />
            <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                    <StatsCard 
                        title="Total Requests"
                        desc="Total number of request for today"
                        value={appMetrix.total_requests}
                    />
                    <StatsCard 
                        title="Average Response Time"
                        desc="Average Response Time  for today"
                        value={appMetrix.avg_response_time}

                    />
                    <StatsCard 
                        title="Total Logs"
                        desc="Average Response Time for today"
                        value={appMetrix.total_logs}
                    />
                    <StatsCard 
                        title="CPU/Memory/Disk Usage "
                        desc="Memory usage"
                        value={`CPU: ${appMetrix.system_metrics.cpu_usage}% | Memory: ${appMetrix.system_metrics.memory_usage}% | Disk: ${appMetrix.system_metrics.disk_usage}%`}
                    />
                </div>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <LineChartCard 
                        title="Total Requests Over Time"
                        description="Line chart of requests over time"
                        data={formattedDataTotalOverTime}
                        color="#8884d8"
                    />
                    <BarChartCard 
                        title="Status Code Distribution"
                        description="Bar chart showing the distribution of status codes"
                        data={statusCodeData}
                        color="#82ca9d"
                    />
                    <PieChartCardWithOutTable 
                         title="Request Method Distribution"
                         description="Pie chart showing the distribution of HTTP methods"
                         data={transformedrequestMethodData}
                    />
                </div>
                <div className="grid grid-cols-3 grid-rows-2 gap-4">
                    <LineChartCard 
                        title="Error Trends Over Time"
                        description="Line chart showing daily error trends"
                        data={formattederrorTrendsData}
                        color="#8884d8"
                    />
                    <div className="col-span-2 row-span-2">
                    <ResourceUsageChart 
                        title="System Resource Usage"
                        description="Overview of CPU, Memory, Disk usage and trends over time"
                        chartData={currentResourceUsageData}
                       
                    />
                    </div>
                    <div className="row-start-2">
                        <AreaLineCardCard 
                          title="Anomaly Detection"
                          description="This chart represents detected anomalies in CPU, Memory, and Disk usage over time."
                          data={formattedanomaliesDataData}
                          
                        areas={[
                            { dataKey: "memory", color: "#36A2EB", fillColor: "rgba(54,162,235,0.3)", name: "Memory Usage" },
                            { dataKey: "disk", color: "#4BC0C0", fillColor: "rgba(75,192,192,0.3)", name: "Disk Usage" },
                            { dataKey: "cpu", color: "#FF6384", name: "CPU Usage" }
                        ]}
                        
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}