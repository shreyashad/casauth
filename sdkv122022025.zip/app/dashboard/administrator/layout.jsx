"use client";
import HeaderComponent from "@/components/layout/header";
import SidebarComponent from "@/components/layout/sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";


export default function AdministratorLayout({ children }) {
        
    return(
        <SidebarProvider>
            <SidebarComponent dashboardType="Administrator" />
            <SidebarInset>
                <HeaderComponent />
                <main>
                    {children}
                </main>
            </SidebarInset>
        </SidebarProvider>
    );
};




