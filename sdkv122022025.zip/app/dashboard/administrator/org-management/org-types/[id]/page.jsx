import { auth } from "@/auth";
import { OrgTypeForm } from "@/components/administrator/organization-management/orgtype/orgtype-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchOrgTypeDeatils } from "@/lib/administrator/org_api";

function getOrgTypeId(data) {
    try {
        return decodeURIComponent(data);
    } catch(error) {
        console.error('Failed to decode app Id')
        return data;
    }
};

export default async function EditOrgType({ params }) {
    const { id } = params;
    console.log("params details: ", id);
    const session = await auth();
    
    if (!session){
        redirect("/login");
        return;
    }

    

    let initialData = null;
    if (id === "new") {
       initialData = {} ;
    } else {
        const OrgId = getOrgTypeId(id);
        initialData = await fetchOrgTypeDeatils(OrgId, session.accessToken);
    }

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator/"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/org-management/"
                mdipagetitle="Organization Management"
                pagetitle="Organization Type"
            />
            <OrgTypeForm initialData={initialData || {}} />
        </div>
        
    );
};