import { auth } from "@/auth";
import { LocationClient } from "@/components/administrator/organization-management/location/location-client";
import { LocationColumns } from "@/components/administrator/organization-management/location/location-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { Toast, ToastAction, ToastDescription, ToastProvider, ToastTitle } from "@/components/ui/toast";
import { fetchLocationListData } from "@/lib/administrator/org_api";



export default async function LocationManagementPage() {
    const session = await auth();

    if (!session) {
        redirect("/login");
        return;
    }
   

    try {

        const locationData = await fetchLocationListData(session.accessToken);
        console.log("location data:", locationData);
        return(
            <ToastProvider>
                <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                    <DashboradBreadCrumb 
                        homelink="/dashboard/administrator"
                        hometitle="Dashboard"
                        mdipagelink="/dashboard/administrator/org-management/locations"
                        mdipagetitle="Organization Management"
                        pagetitle="Location"
                    />
                    <LocationClient />
                    <Separator />
                    <DataTable 
                        data={locationData}
                        columns={LocationColumns}
                        globalFilterColumnId="org_name"
                    />
                </div>
            </ToastProvider>
        );

    } catch (error) {
        const handleError = () => {
            if (error.response) {
                // Handling different HTTP errors
                if (error.response.status === 403) {
                    return {
                        title: "Permission Denied",
                        description: "You do not have permission to view this page.",
                    };
                } else {
                    return {
                        title: `Error: ${error.response.status}`,
                        description: `Status: ${error.response.statusText}`,
                    };
                }
            } else if (error.request) {
                // Network error
                return {
                    title: "Network Error",
                    description: "Unable to reach the server. Please try again later.",
                };
            } else {
                // Unexpected errors
                return {
                    title: "Unexpected Error",
                    description: error.message || "Something went wrong.",
                };
            }
        };

        const { title, description } = handleError();

        return (
            <ToastProvider>
                <div className="flex justify-center items-center">
                    {/* Unauthorized Error Card */}
                    <UnauthorizedErrorCard message={description} redirectUrl="/dashboard/administrator" />

                    {/* Shadcn Toast Notification */}
                    <Toast>
                        <ToastTitle>{title}</ToastTitle>
                        <ToastDescription>{description}</ToastDescription>
                        <ToastAction altText="Dismiss">Dismiss</ToastAction>
                    </Toast>
                </div>
            </ToastProvider>
        );
    
    }
};