import { auth } from "@/auth";
import { LocationForm } from "@/components/administrator/organization-management/location/location-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { Toast, ToastAction, ToastDescription, ToastProvider, ToastTitle } from "@/components/ui/toast";
import { fetchLocationDetails, fetchLocationListData, fetchOrgTypeListData } from "@/lib/administrator/org_api";
import { redirect } from "next/navigation";

function getLocId(data) {
    try {
        return decodeURIComponent(data);
    } catch(error) {
        console.error('Failed to decode app Id')
        return data;
    }
};

export default async function EditLocation({ params }) {
    const { id } = params;
    const session = await auth();

    if (! session ) {
        redirect("/login")
        return;
    }

    try {
       
        const orgTypeData = await fetchOrgTypeListData(session.accessToken);
        console.log("org Typedata for location:", orgTypeData);

        let initialData = null;

        
        if (id === "new") {
            initialData = {};
        } else {
            const locId = getLocId(id);
            initialData = await fetchLocationDetails(locId, session.accessToken);
        }
        
        
        return (
            <ToastProvider>
                <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                    <DashboradBreadCrumb 
                        homelink="administrator/dashboard"
                        hometitle="Dashboard"
                        mdipagelink="administrator/org-management/location"
                        mdipagetitle="Organization  Management"
                        pagetitle="Location"
                    />
                    <LocationForm initialData={initialData} orgTypedata={orgTypeData} />
                </div>
            </ToastProvider>
        );
    } catch (error) {
        const handleError = () => {
            if (error.response) {
                // Handling different HTTP errors
                if (error.response.status === 403) {
                    return {
                        title: "Permission Denied",
                        description: "You do not have permission to view this page.",
                    };
                } else {
                    return {
                        title: `Error: ${error.response.status}`,
                        description: `Status: ${error.response.statusText}`,
                    };
                }
            } else if (error.request) {
                // Network error
                return {
                    title: "Network Error",
                    description: "Unable to reach the server. Please try again later.",
                };
            } else {
                // Unexpected errors
                return {
                    title: "Unexpected Error",
                    description: error.message || "Something went wrong.",
                };
            }
        };

        const { title, description } = handleError();

        return (
            <ToastProvider>
                <div className="flex justify-center items-center">
                    <UnauthorizedErrorCard message={description} redirectUrl="/dashboard/administrator" />
                    <Toast>
                        <ToastTitle>{title}</ToastTitle>
                        <ToastDescription>{description}</ToastDescription>
                        <ToastAction altText="Dismiss">Dismiss</ToastAction>
                    </Toast>
                </div>
            </ToastProvider>
        );
    }
};