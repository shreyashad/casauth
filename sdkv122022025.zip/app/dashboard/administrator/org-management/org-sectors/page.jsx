import { auth } from "@/auth";
import { SectorClient } from "@/components/administrator/organization-management/sector/sector-client";
import { SectorColumns } from "@/components/administrator/organization-management/sector/sector-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { DataTable } from "@/components/ui/data-table/data-table";

import { Separator } from "@/components/ui/separator";
import { fetchOrganizationSectorListData } from "@/lib/administrator/org_api";


export default async function OrgSectorManagementPage() {
    const session = await auth();

    if (!session) {
        redirect("/login");
        return;
    }


    try{
        const sectorData = await fetchOrganizationSectorListData(session.accessToken);
        return (
            <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                <DashboradBreadCrumb 
                    homelink="/dashboard/administrator"
                    hometitle="Dashboard"
                    mdipagelink="/dashboard/administrator/org-management/org-sectors"
                    mdipagetitle="Organization Management"
                    pagetitle="Organization Sectors"
                />
                <SectorClient />
                <Separator />
                <DataTable 
                    data={sectorData}
                    columns={SectorColumns}
                    globalFilterColumnId="name"
                />
            </div>
        );
    } catch (error) {
        return <UnauthorizedErrorCard message="You do not have permission to view this page." redirectUrl="/dashboard/administrator"/>
    }
};