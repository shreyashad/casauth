import { auth } from "@/auth";
import { SectorForm } from "@/components/administrator/organization-management/sector/sector-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchSectorDeatils } from "@/lib/administrator/org_api";

function getSectorId(data) {
    try {
        return decodeURIComponent(data);
    } catch(error) {
        console.error('Failed to decode app Id')
        return data;
    }
};

export default async function EditSector({ params }) {
    const  { id } = params;
    const session = await auth();
    
    if (!session){
            redirect("/login");
            return;
    }
    
        
    
    let initialData = null;
    if (id === "new") {
        initialData = {} ;
    } else {
        const SectorId = getSectorId(id);
        initialData = await fetchSectorDeatils(SectorId, session.accessToken);
    }
    
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator/"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/org-management/"
                mdipagetitle="Organization Management"
                pagetitle="Sector"
            />
            <SectorForm initialData={initialData || {}} />
        </div>
    );
};