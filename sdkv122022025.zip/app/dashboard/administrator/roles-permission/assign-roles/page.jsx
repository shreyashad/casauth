import { auth } from "@/auth";
import { UserRoleColumns } from "@/components/administrator/roles-permission/user-roles/user-roles-column";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchAssignedUserRoleList } from "@/lib/administrator/rolesPermission_api";

export default async function AssignUserRoleManagementPage() {
    const session = await auth();
    const userRolesListData = await fetchAssignedUserRoleList(session.accessToken);

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/assigned-role/"
                mdipagetitle="Roles & Permission Management"
                pagetitle="User Roles "
            />
               
                <Separator />
                <DataTable 
                    data={userRolesListData}
                    columns={UserRoleColumns}
                    globalFilterColumnId="user"
                    facetedFilters={user}
        
                />
        </div>
    );
};