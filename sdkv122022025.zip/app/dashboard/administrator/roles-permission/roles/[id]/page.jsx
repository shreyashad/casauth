import { auth } from "@/auth";
import { RolesForm } from "@/components/administrator/roles-permission/roles-management/roles-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchApplicationListData } from "@/lib/administrator/applications_api";
import { fetchRoleDetails } from "@/lib/administrator/rolesPermission_api";
import { redirect } from "next/navigation"; // Adjusted import for redirect

export default async function EditRoles({ params }) {
    const { id } = params; // No need for await here
    const session = await auth();

    if (!session) {
        redirect("/login");
        return; // Ensure to return after redirect
    }

    let initialData = null;
    if (id) {
        // Fetch existing roles for edit
        try {
            initialData = await fetchRoleDetails(session.accessToken, id);
            console.log("initialData for selected role:", initialData);
        } catch (error) {
            console.error("Error fetching roles:", error);
            // Optionally handle the error (e.g., show a message)
        }
    }
    
    const appData = await fetchApplicationListData(session.accessToken);

    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/roles"
                mdipagetitle="Roles & Permission Management"
                pagetitle="Roles"
            />
            <RolesForm initialData={initialData} appData={appData} />
        </div>
    );
}