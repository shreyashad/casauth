import { auth } from "@/auth";
import { OrganizationClient } from "@/components/administrator/organization-management/organization/organization-client";
import { OrganizationColumns } from "@/components/administrator/organization-management/organization/organization-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { Toast, ToastAction, ToastDescription, ToastProvider, ToastTitle } from "@/components/ui/toast";
import { fetchOrganizationListData } from "@/lib/administrator/org_api";



export default async function UserAccountPage() {
    const session = await auth();

    if (!session) {
        redirect("/login");
        return;
    }


    try{
        const orgData = await fetchOrganizationListData(session.accessToken);

        const facetedFilters = [
            {
            id: "org_type",
            title: "Organization Type",
            options: [
                { label: "MDIndia", value: "MDIndia" },
                { label: "Insurance Company", value: "Insurance Company" },
                { label: "Broker", value: "Broker"},
                { label: "Corporate", value: "Corporate"}
            ],
            },
        
        ];
    
        return(
            <ToastProvider>
                <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                    <DashboradBreadCrumb 
                        homelink="/dashboard/administrator"
                        hometitle="Dashboard"
                        mdipagelink="/dashboard/administrator/org-management/organization"
                        mdipagetitle="Organization Management"
                        pagetitle="Organization"
                    />
                    <OrganizationClient />
                    <Separator />
                    <DataTable 
                        data={orgData}
                        columns={OrganizationColumns}
                        globalFilterColumnId="name"
                        facetedFilters={facetedFilters}
            
                    />
                </div>
            </ToastProvider>
        );
    } catch (error) {
        // Error Handling
        const handleError = () => {
            if (error.response) {
                // Handling different HTTP errors
                if (error.response.status === 403) {
                    return {
                        title: "Permission Denied",
                        description: "You do not have permission to view this page.",
                    };
                } else {
                    return {
                        title: `Error: ${error.response.status}`,
                        description: `Status: ${error.response.statusText}`,
                    };
                }
            } else if (error.request) {
                // Network error
                return {
                    title: "Network Error",
                    description: "Unable to reach the server. Please try again later.",
                };
            } else {
                // Unexpected errors
                return {
                    title: "Unexpected Error",
                    description: error.message || "Something went wrong.",
                };
            }
        };

        const { title, description } = handleError();

        return (
            <ToastProvider>
                <div className="flex justify-center items-center">
                    {/* Unauthorized Error Card */}
                    <UnauthorizedErrorCard message={description} redirectUrl="/dashboard/administrator" />

                    {/* Shadcn Toast Notification */}
                    <Toast>
                        <ToastTitle>{title}</ToastTitle>
                        <ToastDescription>{description}</ToastDescription>
                        <ToastAction altText="Dismiss">Dismiss</ToastAction>
                    </Toast>
                </div>
            </ToastProvider>
        );
    }
    
};