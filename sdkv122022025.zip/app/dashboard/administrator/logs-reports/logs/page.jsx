import { auth } from "@/auth";
import { LogsColumns } from "@/components/administrator/logs-reports/logs-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import UnauthorizedErrorCard from "@/components/common/unathorized-card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { Toast, ToastAction, ToastDescription, ToastProvider, ToastTitle } from "@/components/ui/toast";
import { fetchlogslistData } from "@/lib/administrator/logs_reports_api";



export default async function LogManagementPage() {
    const session = await auth();

    if (!session) {
        redirect("/login");
        return;
    }

    try {
        const logData = await fetchlogslistData(session.accessToken);

        return(
            <ToastProvider>
            <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                <DashboradBreadCrumb 
                    homelink="/dashboard/administrator"
                    hometitle="Dashboard"
                    mdipagelink="/dashboard/administrator/logs-reports/logs"
                    mdipagetitle="Logs & Reports Management"
                    pagetitle="Logs"
                />
                
                <Separator />
                
                <DataTable 
                    data={logData}
                    columns={LogsColumns}
                    globalFilterColumnId=""
                    

                />
                
            </div>
            </ToastProvider>
        );
    } catch (error) {
        const handleError = () => {
            if (error.response) {
                // Handling different HTTP errors
                if (error.response.status === 403) {
                    return {
                        title: "Permission Denied",
                        description: "You do not have permission to view this page.",
                    };
                } else {
                    return {
                        title: `Error: ${error.response.status}`,
                        description: `Status: ${error.response.statusText}`,
                    };
                }
            } else if (error.request) {
                // Network error
                return {
                    title: "Network Error",
                    description: "Unable to reach the server. Please try again later.",
                };
            } else {
                // Unexpected errors
                return {
                    title: "Unexpected Error",
                    description: error.message || "Something went wrong.",
                };
            }
        };

        const { title, description } = handleError();

        return (
            <ToastProvider>
                <div className="flex justify-center items-center">
                    {/* Unauthorized Error Card */}
                    <UnauthorizedErrorCard message={description} redirectUrl="/dashboard/administrator" />

                    {/* Shadcn Toast Notification */}
                    <Toast>
                        <ToastTitle>{title}</ToastTitle>
                        <ToastDescription>{description}</ToastDescription>
                        <ToastAction altText="Dismiss">Dismiss</ToastAction>
                    </Toast>
                </div>
            </ToastProvider>
        );
    }
};