import NextAuth, { CredentialsSignin } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { doCrendentialLogin, fetchAuthApplicationDetails, validateTicket } from "./lib/auth/auth_api";
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";



const errorClasses = {};

function createCustomErrorClass(errorCode, errorMessage) {
    if (!errorClasses[errorCode]) {
        errorClasses[errorCode] = class extends CredentialsSignin {
            constructor(message) {
                super(message);
                this.code = errorCode; // Set the code property
            }
        };
    }
    return errorClasses[errorCode];
}


async function authenticateUser(credentials) {
    try {
        const application = await fetchAuthApplicationDetails();
        const appId = application.app.id;
        const loginData = await doCrendentialLogin(credentials, appId);
        const userDetails  = await validateTicket(loginData.service_ticket, appId);
        if (!userDetails || !loginData) {
            const InvalidCredentialsError = createCustomErrorClass("invalid_credentials", "Invalid username or password");
            throw new InvalidCredentialsError();
        }
        return {
            id: userDetails.id || loginData.id,
            name: `${userDetails.first_name} ${userDetails.last_name}` || userDetails.username,
            roles: userDetails.roles,
            permissions: userDetails.permissions,
            profile_picture: userDetails.profile_picture,
            first_name: userDetails.first_name,
            last_name: userDetails.last_name,
            org_type: userDetails.org_type,
            org_name: userDetails.org_name,
            org_sub_type: userDetails.org_sub_type,
            location_type: userDetails.location_type,
            location_name: userDetails.location_name,
            location_code: userDetails.location_code,
            emp_code: userDetails.emp_code,
            department: userDetails.department,
            designation: userDetails.designation,
            accessToken: loginData.access,
            refreshToken: loginData.refresh,
            sessionKey: loginData.session_key,
            service_ticket: loginData.service_ticket,
            sessionExp: new Date(loginData.session_expires_at).getTime(),
          };

      
    } catch (error) {
        console.error("Authentication Error:", error);
         // Dynamic error handling based on status codes or other conditions:
         if (error.response?.status === 401) {
            const InvalidCredentialsError = createCustomErrorClass("invalid_credentials", "Invalid username or password");
            throw new InvalidCredentialsError();
        } else if (error.response?.status === 403) {
            const ExpiredPasswordError = createCustomErrorClass("password_expired", "Password expired");
            throw new ExpiredPasswordError();
        } else if (error.response?.status === 400) {  // Example: Handle 400 Bad Request
            const BadRequestError = createCustomErrorClass("bad_request", error.response.data?.error || "Bad Request"); // Get error from backend if available
            throw BadRequestError();
        } else if (error instanceof CredentialsSignin) { // Check if it is already CredentialsSignin error
            throw error;
        } else {
            const ServiceError = createCustomErrorClass("service_unavailable", error.message || "Service unavailable"); // Use error.message or default
            throw ServiceError();
        }
    }
}


export const { handlers, signIn, signOut, auth  } = NextAuth({
    secret: process.env.AUTH_SECRET,
    debug: true,
    providers: [
        Credentials({
            name: "credentials", 
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                try{
                    const user = await authenticateUser(credentials);
                    return user;
                } catch(error) {
                    console.error("authorize Error:", error);
                    
                    return null;
                }
            },
        })
    ],
    pages: {
        signIn: "/login",
    },
    events: {
        async signIn(message) {
            console.log("Sign in attempt", message)
        },
        async signOut(message) {
            console.log("Sign out", message)
        },
        async error(error) {
            console.error("Auth error:", error)
        }
    },
    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            if (user) {
                return true;
            }
            return false; // This will trigger the error page with CredentialsSignin error
        },

        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            if (token.sessionExp && Date.now() > token.sessionExp) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                        refresh: token.refreshToken,
                    });

                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.sessionExp = Date.now() + (60 * 60 * 1000); // Update expiration time
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error);
                    throw new Error("Session expired, please log in again.");
                    // Optionally, you might want to clear the tokens or redirect to sign-in
                }
            }
            return token;
        },
        async session({ session, token }) {
            if (!token || !token.accessToken) {
                // If there's no valid token, handle it as expired
                session.error = "Session expired, please log in again.";
                return session;
            }

            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionKey = token.sessionKey;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            console.log("user session details:", session);
            return session;
        }
    },

    session: {
        strategy: "jwt"
    },
});