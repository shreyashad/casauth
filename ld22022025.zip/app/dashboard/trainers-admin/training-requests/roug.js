"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Inbox, Send, Calendar as CalendarIcon, Users, PlusCircle, Clock, MapPin } from "lucide-react"
import { cn } from "@/lib/utils"

export default function TrainingRequestSystem() {
  const [activeView, setActiveView] = useState("inbox")
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [requests, setRequests] = useState([
    { id: 1, from: "John Doe", subject: "React Training", status: "Pending", content: "We need a React training session for the frontend team." },
    { id: 2, from: "Jane Smith", subject: "Python Workshop", status: "Scheduled", content: "Requesting a Python workshop for the data science team." },
  ])

  const handleRequestSubmit = (e) => {
    e.preventDefault()
    const newRequest = {
      id: requests.length + 1,
      from: "Current User",
      subject: e.target.subject.value,
      content: e.target.content.value,
      status: "Pending"
    }
    setRequests([newRequest, ...requests])
    setActiveView("inbox")
  }

  const handleScheduleTraining = (requestId) => {
    setRequests(requests.map(req => 
      req.id === requestId ? {...req, status: "Scheduled"} : req
    ))
  }

  const NavItem = ({ icon: Icon, label, view }) => (
    <button
      className={cn(
        "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-accent rounded-md",
        activeView === view && "bg-accent"
      )}
      onClick={() => setActiveView(view)}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </button>
  )

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r p-4 flex flex-col">
        <h1 className="text-2xl font-bold mb-6">Training Requests</h1>
        <nav className="space-y-2">
          <NavItem icon={Inbox} label="Inbox" view="inbox" />
          <NavItem icon={Send} label="Sent" view="sent" />
          <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
          <NavItem icon={Users} label="Trainers" view="trainers" />
        </nav>
        <Button className="mt-auto" onClick={() => setActiveView("compose")}>
          <PlusCircle className="mr-2 h-4 w-4" /> New Request
        </Button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Request List */}
        <div className="w-1/3 border-r p-4 overflow-auto">
          <h2 className="text-xl font-semibold mb-4">
            {activeView === "inbox" ? "Incoming Requests" : 
             activeView === "sent" ? "Sent Requests" :
             activeView === "scheduled" ? "Scheduled Trainings" :
             activeView === "trainers" ? "Available Trainers" : ""}
          </h2>
          {requests.map(request => (
            <div
              key={request.id}
              className={cn(
                "p-2 border-b cursor-pointer hover:bg-accent",
                selectedRequest?.id === request.id && "bg-accent"
              )}
              onClick={() => setSelectedRequest(request)}
            >
              <div className="font-semibold">{request.from}</div>
              <div className="text-sm text-muted-foreground">{request.subject}</div>
              <div className="text-xs text-muted-foreground">{request.status}</div>
            </div>
          ))}
        </div>

        {/* Request Details / Compose */}
        <div className="flex-1 p-4 overflow-auto">
          {activeView === "compose" ? (
            <Card>
              <CardHeader>
                <CardTitle>New Training Request</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRequestSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" name="subject" required />
                  </div>
                  <div>
                    <Label htmlFor="content">Description</Label>
                    <Textarea id="content" name="content" required rows={5} />
                  </div>
                  <Button type="submit">Send Request</Button>
                </form>
              </CardContent>
            </Card>
          ) : selectedRequest ? (
            <div>
              <h2 className="text-2xl font-semibold mb-4">{selectedRequest.subject}</h2>
              <div className="mb-4">
                <span className="font-semibold">From:</span> {selectedRequest.from}
              </div>
              <div className="mb-4">
                <span className="font-semibold">Status:</span> {selectedRequest.status}
              </div>
              <div className="mb-4">{selectedRequest.content}</div>
              {selectedRequest.status === "Pending" && activeView === "inbox" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Schedule Training</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="trainer">Select Trainer</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Trainer" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="john">John Doe</SelectItem>
                            <SelectItem value="jane">Jane Smith</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Select Date</Label>
                        <Calendar className="rounded-md border" />
                      </div>
                      <div>
                        <Label htmlFor="time">Select Time</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Time" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="9am">9:00 AM</SelectItem>
                            <SelectItem value="10am">10:00 AM</SelectItem>
                            <SelectItem value="11am">11:00 AM</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="room">Select Room</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Room" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="room1">Training Room 1</SelectItem>
                            <SelectItem value="room2">Training Room 2</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button onClick={() => handleScheduleTraining(selectedRequest.id)}>
                        Confirm Schedule
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              Select a request to view details
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

-------
// pages/training-requests.jsx

import { Sidebar } from "@/components/Sidebar"
import { RequestList } from "@/components/RequestList"
import { RequestDetails } from "@/components/RequestDetails"
import { NewRequestForm } from "@/components/NewRequestForm"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export default function TrainingRequestSystem({ initialRequests }) {
  const [activeView, setActiveView] = useState("inbox")
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [requests, setRequests] = useState(initialRequests)

  const handleRequestSubmit = (newRequest) => {
    setRequests([newRequest, ...requests])
    setActiveView("inbox")
  }

  const handleScheduleTraining = (requestId) => {
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: "Scheduled" } : req
    ))
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div className="flex-1 flex">
        {/* Request List */}
        <div className="w-1/3 border-r p-4 overflow-auto">
          <h2 className="text-xl font-semibold mb-4">
            {activeView === "inbox" ? "Incoming Requests" :
              activeView === "sent" ? "Sent Requests" :
              activeView === "scheduled" ? "Scheduled Trainings" :
              activeView === "trainers" ? "Available Trainers" : ""}
          </h2>
          {/* If there are no requests, display a "No Requests" message */}
          {requests.length === 0 ? (
            <div className="text-center text-muted-foreground">
              No requests available. You can create a new request or check back later.
            </div>
          ) : (
            <RequestList
              requests={requests}
              setSelectedRequest={setSelectedRequest}
              selectedRequest={selectedRequest}
            />
          )}
        </div>

        {/* Request Details / Compose */}
        <div className="flex-1 p-4 overflow-auto">
          {activeView === "compose" ? (
            <NewRequestForm onSubmit={handleRequestSubmit} />
          ) : selectedRequest ? (
            <RequestDetails request={selectedRequest} onScheduleTraining={handleScheduleTraining} />
          ) : (
            <div className="text-center text-muted-foreground">
              Select a request to view details
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export async function getServerSideProps() {
  // Fetch requests data from your server or API
  const res = await fetch("https://api.example.com/requests")
  const initialRequests = await res.json()

  return {
    props: {
      initialRequests: initialRequests.length > 0 ? initialRequests : [],
    },
  }
}
