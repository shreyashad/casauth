import { fetchAnnouncementCategoryListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import AnnouncementCategoryClient from "@/components/trainers-admin/announcement-category/announcement-category-client";
import { AnnouncementCategoryColumns } from "@/components/trainers-admin/announcement-category/announcement-category-columns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function AnnouncementCategoryPage() {
    const session = await auth();
    const announceCateData = await fetchAnnouncementCategoryListData(session.accessToken);

    return(
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/announcement-management/category" 
                    mdipagetitle="Announcement Management" 
                    pagetitle="Category"
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Announcement Category</CardTitle>
                    <div className="justify-center space-2">
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your Announcement Category in one place.
                        
                    </CardDescription>
                    <AnnouncementCategoryClient />
                    </div>
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={AnnouncementCategoryColumns} data={announceCateData} />
                </CardContent>
            </Card>
        </div>
    );
}