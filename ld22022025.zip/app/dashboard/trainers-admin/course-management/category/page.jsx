import { fetchCategoryData } from "@/app/api/server/route";
import { auth } from "@/auth";
import CourseCategoryClient from "@/components/course/course-category-client";
import { CourseCategoryColumns } from "@/components/course/course-category-columns";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";

export default async function CourseCategoryPage() {
    const session = await auth();
    const categoryData = await fetchCategoryData(session.accessToken);
    console.log("category details:", categoryData);
    
    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/course-management/category" 
                    mdipagetitle="Course Management" 
                    pagetitle="Course Category"
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Course Category</CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your courses category in one place.
                        <CourseCategoryClient />
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={CourseCategoryColumns} data={categoryData} />
                </CardContent>
            </Card>
        </div>
    );
}
