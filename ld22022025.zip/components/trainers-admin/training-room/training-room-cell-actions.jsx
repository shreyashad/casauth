"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useSession } from "next-auth/react";
import toast from "react-hot-toast";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { deleteTrainingRoomDetails } from "@/app/api/server/route";


export function TrainingRoomCellAction({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlterModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/trainers-admin/training-management/training-rooms/${data.id}`);
    };

    const deleteTrainingRoom = async () => {
        try{
            await deleteTrainingRoomDetails(session.accessToken, data.id);
            toast.success("Announcement Category Deleted successfully");
            setAlterModalOpen(false);
            router.refresh();
        } catch (error) {
            toast.error("Error deleting Training Room");
        }
    };

    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Training Room</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={() => setAlterModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Training Room</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlterModalOpen(false)}
                onConfirm={() => deleteTrainingRoom(data.id)}
                loading={false}
            />

        </div>
    );
};