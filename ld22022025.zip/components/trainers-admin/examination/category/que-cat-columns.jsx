"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { QuestionTypeCellAction } from "./que-cat-cell-action";



export const QuestionTypeColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Name"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.name }</div>;
      }
        
       
    
    },
    {
        accessorKey: "description",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Descriptions"} />
    },
    

    {
        id: "actions",
        enableSorting: false,
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Actions"} />,
        cell: ({ row }) => <QuestionTypeCellAction data={row.original} />,
    },
];