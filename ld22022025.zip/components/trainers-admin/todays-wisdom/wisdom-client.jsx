"use client";

import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";





const TodaysWisdomClient = () => {
    const router = useRouter();
    return(
        <>
        
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/todays-wisdom/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Create New Topic
                </Button>
           
        
        </>
    );
}
export default TodaysWisdomClient;