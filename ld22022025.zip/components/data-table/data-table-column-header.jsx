"use client";
import { cn } from "@/lib/utils";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../dropdown-menu";
import { Button } from "../button";
import { ArrowDown, ArrowUp, ChevronsUpDown, EyeOff } from "lucide-react";


export function DataTableColumnHeader({ column, title, className }) {
    if (!column.getCanSort()) {
        return <div className={cn(className)}>{title}</div>
    }

    const handleSort = (direction) => {
        if (column.id === "date") {
            column.toggleSorting(direction === 'asc');
        } else if  (column.id === 'numeric') {
            column.toggleSorting(direction === 'asc');
        } else {
            column.toggleSorting(direction === 'asc');
        }
    };


    return(
        <div className={cn("flex items-center space-x-2", className)}>
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                <Button
                    variant="ghost"
                    size="sm"
                    className="-ml-3 h-8 data-[state=open]:bg-accent"
                >
                    <span>{title}</span>
                    {column.getIsSorted() === "desc" ? (
                    <ArrowDown />
                    ) : column.getIsSorted() === "asc" ? (
                    <ArrowUp />
                    ) : (
                    <ChevronsUpDown />
                    )}
                </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => handleSort('asc')}>
                    <ArrowUp className="h-3.5 w-3.5 text-muted-foreground/70" />
                    Asc
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSort('desc')}>
                    <ArrowDown className="h-3.5 w-3.5 text-muted-foreground/70" />
                    Desc
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => column.toggleVisibility(false)}>
                    <EyeOff className="h-3.5 w-3.5 text-muted-foreground/70" />
                    Hide
                </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
    );
}