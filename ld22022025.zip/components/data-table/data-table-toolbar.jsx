"use client";

import { X } from "lucide-react";
import { Button } from "../button";
import { Input } from "../input";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";

export function DataTableToolbar({ table, globalFilterColumnId, facetedFilters=[] }) {
    if (!table) {
        return null; // Or you could render a fallback UI or loading state
    }
    
    const isFiltered = table.getState().columnFilters.length > 0;
    const globalFilterValue = table.getColumn(globalFilterColumnId)?.getFilterValue() || "";

    const handleGlobalFilterChange = (event) => {
        const column = table.getColumn(globalFilterColumnId);
        if (column) {
          column.setFilterValue(event.target.value);
        }
    };
    
    const handleResetFilters = () => {
    if (table.resetColumnFilters) {
        table.resetColumnFilters();
    }
    };
    return (
        <div className="flex item-center jsutify-between">
            <div className="flex flex-1 item-center space-x-2">
                {globalFilterColumnId && (
                    <Input 
                        placeholder={`Filter ${globalFilterColumnId}...`}
                        value={globalFilterValue}
                        onChange={handleGlobalFilterChange}
                        className="h-8 w-[150px] lg:w-[250px]"
                        aria-label={`Global filter for ${globalFilterColumnId}`}
                    />
                )}
                 {facetedFilters.length > 0 && facetedFilters.map((filter) => (
                    <DataTableFacetedFilter
                        key={filter.id}
                        column={table.getColumn(filter.id)}
                    />
                ))}

                {isFiltered && (
                    <Button
                        variant="ghost"
                        onClick={handleResetFilters}
                        className="h-8 px-2 lg:px-3"
                        aria-label="Reset filters"
                    >
                        Reset
                        <X />
                    </Button>
                )}
            </div> 
            <DataTableViewOptions table={table} />
        </div>
    );
};