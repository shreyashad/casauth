import Image from "next/image";

export default function CourseCatlogCard({ course }) {
    const { difficulty_level, cover_image, title, duration, parts, technology } = course;
    const isExternalImage = cover_image.startsWith("http");
    return (
        <div className="max-w-sm bg-white px-6 pt-6 pb-2 rounded-xl shadow-lg transform hover:scale-105 transition duration-500">
            <h3 className="mb-3 text-xl font-bold text-indigo-600">{difficulty_level}</h3>
            
            <div className="relative mb-4">
                {/* Use next/image for external image URLs */}
                {isExternalImage ? (
                    <img 
                        src={cover_image} 
                        alt={title}
                        className="w-full rounded-xl" // Optional: for rounded corners
                    />
                ) : (
                    // Otherwise, use next/image for local or internal images
                    <Image 
                        src={cover_image} 
                        alt={title}
                        layout="responsive" // Responsive image
                        width={600}          // Width of the image
                        height={400}         // Height of the image
                        className="rounded-xl" // Optional: for rounded corners
                    />
                )}
            </div>

            <h1 className="mt-4 text-gray-800 text-2xl font-bold cursor-pointer">{title}</h1>
            <div className="my-4">
                <div className="flex space-x-1 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600 mb-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p>{duration} Minutes</p>
                </div>
                <div className="flex space-x-1 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600 mb-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 4v12l-4-2-4 2V4M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p>{parts} Modules</p>
                </div>
                <div className="flex space-x-1 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600 mb-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                    </svg>
                    <p>{technology}</p>
                </div>
            </div>
            <button className="mt-4 text-xl w-full text-white bg-indigo-600 py-2 rounded-xl shadow-lg">Buy Lesson</button>
        </div>
    );
}
