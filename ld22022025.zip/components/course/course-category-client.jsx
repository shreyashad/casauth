"use client";
import { useRouter } from "next/navigation";
import { Button } from "../ui/button";
import { Plus } from "lucide-react";

const CourseCategoryClient = () => {
    const router = useRouter();
    return(
        <Button onClick={() => {
            router.push("/dashboard/trainers-admin/course-management/category/new");
        }}>
            <Plus className="mr-2 h-4 w-4" /> Add New
        </Button>
    );
};

export default CourseCategoryClient;