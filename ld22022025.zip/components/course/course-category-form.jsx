"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Separator } from "../ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CourseCategorySchema } from "@/schema";
import { Input } from "../ui/input";
import Image from "next/image";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { createNewCategory, deleteCourseCategory, updateCourseCategory } from "@/app/api/server/route";
import toast from "react-hot-toast";
import { useEffect, useState } from "react";
import { Trash } from "lucide-react";
import { AlertModal } from "../dashboard/alert-modal";

export const CourseCategoryForm = ({ initialData }) => {
    console.log("category data:", initialData);
    const router = useRouter();
    const { data: session } = useSession();

    const title = initialData && initialData.id ?  "Edit Course Category" : "Create Course Category";
    const description = initialData && initialData.id ?  "Edit the Course category details" : "Create a new Course category";
    const action = initialData && initialData.id ?  "Save Changes" : "Create";
    
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    
    
    const form = useForm({
        resolver: zodResolver(CourseCategorySchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            category_status:"",
            image: null,
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        try {
            setLoading(true);
            if (initialData && initialData.id) {
                await updateCourseCategory(session.accessToken, initialData.id, values);
                router.push(`/dashboard/trainers-admin/course-management/category/`);
            } else {
                await createNewCategory(session.accessToken, values);
                router.push(`/dashboard/trainers-admin/course-management/category/`);
            }
            router.refresh();
            toast.success(`${action} successfully!`)
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    

    const onDelete = async () => {
        try {
            setLoading(true);
            await deleteCourseCategory(initialData.id, session.accessToken);
            toast.success("Course Category deleted successfully")
            router.push(`dashboard/trainers-admin/course-management/category/`);
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return(
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </CardHeader>
            <Separator />
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel> Category Name</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter category name"
                                                {...field }
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="image"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Category Image</FormLabel>
                                        <FormControl>
                                            <div className="flex items-center space-x-4">
                                                <Input
                                                    type="file"
                                                    accept="image/*"
                                                    disabled={loading}
                                                    onChange={(e) => {
                                                        field.onChange(e.target.files?.[0]);
                                                    }}
                                                />
                                                {field.value ? (
                                                    field.value instanceof File ? (
                                                        <Image
                                                            src={URL.createObjectURL(field.value)}
                                                            alt="Category icon preview"
                                                            width={50}
                                                            height={50}
                                                            className="object-cover rounded"
                                                        />
                                                    ) : (
                                                        <Image
                                                            src={field.value} // assuming field.value is a URL string when editing
                                                            alt="Category icon preview"
                                                            width={50}
                                                            height={50}
                                                            className="object-cover rounded"
                                                        />
                                                    )
                                                ) : initialData?.image ? ( // check if there's an existing image URL in initialData
                                                    <Image
                                                        src={initialData.image} // use the existing image URL
                                                        alt="Category icon preview"
                                                        width={50}
                                                        height={50}
                                                        className="object-cover rounded"
                                                    />
                                                ) : null}
                                            </div>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            <FormField
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea
                                                {...field}
                                                placeholder="Category Description"
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="category_status"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Category Status</FormLabel>
                                        <FormControl>
                                            <Select
                                                {...field}
                                                onValueChange={(value) => field.onChange(value)}
                                                
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Select a status" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Published">Published</SelectItem>
                                                    <SelectItem value="Inactive">Inactive</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="mt-5 space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>

                </Form>
                {initialData && initialData.id && (
                    <AlertModal 
                        title="Are you Sure!"
                        description="This actions can not be undone."
                        name={initialData?.name}
                        isOpen={open}
                        onClose={() => setOpen(false)}
                        onConfirm={onDelete}
                        loading={loading}
                    />
                )}
            </CardContent>
        </Card>
    );
}