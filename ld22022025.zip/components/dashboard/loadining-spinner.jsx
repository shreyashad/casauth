export default function LoadingSpinner() {
    return (
      <div className="flex justify-center items-center h-24">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    )
  }
  